cd "C:/Users/Sakuya/.codex/worktrees/a61b/FPGA-Music-project/src/gowin/tdm_synth"
open_project "C:/Users/Sakuya/.codex/worktrees/a61b/FPGA-Music-project/src/gowin/tdm_synth/tdm_synth.gprj"
set_option -top_module tdm_ship
set_option -use_sspi_as_gpio 1
run all
exit
