module finger_synth_probe(
input clk,rst_n,ev_valid,ev_on,uart_rx_pin,finger_valid,
input [6:0] ev_note,input [3:0] ev_vel,input [1:0] finger_cmd,
input [4:0] finger_id,finger_group,input signed [11:0] finger_position,
output uart_tx_pin,dac_din,dac_ws,dac_bck,pa_en,output [5:0] led,
inout [15:0] pad);
tdm_top #(.FINGER_EXPR(1)) u(.clk(clk),.rst_n(rst_n),.ev_valid(ev_valid),
.ev_on(ev_on),.ev_note(ev_note),.ev_vel(ev_vel),.preset(2'd1),.test_mode(1'b0),
.uart_rx_pin(uart_rx_pin),.uart_tx_pin(uart_tx_pin),.dac_din(dac_din),
.dac_ws(dac_ws),.dac_bck(dac_bck),.pa_en(pa_en),.led(led),.pad(pad),
.finger_valid(finger_valid),.finger_cmd(finger_cmd),.finger_id(finger_id),
.finger_group(finger_group),.finger_position(finger_position),
.voice_valid(),.voice_on(),.voice_group(),.voice_note());
endmodule
