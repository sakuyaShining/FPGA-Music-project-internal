cd "C:/Users/Sakuya/.codex/worktrees/a61b/FPGA-Music-project/sim_build/finger_pitch/synth"
open_project "C:/Users/Sakuya/.codex/worktrees/a61b/FPGA-Music-project/sim_build/finger_pitch/synth/probe.gprj"
set_option -top_module finger_synth_probe
set_option -use_sspi_as_gpio 1
run syn
exit
