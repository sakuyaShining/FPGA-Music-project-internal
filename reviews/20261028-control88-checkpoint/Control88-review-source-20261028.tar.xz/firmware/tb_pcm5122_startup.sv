`timescale 1ns/1ps
module tb_pcm5122_startup;
reg clk=0;always #5 clk=~clk;
reg rst_n=0,start=0,bus_busy=0,done=0,err=0;reg[31:0]rdata=0;
wire req,rd,busy,ready;wire[6:0]dev;wire[7:0]reg_a;wire[15:0]wd;wire[1:0]wn;wire[2:0]rn,fault;
pcm5122_startup #(.WAIT_CYCLES(3),.TX_TIMEOUT_CYCLES(30),.POLL_MAX(4))dut(clk,rst_n,start,bus_busy,done,err,rdata,req,dev,rd,reg_a,wd,wn,rn,busy,ready,fault);
integer mode=0,delay_left=-1,txcount=0,writeindex=0,pllpolls=0,bootpolls=0;reg saved_rd;reg[7:0]saved_reg;reg[15:0]saved_wd;reg[15:0]expected[0:24];
initial begin
 expected[0]=16'h0000;
 expected[1]=16'h0311;
 expected[2]=16'h0210;
 expected[3]=16'h0400;
 expected[4]=16'h255a;
 expected[5]=16'h0d10;
 expected[6]=16'h1400;
 expected[7]=16'h1520;
 expected[8]=16'h1600;
 expected[9]=16'h1700;
 expected[10]=16'h1801;
 expected[11]=16'h1b01;
 expected[12]=16'h1c0f;
 expected[13]=16'h1d03;
 expected[14]=16'h1e07;
 expected[15]=16'h2200;
 expected[16]=16'h2304;
 expected[17]=16'h2400;
 expected[18]=16'h2830;
 expected[19]=16'h2900;
 expected[20]=16'h3d30;
 expected[21]=16'h3e30;
 expected[22]=16'h0401;
 expected[23]=16'h1301;
 expected[24]=16'h1300;
end
always @(posedge clk)begin
 if(!rst_n)begin done<=0;err<=0;rdata<=0;bus_busy<=0;delay_left<=-1;txcount<=0;writeindex<=0;pllpolls<=0;bootpolls<=0;end
 else begin
 done<=0;err<=0;
 if(mode==7)bus_busy<=1;
 if(req)begin
  if(bus_busy)$fatal(1,"Request while busy");
  if(dev!==7'h4c || (rd && rn!==1) || (!rd && wn!==1))$fatal(1,"Bad request contract");
  if(!rd && writeindex<25)begin
   if({reg_a,wd[7:0]}!==expected[writeindex])$fatal(1,"Wrong startup ROM sequence");
   writeindex<=writeindex+1;
  end
  if(!rd && reg_a==3 && wd[7:0]==0 && (pllpolls<3 || bootpolls<3))$fatal(1,"Unmute before lock/boot");
  saved_rd<=rd;saved_reg<=reg_a;saved_wd<=wd;txcount<=txcount+1;bus_busy<=1;delay_left<=3;
 end
 else if(delay_left>0)delay_left<=delay_left-1;
 else if(delay_left==0 && mode!=6)begin
  delay_left<=-1;bus_busy<=0;done<=1;rdata<=0;
  if(mode==1 && txcount==8)err<=1;
  if(saved_rd)begin
   case(saved_reg)
   8'h04:begin pllpolls<=pllpolls+1;rdata<=mode==2?8'h11:pllpolls<2?8'h11:8'h01;end
   8'h28:rdata<=mode==3?8'h02:8'h30;
   8'h76:begin bootpolls<=bootpolls+1;rdata<=mode==4?0:bootpolls<2?0:8'h85;end
   default:$fatal(1,"Unexpected read");
   endcase
  end
 end
 if(ready && fault!=0)$fatal(1,"Ready with fault");
 end
end
task run_case(input integer m,input[2:0]expected_fault);
 integer ticks,final_count;
 begin
 @(negedge clk);rst_n=0;start=0;mode=m;repeat(3)@(negedge clk);rst_n=1;
 repeat(3)@(negedge clk);start=1;@(negedge clk);start=0;ticks=0;
 while(!ready && fault==0 && ticks<5000)begin @(negedge clk);ticks=ticks+1;end
 if(ticks==5000 || fault!==expected_fault || (expected_fault==0 && !ready) || (expected_fault!=0 && ready))$fatal(1,"Scenario %0d fault=%0d ready=%0d",m,fault,ready);
 final_count=txcount;repeat(40)@(negedge clk);if(txcount!=final_count || busy)$fatal(1,"Continued after terminal state");
 $display("PASS scenario%0d fault%0d requests%0d",m,fault,txcount);
 end
endtask
initial begin
 run_case(0,0);run_case(1,1);run_case(2,3);run_case(3,4);run_case(4,5);run_case(6,2);run_case(7,2);
 $display("PASS_PCM5122_STARTUP_7_SCENARIOS");$finish;
end
endmodule
