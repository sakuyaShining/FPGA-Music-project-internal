`timescale 1ns/1ps
module tb_existing_serial_alignment;
reg clk=0;always #5 clk=~clk;reg rst_n=0;wire en,bck,lrck,se,sd,ws;reg signed[23:0]sample=24'h123400;
audio_clk_en cg(clk,rst_n,en,bck,lrck,se);
i2s_tx tx(clk,rst_n,en,lrck,se,sample,sd,ws);
reg[15:0]left,right,i2s_word;integer i,j,mismatches=0;reg[15:0]patterns[0:7];
initial begin
 patterns[0]=16'h1234;patterns[1]=16'h8001;patterns[2]=16'h7ffe;patterns[3]=16'hfedc;patterns[4]=16'ha55a;patterns[5]=16'h0100;patterns[6]=16'h3c69;patterns[7]=16'h9123;
 repeat(5)@(negedge clk);rst_n=1;
 for(j=0;j<8;j=j+1)begin
  @(negedge clk);sample={patterns[j],8'b0};repeat(3)@(negedge ws);
  left=0;right=0;i2s_word=0;
  for(i=0;i<16;i=i+1)begin @(posedge bck);left={left[14:0],sd};end
  for(i=0;i<16;i=i+1)begin @(posedge bck);right={right[14:0],sd};end
  if(left!==patterns[j] || right!==patterns[j])$fatal(1,"Not LTJ16 left=%h right=%h expected=%h",left,right,patterns[j]);
  @(negedge ws);@(posedge bck); // A Philips I2S receiver skips WS transition bit.
  for(i=0;i<16;i=i+1)begin @(posedge bck);i2s_word={i2s_word[14:0],sd};end
  if(i2s_word!==patterns[j])mismatches=mismatches+1;
 end
 if(mismatches!=8)$fatal(1,"Negative I2S receiver did not distinguish all patterns");
 $display("PASS_EXISTING_STREAM_LTJ16_8_PATTERNS_I2S_NEGATIVE_8");$finish;
end
initial begin #20000000;$fatal(1,"timeout");end
endmodule
