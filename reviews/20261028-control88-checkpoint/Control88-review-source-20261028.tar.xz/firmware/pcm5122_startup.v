// PCM5122PWR dedicated-bus startup CANDIDATE. No top-level integration yet.
// TI SLAS763C pp47-49,72-85,97. Board: MODE2=1 MODE1=0, ADR1/2=0,
// SCK=GND, VCOM=GND (default VREF). Existing serial TX is LEFT-JUSTIFIED16.
// 27MHz/18 BCK=1.5MHz, Fs=BCK/32=46875Hz. P1 J32 D0 R2 ->96MHz.
// DSP /2=48MHz(1024Fs), DAC /16=6MHz(128Fs), OSR /8=750kHz(16Fs),
// NCP /4=1.5MHz. Do not reuse for a different clock or VCOM mode.
// Owner must hold exclusive I2C bus ownership until busy falls. Gate audio
// samples to zero unless ready=1; keep BCK/LRCK running throughout startup.
module pcm5122_startup #(
 parameter integer WAIT_CYCLES=27000,
 parameter integer TX_TIMEOUT_CYCLES=2700000,
 parameter integer POLL_MAX=128
)(input wire clk,rst_n,start,
 input wire i2c_busy,i2c_done,i2c_err,input wire[31:0]i2c_rd_data,
 output reg i2c_req,output wire[6:0]i2c_dev,
 output wire i2c_rd,output wire[7:0]i2c_reg_a,
 output wire[15:0]i2c_wr_d,output wire[1:0]i2c_wr_n,
 output wire[2:0]i2c_rd_n,
 output reg busy,ready,output reg[2:0]fault);
 localparam IDLE=0,DELAY=1,ISSUE=2,WAIT_TX=3,FINISHED=4,FAILED=5;
 reg[2:0]state,phase;reg[5:0]index;reg[31:0]timer,polls;
 function[15:0]rom(input[5:0]n);
 begin case(n)
      6'd0: rom=16'h0000;
      6'd1: rom=16'h0311;
      6'd2: rom=16'h0210;
      6'd3: rom=16'h0400;
      6'd4: rom=16'h255a;
      6'd5: rom=16'h0d10;
      6'd6: rom=16'h1400;
      6'd7: rom=16'h1520;
      6'd8: rom=16'h1600;
      6'd9: rom=16'h1700;
      6'd10: rom=16'h1801;
      6'd11: rom=16'h1b01;
      6'd12: rom=16'h1c0f;
      6'd13: rom=16'h1d03;
      6'd14: rom=16'h1e07;
      6'd15: rom=16'h2200;
      6'd16: rom=16'h2304;
      6'd17: rom=16'h2400;
      6'd18: rom=16'h2830;
      6'd19: rom=16'h2900;
      6'd20: rom=16'h3d30;
      6'd21: rom=16'h3e30;
      6'd22: rom=16'h0401;
      6'd23: rom=16'h1301;
      6'd24: rom=16'h1300;
 default:rom=16'h0000;
 endcase end endfunction
 wire[15:0]word=rom(index);
 assign i2c_dev=7'h4c;
 assign i2c_rd=(phase==1 || phase==2 || phase==4);
 assign i2c_reg_a=phase==0?word[15:8]:phase==1?8'h04:phase==2?8'h28:phase==3?8'h02:phase==4?8'h76:8'h03;
 assign i2c_wr_d=phase==0?{8'b0,word[7:0]}:16'b0;
 assign i2c_wr_n=i2c_rd?2'd0:2'd1;
 assign i2c_rd_n=i2c_rd?3'd1:3'd0;
 task fail(input[2:0]code);begin fault<=code;busy<=0;ready<=0;state<=FAILED;end endtask
 always @(posedge clk or negedge rst_n) begin
 if(!rst_n)begin state<=IDLE;phase<=0;index<=0;timer<=0;polls<=0;i2c_req<=0;busy<=0;ready<=0;fault<=0;end
 else begin
 i2c_req<=0;
 case(state)
 IDLE:if(start)begin busy<=1;ready<=0;fault<=0;phase<=0;index<=0;timer<=0;polls<=0;state<=DELAY;end
 DELAY:if(timer>=WAIT_CYCLES-1)begin timer<=0;state<=ISSUE;end else timer<=timer+1;
 ISSUE:if(!i2c_busy)begin i2c_req<=1;timer<=0;state<=WAIT_TX;end
       else if(timer>=TX_TIMEOUT_CYCLES-1)fail(2);else timer<=timer+1;
 WAIT_TX:if(i2c_done)begin
  timer<=0;
  if(i2c_err)fail(1);
  else case(phase)
   0:if(index==24)begin phase<=1;polls<=0;state<=DELAY;end else begin index<=index+1;state<=ISSUE;end
   // PLCK bit4 is ONE WHEN UNLOCKED; PLLE bit0 must remain enabled.
   1:if((i2c_rd_data[7:0]&8'h11)==8'h01)begin phase<=2;polls<=0;state<=ISSUE;end
     else if(polls>=POLL_MAX-1)fail(3);else begin polls<=polls+1;state<=DELAY;end
   2:if(i2c_rd_data[7:0]!=8'h30)fail(4);else begin phase<=3;state<=ISSUE;end
   3:begin phase<=4;polls<=0;state<=DELAY;end
   4:if(i2c_rd_data[7])begin phase<=5;state<=ISSUE;end
     else if(polls>=POLL_MAX-1)fail(5);else begin polls<=polls+1;state<=DELAY;end
   5:begin busy<=0;ready<=1;state<=FINISHED;end
   default:fail(7);
  endcase
 end else if(timer>=TX_TIMEOUT_CYCLES-1)fail(2);else timer<=timer+1;
 FINISHED:begin busy<=0;ready<=1;end
 FAILED:begin busy<=0;ready<=0;end
 default:fail(7);
 endcase end end
endmodule
