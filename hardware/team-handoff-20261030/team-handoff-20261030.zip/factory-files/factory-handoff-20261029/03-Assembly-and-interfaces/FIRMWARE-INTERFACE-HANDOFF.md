# 固件任务交接：Sensor14Bank准确接口

当前硬件：Sensor14Bank S1，PCB 2184d027；Control88 R2，PCB 733e1d9c。

- J2.3 RC_DRIVE → R1 47k → RC0 → U1公共端Z及U2.1施密特反相输入。
- U2.2反相输出INV0 → R2 220Ω → J2.5 SENSE_OUT。六板分别接Control88 JB0…5的第5脚SENSE_0…5。
- LOW驱动放电，SENSE为HIGH；HIGH驱动充电，测SENSE从HIGH到LOW的时间。RC_DRIVE不是MOS管栅极。必须先确认放电完成，再按反相输出计时，不能见到初始HIGH就作为触发完成。
- MUX_DISABLE HIGH断开；LOW接通ADDR[3:0]对应通道。CH14=10pF、CH15=100pF两个参考；CH0…13外接电极。
- 地址/禁用由控制板595链输出，R1充放电波形和165返回读取须结合共享总线仲裁仿真。至少覆盖两校准通道、延时响应、超时、并行六通道及屏总线活动。

Q4此前按“放电管栅极/高有效”写前端，本硬件证据明确了真实语义；本任务没有修改该协作者RTL，也不宣称固件或整机通过。请按源网表做定向仿真/上板波形验证。
