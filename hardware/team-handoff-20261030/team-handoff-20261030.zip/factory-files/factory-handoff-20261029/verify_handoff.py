from pathlib import Path
import csv,json,hashlib,zipfile
p=Path(__file__).resolve().parent;m=json.loads((p/'MANIFEST.json').read_text(encoding='utf-8'))
for n,h in m['files_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
rows=list(csv.DictReader((p/'COMBINED-38SKU-256PARTS-NET-QUANTITIES.csv').open(encoding='utf-8-sig')));assert len(rows)==38 and sum(int(r['Total_net_quantity']) for r in rows)==256
for archive in (p/'99-Frozen-sources-and-evidence').glob('*.zip'):
 with zipfile.ZipFile(archive) as z:
  assert z.testzip() is None
  mn=next(n for n in z.namelist() if n.count('/')==1 and n.endswith('/MANIFEST.json'));sm=json.loads(z.read(mn));prefix=mn.rsplit('/',1)[0]+'/'
  for n,h in sm['files_sha256'].items():assert hashlib.sha256(z.read(prefix+n)).hexdigest()==h,(archive.name,n)
print('PASS: combined handoff file hashes, 38SKU/256parts, and both frozen source archive contents.')
