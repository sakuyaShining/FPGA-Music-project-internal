from pathlib import Path
import hashlib,json,collections
p=Path(__file__).resolve().parent;m=json.loads((p/'MANIFEST.json').read_text(encoding='utf-8'))
for n,h in m['files_sha256'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==h,n
pcb=p/'source/pcb/PCB2.epcb2';assert hashlib.sha256(pcb.read_bytes()).hexdigest()==m['pcb_sha256'];counts=collections.Counter();active=False;nets=set()
for line in pcb.read_text(encoding='utf-8-sig').splitlines():
 if '||' not in line:continue
 a,b=line.split('||',1);b=b[:-1] if b.endswith('|') else b
 if not b.strip():continue
 a,b=json.loads(a),json.loads(b)
 if a['type']=='DOCHEAD':active=b['docType']=='PCB'
 if active:
  counts[a['type']]+=1
  if a['type']=='PAD_NET' and b['padNet']:nets.add(b['padNet'])
for k,v in [('COMPONENT',28),('PAD_NET',150),('LINE',302),('VIA',51),('POUR',3),('POURED',3)]:assert counts[k]==v,(k,counts[k])
assert len(nets)==41
g=json.loads((p/'evidence/sensor-ground-review.json').read_text());assert g['pcb_sha256']==m['pcb_sha256'];assert not g['full_copper_including_pours_check']['clearance_errors'] and not g['full_copper_including_pours_check']['unconnected_nets']
r=json.loads((p/'evidence/sensor-manufacturing-verification.json').read_text());assert r['pcb_sha256']==m['pcb_sha256'] and r['all83_hole_positions_and_diameters_match']
assert all(x['missing_mm2_at_5um']==x['extra_mm2_at_5um']==0 for x in r['whole_copper_equivalence_5um_tolerance'].values())
assert '全部 (0)' in (p/'evidence/native-pcb-drc-reopened.txt').read_text(encoding='utf-8')
print('PASS: Sensor S1 file hashes, exact source, 28 components/150 pad nets/41 nets/302 lines/51 vias and ground/Gerber evidence binding.')
