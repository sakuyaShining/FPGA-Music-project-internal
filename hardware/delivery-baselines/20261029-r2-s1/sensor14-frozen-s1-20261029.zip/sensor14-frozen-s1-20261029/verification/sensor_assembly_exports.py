from sensor_geometry import *
import csv,html
_,b=load();obs=objects(b);bom=list(csv.DictReader((O/'Sensor14Bank-BOM-VERIFIED.csv').open(encoding='utf-8-sig')));old=list(csv.DictReader((O.parent/'electrode-assembly-20261028/Sensor14Bank_BOM_MATCHED_DRAFT.csv').open(encoding='utf-8-sig')));expected={ref:(row['Comment'],row['LCSC Part #'],row['Footprint']) for row in old for ref in row['Designator'].split(',')}
assert {r['Designator']:(r['MPN'],r['LCSC']) for r in bom}=={k:v[:2] for k,v in expected.items()}
with (O/'Sensor14Bank-BOM-FACTORY.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['Comment','Designator','Footprint','LCSC Part #']);w.writeheader();w.writerows(old)
# Standalone source-derived assembly diagram: native coordinates, Top view,
# every pad drawn, exact component designator and pin1 position.
at=collections.defaultdict(dict)
for h,v in b['records']:
 if h['type']=='ATTR':at[v['parentId']][v['key']]=v['value']
parts=[];pins=[]
def xy(x,y):return 40+x*.0254*10,530-y*.0254*10
svg=['<svg xmlns="http://www.w3.org/2000/svg" width="760" height="640" viewBox="0 0 760 640">','<rect width="760" height="640" fill="white"/>','<text x="40" y="30" font-size="20" font-family="Arial">Sensor14Bank — TOP assembly view</text>','<rect x="40" y="80" width="550" height="450" fill="#f3f6f8" stroke="#222" stroke-width="2"/>']
for o in obs:
 if o['kind']!='PAD' or o['layer']!=1:continue
 xs,ys=o['g'].exterior.coords.xy;ps=' '.join(f'{xy(x,y)[0]:.3f},{xy(x,y)[1]:.3f}' for x,y in zip(xs,ys));pin1=o['ref'].endswith('.1');svg.append(f'<polygon points="{ps}" fill="{"#ed8b23" if pin1 else "#b5bfc9"}" stroke="#40566b" stroke-width=".5"/>')
 if pin1:
  x,y=o['g'].centroid.coords[0];pins.append({'Designator':o['ref'].split('.')[0],'Pad1_X_mm':x*.0254,'Pad1_Y_mm':y*.0254})
for h,c in b['records']:
 if h['type']!='COMPONENT':continue
 ref=at[h['id']]['Designator'];x,y=xy(c['x'],c['y']);dx,dy=(0,-15) if ref.startswith(('U','D')) else (0,-10)
 svg.append(f'<text x="{x+dx:.3f}" y="{y+dy:.3f}" text-anchor="middle" font-size="10" font-family="Arial" fill="#162e41">{html.escape(ref)}</text>')
 if ref in ['U1','U2','D1','D2','D3','D4']:parts.append((ref,c['angle']))
svg.extend(['<text x="40" y="565" font-size="13" font-family="Arial">Orange = pad1. Native board origin at lower-left, units mm.</text>','<text x="40" y="588" font-size="13" font-family="Arial">J1: electrodes; J2: controller. J2 pin1 = 3.3V, pin2 = GND.</text>','<text x="40" y="610" font-size="12" font-family="Arial">Verify supplier library pin1/rotation in SMT preview before ordering.</text>','</svg>'])
(O/'Sensor14Bank-TOP-ASSEMBLY.svg').write_text('\n'.join(svg),encoding='utf-8')
with (O/'Sensor14Bank-PIN1-COORDINATES.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(pins[0]));w.writeheader();w.writerows(pins)
r={'pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'factory_BOM_groups':len(old),'factory_BOM_components':len(expected),'all_MPN_LCSC_match_current_source':True,'assembly_drawing':'Sensor14Bank-TOP-ASSEMBLY.svg','pin1_coordinates':'Sensor14Bank-PIN1-COORDINATES.csv','critical_rotations':parts};(O/'sensor-assembly-export-verification.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
