from sensor_geometry import *
import csv
_,b=load();obs=objects(b);nets={o['ref']:o['net'] for o in obs if o['kind']=='PAD'}
control=O.parent/'control88-frozen-r2-20261029/source/pcb/PCB1.epcb2';_,cb=base.load(control);cn={o['ref']:o['net'] for o in base.objects(cb) if o['kind']=='PAD'}
rows=[]
for bank in range(6):
 for pin in range(1,17):
  sensor=nets[f'J2.{pin}'];ctrl=cn[f'JB{bank}.{pin}'];expected=f'SENSE_{bank}' if sensor=='SENSE_OUT' else sensor;assert ctrl==expected,(bank,pin,sensor,ctrl)
  rows.append({'Board':f'B{bank}','Control_connector':f'JB{bank}','Control_pin':pin,'Control_net':ctrl,'Sensor_connector':'J2','Sensor_pin':pin,'Sensor_net':sensor})
f=O/'SIX-BOARD-CONTROL-HARNESS.csv'
with f.open('w',encoding='utf-8-sig',newline='') as out:w=csv.DictWriter(out,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
source=O.parent/'electrode-assembly-20261028/electrode-harness-84-CANDIDATE.csv';electrodes=list(csv.DictReader(source.open(encoding='utf-8-sig')));assert len(electrodes)==84 and {int(r['raw_index']) for r in electrodes}==set(range(84))
assert collections.Counter(r['kind'] for r in electrodes)=={'pitch':75,'octave':5,'spare':4}
assert collections.Counter(r['board_label'] for r in electrodes)=={f'B{i}':14 for i in range(6)}
assert len({(r['board_label'],r['pin']) for r in electrodes})==84
mux_channel_pins={0:9,1:8,2:7,3:6,4:5,5:4,6:3,7:2,8:23,9:22,10:21,11:20,12:19,13:18,14:17,15:16}
for row in electrodes:
 e=nets['J1.'+row['pin']];assert e==row['PCB_electrode_net'];res=row['series_resistor'];rp={nets[res+'.1'],nets[res+'.2']};mux=nets['U1.'+row['mux_pin']]
 assert rp=={e,mux};assert int(row['mux_pin'])==mux_channel_pins[int(row['channel'])]
for pin,net in {'1':'RC0','10':'ADDR0','11':'ADDR1','12':'GND','13':'ADDR3','14':'ADDR2','15':'MUX_DISABLE','24':'3V3_IO'}.items():assert nets['U1.'+pin]==net
assert nets['U2.1']=='RC0' and nets['U2.2']=='INV0' and nets['U2.7']=='GND' and nets['U2.14']=='3V3_IO'
assert {nets['R1.1'],nets['R1.2']}=={'RC_DRIVE','RC0'} and {nets['R2.1'],nets['R2.2']}=={'INV0','SENSE_OUT'}
calib={ref:{k.split('.')[1]:n for k,n in nets.items() if k.startswith(ref+'.')} for ref in ['C3','C4']}
assert {nets['C3.1'],nets['C3.2']}=={'L0_M14','GND'} and {nets['C4.1'],nets['C4.2']}=={'L0_M15','GND'}
for d in ['D1','D2','D3','D4']:
 assert nets[d+'.3']==nets[d+'.8']=='GND'
 for a,z in [(1,10),(2,9),(4,7),(5,6)]:assert nets[d+'.'+str(a)]==nets[d+'.'+str(z)]
r={'sensor_pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'control_pcb_sha256':hashlib.sha256(control.read_bytes()).hexdigest(),'six_connectors_96_pin_matches':True,'six_SENSE_nets_independent':True,'external_electrodes':84,'pitch':75,'octave':5,'spare':4,'per_board_electrodes':14,'calibration_channels_per_board':2,'calibration_channels':calib,'pin_to_resistor_to_mux_matches_all84_rows':True,'sources':{'U1':'https://assets.nexperia.com/documents/data-sheet/74HC_HCT4067.pdf','U2':'https://www.ti.com/lit/ds/symlink/sn74lvc14a.pdf','ESD':'https://www.ti.com/lit/ds/symlink/tpd4e02b04.pdf'},'firmware_contract':'RC_DRIVE connects via R1 47k to RC0; U2.1/2 invert RC0. Drive LOW to discharge (SENSE_OUT HIGH), then HIGH to charge; time SENSE_OUT HIGH-to-LOW transition. E/MUX_DISABLE HIGH disconnects all channels. There is no MOSFET discharge gate on this sensor board.','firmware_implementation_validation':'Q4 prior scan semantics require targeted simulation/bench verification; this task freezes hardware and supplies the exact contract.'}
(O/'sensor-interface-review.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(r,ensure_ascii=True,indent=2))
