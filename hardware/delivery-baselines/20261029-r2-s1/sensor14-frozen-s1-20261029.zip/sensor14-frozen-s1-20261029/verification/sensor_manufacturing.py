from sensor_ground import *
from shapely.geometry import box
import re,csv,importlib.util
_,b=load();ds=documents(Q);obs=objects(b);planes,mains,ground_report=ground(b)
from gerber_geometry import gerber_regions
G=O/'gerber-inspection';coverage={}
whole_copper={}
for layer,name in [(1,'TopLayer.GTL'),(2,'BottomLayer.GBL'),(15,'InnerLayer1.G1'),(16,'InnerLayer2.G2')]:
 native=unary_union(([planes[layer]] if layer in planes else [])+[o['g'] for o in obs if o['layer']==layer]);native=scale(native,.0254,.0254,origin=(0,0));export=gerber_regions(G/('Gerber_'+name))
 missing=native.difference(export.buffer(.005)).area;extra=export.difference(native.buffer(.005)).area
 whole_copper[layer]={'missing_mm2_at_5um':missing,'extra_mm2_at_5um':extra}
 assert missing<.001 and extra<.001,(layer,missing,extra)
for layer,name in [(2,'BottomLayer.GBL'),(15,'InnerLayer1.G1'),(16,'InnerLayer2.G2')]:
 native=scale(planes[layer],.0254,.0254,origin=(0,0));export=gerber_regions(G/('Gerber_'+name));missing=native.difference(export.buffer(.005)).area;assert missing<.001,(layer,missing)
 coverage[layer]={'native_pour_mm2':native.area,'uncovered_mm2_at_5um':missing}
# Reuse the reviewed line/width inclusion checker, with exact source paths.
spec=importlib.util.spec_from_file_location('gerberlines',src.parent/'compare_r2_gerber.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.Q=Q;mod.G=G;mod.O=O;mod.main()
lr=json.loads((O/'r2-gerber-samesource-check.json').read_text(encoding='utf-8'));assert lr['all_layers_same_source'] and lr['via_count_match']
libs={d['head']['uuid']:d for d in ds};at=collections.defaultdict(dict)
for h,v in b['records']:
 if h['type']=='ATTR':at[v['parentId']][v['key']]=v['value']
expected=[]
for h,c in b['records']:
 if h['type']=='VIA':expected.append((c['centerX']*.0254,c['centerY']*.0254,c['holeDiameter']*.0254));continue
 if h['type']!='COMPONENT':continue
 theta=math.radians(c['angle']);co,si=math.cos(theta),math.sin(theta)
 for hh,p in libs[at[h['id']]['Footprint']]['records']:
  if hh['type']!='PAD' or not p.get('hole') or p['hole']['width']<=0:continue
  assert p['hole']['holeType']=='ROUND';pa=math.radians(p['padAngle']);ox=p.get('padOffsetX',0) or 0;oy=p.get('padOffsetY',0) or 0;x=p['centerX']+ox*math.cos(pa)-oy*math.sin(pa);y=p['centerY']+ox*math.sin(pa)+oy*math.cos(pa)
  expected.append(((c['x']+x*co-y*si)*.0254,(c['y']+x*si+y*co)*.0254,p['hole']['width']*.0254))
txt=(G/'Drill_PTH_Through.DRL').read_text();toolsizes={int(n):float(d) for n,d in re.findall(r'^T(\d+)C([\d.]+)$',txt,re.M)};actual=[];tool=None
for l in txt.splitlines():
 t=re.fullmatch(r'T(\d+)',l)
 if t:tool=int(t[1]);continue
 m=re.fullmatch(r'X(-?[\d.]+)Y(-?[\d.]+)',l)
 if m:actual.append((float(m[1]),float(m[2]),toolsizes[tool]))
assert len(expected)==len(actual)==83;remain=actual.copy();maxerr=0
for a in expected:
 q=min(remain,key=lambda x:math.dist(a,x));err=math.dist(a,q);assert err<.00003,(a,q,err);maxerr=max(maxerr,err);remain.remove(q)
native=list(csv.DictReader((O/'Sensor14Bank_2184d027_CPL_NATIVE.csv').open(encoding='utf-16'),delimiter='\t'));comps={at[h['id']]['Designator']:c for h,c in b['records'] if h['type']=='COMPONENT'};assert len(native)==len(comps)==28;rows=[]
for row in native:
 c=comps[row['Designator']]
 assert abs(float(row['Ref X'].removesuffix('mm'))-c['x']*.0254)<.00001 and abs(float(row['Ref Y'].removesuffix('mm'))-c['y']*.0254)<.00001
 assert float(row['Rotation'])==c['angle'] and row['Layer']=='T'
 if row['SMD']=='Yes':rows.append({'Designator':row['Designator'],'Mid X':row['Mid X'],'Mid Y':row['Mid Y'],'Layer':'Top','Rotation':row['Rotation']})
assert len(rows)==26
with (O/'Sensor14Bank-CPL-SMT-VERIFIED.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
r={'pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'native_export_zip_sha256':hashlib.sha256((O/'Sensor14Bank_2184d027_Gerber_REVIEW.zip').read_bytes()).hexdigest(),'all_actual_ground_pours_covered_by_gerber':coverage,'all_effective_trace_segments_and_widths_covered':lr['all_layers_same_source'],'all83_hole_positions_and_diameters_match':True,'max_drill_coordinate_diameter_error_mm':maxerr,'native_CPL_components_positions_rotations_match':28,'SMT_CPL_components':26,'THT_components':2,'using_native_board_origin_and_midpoints':True,'note':'No copper or placements changed; reuse of original native exports is proven by geometry and current exact file hashes, not inherited status.'}
r['whole_copper_equivalence_5um_tolerance']=whole_copper
r['production_optimization']='Inner layer SOLID minimum-neck8mil contours include a native8mil circular contour stroke; reconstructed using native POUR parameter, then matched both directions against actual Gerber.'
(O/'sensor-manufacturing-verification.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
