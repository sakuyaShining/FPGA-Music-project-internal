from sensor_geometry import *
ds,b=load();at=collections.defaultdict(dict);libs={d['head']['uuid']:d for d in ds}
for h,v in b['records']:
 if h['type']=='ATTR':at[v['parentId']][v['key']]=v['value']
reviews=[]
for h,c in b['records']:
 if h['type']!='COMPONENT':continue
 ref=at[h['id']]['Designator'];fp=at[h['id']]['Footprint'];pads={p['num']:p for hh,p in libs[fp]['records'] if hh['type']=='PAD'}
 if ref not in ['U1','U2','D1','D2','D3','D4']:continue
 count,pitch=(24,.65) if ref=='U1' else (14,1.27) if ref=='U2' else (10,.5)
 assert set(pads)=={str(i) for i in range(1,count+1)}
 # Library normal orientation: pin1 left/lower, row one increases x;
 # upper row counts back to the left, a valid rotation of top-view pinning.
 a=pads['1'];z=pads[str(count)];assert a['centerX']==z['centerX'] and a['centerY']<z['centerY']
 for i in range(1,count//2):
  dx=(pads[str(i+1)]['centerX']-pads[str(i)]['centerX'])*.0254;assert abs(dx-pitch)<.0004
 for i in range(count//2+1,count):
  dx=(pads[str(i+1)]['centerX']-pads[str(i)]['centerX'])*.0254;assert abs(dx+pitch)<.0004
 reviews.append({'ref':ref,'footprint_uuid':fp,'pins':count,'pitch_mm':pitch,'pad_order_top_view_no_mirror':True,'placement_angle':c['angle'],'pin1_library_mm':[a['centerX']*.0254,a['centerY']*.0254],'supplier_library_rotation_preview_still_required':True})
assert len(reviews)==6
r={'pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'package_mapping':{'U1':'74HC4067PW TSSOP24/SOT355-1; .65mm pitch','U2':'SN74LVC14AD SOIC14;1.27mm pitch','D1-D4':'TPD4E02B04DQA USON10; .5mm pitch'},'checks':reviews,'datasheet_sources':['https://assets.nexperia.com/documents/data-sheet/74HC_HCT4067.pdf','https://www.ti.com/lit/ds/symlink/sn74lvc14a.pdf','https://www.ti.com/lit/ds/symlink/tpd4e02b04.pdf'],'interpretation':'Footprint pin order and pitch checked against exact package top view. The DQA NC pins6/7/9/10 are optional straight-through lands, not electrically protected pin duplicates; PCB parallels them to real channel pins1/2/4/5 by copper, which is allowed optional straight-through routing.','physical_part_marking_and_SMT_preview':'Supplier order-stage check; not yet submitted.'};(O/'sensor-footprint-direction-review.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
