from sensor_ground import *
import importlib.util
_,b=load();obs=objects(b);lines={h['id']:v for h,v in b['records'] if h['type']=='LINE'};vias={h['id']:v for h,v in b['records'] if h['type']=='VIA'}
spec=importlib.util.spec_from_file_location('powergraph',src.parent/'verify_r2_power.py');pg=importlib.util.module_from_spec(spec);spec.loader.exec_module(pg)
groups=collections.defaultdict(list)
for o in obs:
 if o['kind']=='PAD' and o['net']=='3V3_IO':groups[o['id']].append((o['layer'],o['g']))
adj=pg.build_graph(lines,vias,'3V3_IO',list(groups.items()));s=next(o for o in obs if o.get('ref')=='J2.1' and o['layer']==1);source=min((n for n in adj if n[0]==1),key=lambda n:Point(n[1],n[2]).distance(s['g']));assert s['g'].distance(Point(source[1],source[2]))<.02
dist,_=pg.dijkstra(adj,source);assert len(dist)==len(adj);rmax=max(dist.values());load_A=.020;drop_pct=rmax*load_A/3.3*100
assert drop_pct<1
_,_,gr=ground(b);assert not gr['full_copper_including_pours_check']['clearance_errors'] and not gr['full_copper_including_pours_check']['unconnected_nets']
outline=box(0,0,2165.3543,1771.6535);edge=outline.boundary;min_edge=min(o['g'].distance(edge)*.0254 for o in obs);width=min(v['width'] for v in lines.values())*.0254;via_min_hole=min(v['holeDiameter'] for v in vias.values())*.0254;min_ring=min((v['viaDiameter']-v['holeDiameter'])/2 for v in vias.values())*.0254
holes=[]
for v in vias.values():holes.append(Point(v['centerX'],v['centerY']).buffer(v['holeDiameter']/2,quad_segs=128))
# PTH header centers have a tiny drill offset; exact drill-vs-source verification
# separately accounts for it. Distances here include that offset conservatively.
for o in obs:
 if o['kind']=='PAD' and o['layer']==1 and o['ref'].startswith(('J1.','J2.')):holes.append(o['g'].centroid.buffer(40.158/2,quad_segs=128))
min_hole_gap=min(a.distance(z)*.0254 for i,a in enumerate(holes) for z in holes[i+1:])
assert width>=.1 and via_min_hole>=.2 and min_ring>=.075 and min_edge>=.25 and min_hole_gap>=.2
rails={ref:next(o['g'].centroid.coords[0] for o in obs if o.get('ref')==ref and o['layer']==1) for ref in ['C1.1','C2.1','U1.24','U2.14']}
report={'pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'power_source':'J2.1/3V3_IO','worst_supply_path_resistance_20C_ohm':rmax,'assumed_per_board_budget_A':load_A,'drop_pct_at_declared_budget':drop_pct,'six_board_declared_budget_A':load_A*6,'interpretation':'Conditional DC trace-drop calculation; no thermal/transient/actual load measurement.','decoupling_capacitors':{'C1':'100nF 50V X7R0603 on3V3_IO/GND near U1','C2':'100nF 50V X7R0603 on3V3_IO/GND near U2'},'DFM':{'minimum_trace_width_mm':width,'minimum_via_hole_mm':via_min_hole,'minimum_via_annular_ring_mm':min_ring,'minimum_pad_trace_via_edge_to_board_outline_mm':min_edge,'minimum_hole_to_hole_edge_gap_mm':min_hole_gap,'nominal_outline_mm':[55,45],'reference':'https://jlcpcb.com/capabilities/pcb-capabilities','retrieved_date':'2026-10-29','supplier_final_DFM_pending':True},'return_strategy':'Signals only Top/Bottom; inner copper consists of GND pours and GND stitches; both inner GND planes continuous main regions.','physical_test_pending':['RC reference timing / threshold margins','Per-board static current and supply transients','Wire-length/cover-dependent electrode sensitivity and crosstalk']}
planes,_,_=ground(b)
report['DFM']['minimum_pour_copper_edge_to_outline_mm']=min(g.distance(edge)*.0254 for g in planes.values())
(O/'sensor-power-dfm-review.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
