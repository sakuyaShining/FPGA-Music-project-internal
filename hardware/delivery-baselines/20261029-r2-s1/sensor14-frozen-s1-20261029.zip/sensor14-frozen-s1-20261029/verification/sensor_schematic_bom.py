from sensor_geometry import *
import csv
sch=Q.parent.parent/'sch/Sensor14Bank_Schematic/Sensor14_frontend.esch2';ds=documents(sch);s=next(d for d in ds if d['head']['docType']=='SCH_PAGE')
def attrs(records):
 a=collections.defaultdict(dict)
 for h,v in records:
  if h['type']=='ATTR':a[v['parentId']][v['key']]=v['value']
 return a
at=attrs(s['records']);symbols={d['head']['uuid']:d for d in ds if d['head']['docType']=='SYMBOL'};comps={h['id']:v for h,v in s['records'] if h['type']=='COMPONENT'};wires={h['id']:[] for h,v in s['records'] if h['type']=='WIRE'}
for h,v in s['records']:
 if h['type']=='LINE' and v.get('lineGroup')in wires:wires[v['lineGroup']].append(v)
ports=collections.defaultdict(list)
for cid,c in comps.items():
 if not at[cid].get('Designator') and at[cid].get('Name'):ports[(round(c['x'],6),round(c['y'],6))].append(at[cid]['Name'])
schematic={};nc=0
for cid,c in comps.items():
 ref=at[cid].get('Designator')
 if not ref:continue
 assert not c.get('rotation',0) and not c.get('isMirror');sd=symbols[at[cid]['Symbol']];sa=attrs(sd['records']);pins={}
 for h,p in sd['records']:
  if h['type']!='PIN' or p.get('partId')!=c['partId']:continue
  num=str(sa[h['id']]['Pin Number']);xy=(round(c['x']+p['x'],6),round(c['y']+p['y'],6));found=[]
  for wid,lines in wires.items():
   labels=set([at[wid]['NET']]) if at[wid].get('NET') else set()
   for l in lines:
    labels.update(ports[(round(l['startX'],6),round(l['startY'],6))]);labels.update(ports[(round(l['endX'],6),round(l['endY'],6))])
   for l in lines:
    start=(round(l['startX'],6),round(l['startY'],6));end=(round(l['endX'],6),round(l['endY'],6))
    if xy==start or xy==end:
     other=end if xy==start else start
     assert len(labels)==1,(ref,num,xy,labels,at[wid]);found.append(next(iter(labels)))
  assert len(found)<=1
  if not found:assert at[cid+'-'+h['id']].get('NO_CONNECT')=='yes',(ref,num,xy,at[cid+'-'+h['id']]);nc+=1
  pins[num]=found[0] if found else ''
 schematic[ref]=pins
pd,b=load();pa=attrs(b['records']);pb=collections.defaultdict(dict)
for h,v in b['records']:
 if h['type']=='PAD_NET':_,cid,num,pid=json.loads(h['id']);pb[pa[cid]['Designator']][num]=v['padNet']
assert dict(pb)==schematic and sum(len(v) for v in pb.values())==150
devices={d['head']['uuid']:next(v for h,v in d['records'] if h['type']=='META') for d in pd if d['head']['docType']=='DEVICE'};libs={d['head']['uuid']:d for d in pd if d['head']['docType']=='FOOTPRINT'};bom=[]
for h,c in b['records']:
 if h['type']!='COMPONENT':continue
 a=pa[h['id']];dev=devices[a['Device']];props={**dev.get('attributes',{}),**c.get('attrs',{}),**a};ref=a['Designator'];pads=[v for hh,v in libs[a['Footprint']]['records'] if hh['type']=='PAD'];mount='THT' if any(p.get('hole') and p['hole']['width']>0 for p in pads) else 'SMT'
 sc=at[next(cid for cid in comps if at[cid].get('Designator')==ref)]
 assert props['Manufacturer Part']==sc['Manufacturer Part'] and props['Supplier Part']==sc['Supplier Part']
 bom.append({'Designator':ref,'MPN':props['Manufacturer Part'],'LCSC':props['Supplier Part'],'Footprint':a['Footprint'],'Mounting':mount,'Quantity_per_board':1,'Quantity_six_boards':6})
assert len(bom)==28 and sum(v['Mounting']=='SMT' for v in bom)==26
with (O/'Sensor14Bank-BOM-VERIFIED.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(bom[0]));w.writeheader();w.writerows(sorted(bom,key=lambda r:r['Designator']))
r={'pcb_sha256':hashlib.sha256(Q.read_bytes()).hexdigest(),'schematic_sha256':hashlib.sha256(sch.read_bytes()).hexdigest(),'all150_pin_nets_schematic_to_PCB_equal':True,'components':28,'SMT_per_board':26,'TH_per_board':2,'explicit_NC_pins':nc,'effective_nets':41,'bom_identity_source':'PCB embedded DEVICE META + COMPONENT + ATTR, crosschecked schematic MPN.','pin_nets':dict(pb),'BOM':bom};(O/'sensor-schematic-bom-verification.json').write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps({k:v for k,v in r.items() if k not in ['pin_nets','BOM']},ensure_ascii=True,indent=2))
