# Control88 R2 制造源冻结包

状态：**SOURCE_FROZEN — 制造源已冻结，可进入厂家 DFM/SMT 审单及报价。**

冻结 PCB SHA256：`733e1d9c33d11ef946863dca0bc9f36ae2916b9965d038b147aafea416194eb8`

本目录为控制板 R2 唯一交付入口。88 件器件、444 个焊盘网络记录（412 个有效连接、32 个 NC）、68 个网络；1,405 段走线、120 个过孔。源文件和 Gerber 为本次修复后版本。更改任何源文件都需新修订、重跑 DRC 和重导制造文件。

## 使用文件

- `source/FPGA-Music-Control88-GND-R2.eprj3`：嘉立创原生工程，含 10 页原理图及 PCB。
- `manufacturing/Control88-R2-Gerber.zip`：原生导出的四层制造文件。
- `manufacturing/Control88-R2-BOM.csv`：88 位号校正 BOM，76 件 SMT / 12 件插件。工厂承担 SMT；插件装配与配线另按采购/装配方案安排。
- `manufacturing/Control88-R2-CPL-SMT.csv`：76 件顶面 SMT，中心坐标取自原生 CPL；单位 mm，板坐标原点，原生角度。
- `manufacturing/Control88-R2-CPL-EDA-ORIGINAL.tsv`：完整原生导出，UTF-16 制表符文件，含中心、原点、1 号焊盘坐标及角度，供审单对照。
- `MANIFEST.json` / `SHA256SUMS.txt`：本包文件绑定和完整性校验。

## 已关闭的工程检查

| 检查 | 结果与证据 |
|---|---|
| 原生保存重开 DRC | 2026-10-29 08:35:13，141 项检查，0 问题；前后 PCB 哈希一致 |
| 独立线铜间距/网络 | 6 mil 规则，0 间距冲突、0 未连通网络，68 网 |
| 地铜 | 四层原生重建；新增 C33/C34/U14 地孔均接触内层1主地平面 |
| 局部回流 | C33.2→新地孔 1.4224mm；C34.2→新地孔 0.9652mm；U14.4→新地孔 0.6604mm |
| Gerber 走线/地铜 | 所有有效走线 100% 覆盖；四层原生地铜均被导出铜图形覆盖（5µm 几何容差） |
| 钻孔 | 278 个圆孔含 120 过孔；全部坐标/孔径匹配；两条编码器槽孔中心/方向/宽长匹配 |
| BOM | 与当前原理图 88 位号型号/立创料号完全一致；PCB 封装 UUID 逐件一致 |
| CPL | 原生导出 88 件逐件核对位置/旋转；R2 元件记录与该导出基线完全相同；工厂表只保留 76 件 SMT |
| 电源 | 按声明负载复算压降低于 3%；3V3_IO 从 J6 供电，200mA 时最坏约 1.45% |
| 音频/关键电源脚位 | PCM5122、AP2112、TPS2553 对照厂商资料核对；470Ω/2.2nF 滤波器件已与原理图/BOM统一 |

## 制板设置

- 外形 100×100mm；四层，名义板厚 1.6mm，叠层预设 JLC04161H-7628。
- 顺序 Top / Inner1 / Inner2 / Bottom；外铜35µm、内铜15.2µm。
- Inner1 作为主要 GND 参考；信号分布 Top / Inner2 / Bottom，四层含 GND 铺铜。
- Native 主钻孔 `Drill_PTH_Through.DRL` 已含过孔；`Drill_PTH_Through_Via.DRL` 是过孔子集。审单识别子集关系，不能解释为额外120孔。
- 原生 CPL 的丝印/库角度可追溯，但料盘方向属于厂家贴装库约定，审单须核对芯片1脚预览。

## 下单与实物验收边界

源冻结未代替厂家的 DFM/SMT 预览、实时库存/报价、700元整机预算和交期确认；这些结果未在本任务中提交。尚未下单、付款或烧录。

本包仅为 Control88 控制板；6 块 Sensor14Bank、屏幕、线束、电极、电源及结构件继续由相应采购/装配任务交付。WorkBuddy 的固件构建、音高表修复另存，未因本次 PCB 修复改写。

首次上电按限流电源→5V_IN/FUSED/PROTECTED/PERIPH→3V3_IO/3V3_PERIPH/DAC_3V3→DAC I2C/时钟→AUX 的顺序验收。待实测项目：短路/静态电流、负载及屏幕启动瞬态、稳压器温升、音频噪声/失真、整机扫描和功能。当前没有实物测量或整机验收通过的结论。

## 数据手册

[PCM5122](https://www.ti.com/lit/ds/symlink/pcm5122.pdf)、[AP2112](https://www.diodes.com/assets/Datasheets/AP2112.pdf)、[TPS2553](https://www.ti.com/lit/ds/symlink/tps2553.pdf)。详见 evidence/critical-power-audio-review.json。

## 本地校验

执行 `python verify_package.py` 可用 Python 标准库核对全部文件哈希、PCB 规模和证据绑定。verification/ 内为原过程脚本快照，依赖原工作区路径、audit_saved_sensor 解析器及 Shapely；原生 DRC 证据来自嘉立创界面，便携校验不重新执行 DRC。
