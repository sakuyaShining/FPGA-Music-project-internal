"""Run with Python 3: python verify_package.py. Standard library only.

Checks archive content identity and evidence binding. It does not rerun the EDA
DRC or replace the supplier's DFM/SMT preview and physical validation.
"""
from pathlib import Path
import hashlib,json,collections
root=Path(__file__).resolve().parent
manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
for name,digest in manifest['files_sha256'].items():
 file=root/name
 assert file.is_file(),name
 assert hashlib.sha256(file.read_bytes()).hexdigest()==digest,name
pcb=root/'source/pcb/PCB1.epcb2'
assert hashlib.sha256(pcb.read_bytes()).hexdigest()==manifest['pcb_sha256']
types=collections.Counter();board=False;padnets=set()
for line in pcb.read_text(encoding='utf-8-sig').splitlines():
 if '||' not in line:continue
 a,b=line.rstrip('|').split('||',1);a,b=json.loads(a),json.loads(b)
 if a['type']=='DOCHEAD':board=b['docType']=='PCB'
 if board:
  types[a['type']]+=1
  if a['type']=='PAD_NET' and b['padNet']:padnets.add(b['padNet'])
for key,count in [('COMPONENT',88),('PAD_NET',444),('LINE',1405),('VIA',120),('POUR',4),('POURED',4)]:assert types[key]==count,(key,types[key])
assert len(padnets)==68
for name in ['r2-ground-verification.json','r2-bom-source-verification.json','r2-manufacturing-verification.json','r2-drill-verification.json','r2-power-verification.json','critical-power-audio-review.json']:
 evidence=json.loads((root/'evidence'/name).read_text(encoding='utf-8'));assert evidence['pcb_sha256']==manifest['pcb_sha256'],name
ground=json.loads((root/'evidence/r2-ground-verification.json').read_text());assert ground['all_new_vias_on_main_ground']
manufacturing=json.loads((root/'evidence/r2-manufacturing-verification.json').read_text());assert manufacturing['native_reopen_drc']['issues']==0
print('PASS: all manifest hashes, PCB source identity, 88 components / 444 pad-net records / 68 nets / 1405 lines / 120 vias, and final evidence binding.')
