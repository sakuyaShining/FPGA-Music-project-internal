from cad_audit import *
Q=O/'FPGA-Music-Control88-MANUFACTURING-REVIEW/pcb/PCB1.epcb2'
_,b=load(Q);obs=objects(b)
targets=['C33.2','C34.2','U14.4']
results=[]
for ref in targets:
 pad=next(o for o in obs if o.get('ref')==ref and o['layer']==1);cx,cy=pad['g'].centroid.coords[0];net=pad['net']
 foreign=unary=None
 from shapely.ops import unary_union
 foreign=unary_union([o['g'] for o in obs if o['net']!=net])
 top_foreign=unary_union([o['g'] for o in obs if o['net']!=net and o['layer']==1])
 all_pads=unary_union([o['g'] for o in obs if o['kind']=='PAD'])
 foreign_tree=STRtree([o['g'] for o in obs if o['net']!=net])
 top_tree=STRtree([o['g'] for o in obs if o['net']!=net and o['layer']==1])
 pad_tree=STRtree([o['g'] for o in obs if o['kind']=='PAD'])
 candidates=[]
 for diam,hole in [(24,12),(22,10),(20,10),(18,10)]:
  best=None
  for rad in range(12,61,2):
   for ang in range(0,360,5):
    x=cx+rad*math.cos(math.radians(ang));y=cy+rad*math.sin(math.radians(ang))
    via=Point(x,y).buffer(diam/2,quad_segs=32)
    if len(foreign_tree.query(via,predicate='dwithin',distance=6.5)):continue
    if len(pad_tree.query(via,predicate='dwithin',distance=6.5)):continue
    route=LineString([(cx,cy),(x,y)]).buffer(5,quad_segs=32)
    if len(top_tree.query(route,predicate='dwithin',distance=6.5)):continue
    best={'x':x,'y':y,'diameter_mil':diam,'hole_mil':hole,'distance_mm':rad*.0254};break
   if best:break
  candidates.append(best)
 results.append({'ref':ref,'net':net,'pad_center_mil':[cx,cy],'candidates':candidates})
(O/'decoupling-fix-search-20261029.json').write_text(json.dumps(results,indent=2),encoding='utf-8');print(json.dumps(results,indent=2))
