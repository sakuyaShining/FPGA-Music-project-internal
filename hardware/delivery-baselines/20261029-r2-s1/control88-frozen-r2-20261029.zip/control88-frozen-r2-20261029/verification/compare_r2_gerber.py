"""核对 Gerber 制造包与落盘 PCB 是否同源（端点级匹配）。

Gerber 会额外画出泪滴、焊盘引出等，所以不做条数相等判断，而做包含性检验：
PCB 里每一段走线，都必须能在对应层 Gerber 中找到端点一致（<=2um）且线宽一致（<=0.02mm）的绘制段。
命中率 100% 才判定该层同源。
"""
import sys, re, math, json, collections

sys.path.insert(0, 'D:/FPGA-Project/delivery-evidence-20261027/control88-routing-20261028')
from cad_audit import O, load

G = O / 'gerber-r2-inspection'
Q = O / 'FPGA-Music-Control88-GND-R2/pcb/PCB1.epcb2'
MIL = 0.0254
MAP = {1: 'Gerber_TopLayer.GTL', 2: 'Gerber_BottomLayer.GBL',
       15: 'Gerber_InnerLayer1.G1', 16: 'Gerber_InnerLayer2.G2'}
TOL_XY, TOL_W = 0.005, 0.02
MIN_LEN = 0.01   # 退化零长线段 Gerber 不绘制，不计入分母


def parse_gerber(path):
    txt = path.read_text(errors='replace')
    m = re.search(r'G04 EasyEDA Pro[^,]*, ([0-9\-: ]+)\*', txt)
    gen = m.group(1).strip() if m else None
    aps = {int(a): float(d) for a, s, d in re.findall(r'%ADD(\d+)([CRO]),([0-9.]+)', txt)}
    cur, x, y, region = None, 0.0, 0.0, False
    segs = []
    for cmd in txt.split('*'):
        cmd = cmd.strip()
        if not cmd or cmd.startswith('G04') or cmd.startswith('%'):
            continue
        if cmd == 'G36':
            region = True; continue
        if cmd == 'G37':
            region = False; continue
        dm = re.fullmatch(r'(?:G54)?D(\d+)', cmd)
        if dm:
            cur = int(dm.group(1)); continue
        m2 = re.fullmatch(r'(?:G0[123])?(?:X(-?\d+))?(?:Y(-?\d+))?D0([123])', cmd)
        if not m2:
            continue
        nx = int(m2.group(1)) / 1e5 if m2.group(1) else x
        ny = int(m2.group(2)) / 1e5 if m2.group(2) else y
        if m2.group(3) == '1' and not region:
            segs.append((x, y, nx, ny, aps.get(cur)))
        x, y = nx, ny
    return gen, segs


def key(a, b, c, d):
    p, q = (round(a, 3), round(b, 3)), (round(c, 3), round(d, 3))
    return (p, q) if p <= q else (q, p)


def on_seg(px, py, x1, y1, x2, y2, tol=TOL_XY):
    """点是否落在（共线的）Gerber 绘制段上——用于处理生成器把折线合并/拆分的情况。"""
    dx, dy = x2 - x1, y2 - y1
    L2 = dx * dx + dy * dy
    if L2 == 0:
        return False
    t = ((px - x1) * dx + (py - y1) * dy) / L2
    if t < -0.001 or t > 1.001:
        return False
    return math.hypot(px - (x1 + t * dx), py - (y1 + t * dy)) <= tol


def main():
    ds, b = load(Q)
    out = {'pcb': str(Q), 'layers': {}}
    vias = sum(1 for h, v in b['records'] if h['type'] == 'VIA')
    out['pcb_vias'] = vias
    for lid, fn in MAP.items():
        p = G / fn
        if not p.exists():
            out['layers'][lid] = {'file': fn, 'status': 'MISSING'}; continue
        gen, segs = parse_gerber(p)
        idx = collections.defaultdict(list)
        for x1, y1, x2, y2, w in segs:
            idx[key(x1, y1, x2, y2)].append(w)
        lines = [(v['startX'] * MIL, v['startY'] * MIL, v['endX'] * MIL, v['endY'] * MIL,
                  v['width'] * MIL)
                 for h, v in b['records'] if h['type'] == 'LINE' and v['layerId'] == lid]
        degenerate = sum(1 for x1, y1, x2, y2, w in lines
                         if math.hypot(x2 - x1, y2 - y1) < MIN_LEN)
        lines = [l for l in lines if math.hypot(l[2] - l[0], l[3] - l[1]) >= MIN_LEN]
        hit = 0
        exact = 0
        miss = []
        for x1, y1, x2, y2, w in lines:
            k = key(x1, y1, x2, y2)
            ok = any(c is not None and abs(c - w) <= TOL_W for c in idx.get(k, []))
            if ok:
                exact += 1
            if not ok:
                for gx1, gy1, gx2, gy2, gw in segs:
                    if gw is None or abs(gw - w) > TOL_W:
                        continue
                    if on_seg(x1, y1, gx1, gy1, gx2, gy2) and on_seg(x2, y2, gx1, gy1, gx2, gy2):
                        ok = True
                        break
            if ok:
                hit += 1
            elif len(miss) < 5:
                miss.append([round(v, 3) for v in (x1, y1, x2, y2, w)])
        out['layers'][lid] = {
            'file': fn, 'gerber_generated': gen,
            'pcb_lines': len(lines), 'degenerate_skipped': degenerate,
            'gerber_draws': len(segs),
            'matched': hit, 'exact_endpoint_matched': exact,
            'match_pct': round(100.0 * hit / len(lines), 2) if lines else 100.0,
            'same_source': hit == len(lines), 'miss_samples': miss,
        }
    drl = G / 'Drill_PTH_Through_Via.DRL'
    holes = 0
    if drl.exists():
        holes = len(re.findall(r'^X[-\d.]+Y[-\d.]+$', drl.read_text(errors='replace'), re.M))
    out['drill_via_holes'] = holes
    out['via_count_match'] = holes == vias
    out['all_layers_same_source'] = all(v.get('same_source') for v in out['layers'].values())
    (O / 'r2-gerber-samesource-check.json').write_text(
        json.dumps(out, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(out, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
