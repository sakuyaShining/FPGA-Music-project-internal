from cad_audit import *
from shapely.ops import unary_union
from shapely.geometry import box
import ast,csv
q=O/'FPGA-Music-Control88-GND-R2/pcb/PCB1.epcb2';_,b=load(q)
s=ast.parse((O/'final_electrical_audit.py').read_text(encoding='utf-8'));exec(compile(ast.Module(body=[n for n in s.body if isinstance(n,ast.FunctionDef) and n.name=='points'],type_ignores=[]),'<points>','exec'))
G=O/'gerber-r2-inspection';pours={h['id']:v for h,v in b['records'] if h['type']=='POUR'};planes={}
for h,po in b['records']:
 if h['type']!='POURED':continue
 layer=pours[json.loads(h['id'])[1]]['layerId'];cu=[]
 for f in po['pourFill']:
  if f['fill']:
   g=Polygon(points(f['path'][0]))
   for pp in f['path'][1:]:g=g.symmetric_difference(Polygon(points(pp)))
  else:g=LineString(points(f['path'])).buffer(f['strokeWidth']*5,quad_segs=64)
  cu.append(g)
 planes[layer]=unary_union(cu)
def gerber_regions(file):
 text=file.read_text();assert not re.search(r'G0[23]|%LP',text)
 aps={int(a):(shape,list(map(float,d.split('X')))) for a,shape,d in re.findall(r'%ADD(\d+)([CRO]),([0-9.X]+)',text)}
 regions=[];paths=[];path=[];active=False;x=y=0;ap=None
 for token in text.split('*'):
  t=token.strip()
  if t=='G36':active=True;paths=[];path=[];continue
  if t=='G37':
   if path:paths.append(path)
   g=None
   for p in paths:
    if len(p)<3:continue
    pg=Polygon(p).buffer(0);g=pg if g is None else g.symmetric_difference(pg)
   if g is not None:regions.append(g)
   active=False;continue
  dm=re.fullmatch(r'(?:G54)?D(\d+)',t)
  if dm:ap=int(dm[1]);continue
  m=re.fullmatch(r'(?:G01)?(?:X(-?\d+))?(?:Y(-?\d+))?D0([123])',t)
  if m:
   nx=float(m[1])/1e5 if m[1] else x;ny=float(m[2])/1e5 if m[2] else y
   if active:
    if m[3]=='2':
     if path:paths.append(path)
     path=[(nx,ny)]
    else:path.append((nx,ny))
   elif m[3]=='1':
    shape,d=aps[ap];assert shape=='C',(shape,d)
    regions.append(LineString([(x,y),(nx,ny)]).buffer(d[0]/2,quad_segs=64))
   elif m[3]=='3':
    shape,d=aps[ap]
    if shape=='C':g=Point(nx,ny).buffer(d[0]/2,quad_segs=64)
    elif shape=='R':g=box(nx-d[0]/2,ny-d[1]/2,nx+d[0]/2,ny+d[1]/2)
    else:
     w,h=d[:2];rad=min(w,h)/2
     g=LineString([(nx-max(0,w-h)/2,ny-max(0,h-w)/2),(nx+max(0,w-h)/2,ny+max(0,h-w)/2)]).buffer(rad,quad_segs=64)
    regions.append(g)
   x,y=nx,ny
 return unary_union(regions)
from shapely.affinity import scale
plane_results={}
for lid,name in [(1,'TopLayer.GTL'),(15,'InnerLayer1.G1'),(16,'InnerLayer2.G2'),(2,'BottomLayer.GBL')]:
 copper=gerber_regions(G/('Gerber_'+name));native=scale(planes[lid],xfact=.0254,yfact=.0254,origin=(0,0))
 missed=native.difference(copper.buffer(.005)).area
 assert missed<.001,(lid,missed)
 plane_results[lid]={'native_pour_area_mm2':native.area,'gerber_region_area_mm2':copper.area,'native_pour_uncovered_at_5um_tolerance_mm2':missed}
native_vias=[(v['centerX']*.0254,v['centerY']*.0254) for h,v in b['records'] if h['type']=='VIA']
holes=[(float(x),float(y)) for x,y in re.findall(r'^X(-?[\d.]+)Y(-?[\d.]+)$',(G/'Drill_PTH_Through_Via.DRL').read_text(),re.M)]
assert len(native_vias)==len(holes)==120
unmatched=holes.copy();drill_errors=[]
for v in native_vias:
 nearest=min(unmatched,key=lambda h:math.dist(v,h));err=math.dist(v,nearest);assert err<.00002,(v,nearest,err);drill_errors.append(err);unmatched.remove(nearest)
assert 'X10000000Y10000000' in (G/'Gerber_BoardOutlineLayer.GKO').read_text()
_,old=load(O/'FPGA-Music-Control88-MANUFACTURING-REVIEW/pcb/PCB1.epcb2')
for typ in ['COMPONENT','PAD_NET','RULE','LAYER_PHYS','POLY']:
 assert {h.get('id'):v for h,v in b['records'] if h['type']==typ}=={h.get('id'):v for h,v in old['records'] if h['type']==typ},typ
r={'pcb_sha256':hashlib.sha256(q.read_bytes()).hexdigest(),'ground_pours_covered_by_actual_gerber_regions':plane_results,'all_120_drill_coordinates_match':True,'component_geometry_attrs_padnets_rules_stackup_outline_equal_native_CPL_verified_baseline':True,'CPL_inheritance':'All COMPONENT and PAD_NET records identical; original native CPL export and 76 SMT CSV remain valid for R2.','native_reopen_drc':{'issues':0,'check_items':141,'timestamp':'2026-10-29 08:35:13','evidence':'native-drc-r2-reopened-20261029.txt'}}
(O/'r2-manufacturing-verification.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
