"""Control88 冻结源独立复验 + 电源压降(IR drop)判定。

不依赖 EDA 原生 DRC，直接对落盘 PCB1.epcb2 做几何与电学复算：
  1) 间距 / 连通性（与 final_electrical_audit.py 同一套判据）
  2) 每个电源网络：从源器件焊盘出发的最坏路径电阻（含过孔）
  3) 按 3% 压降预算给出该网络允许的最大负载电流

坐标单位 mil，线宽 mil；铜厚 外层 35um / 内层 15.2um；过孔按 1.2mOhm 计。
"""
import sys, json, math, heapq, collections

sys.path.insert(0, 'D:/FPGA-Project/delivery-evidence-20261027/control88-routing-20261028')
from cad_audit import O, load, objects, audit


def records(board, typ):
    return {h.get('id'): v for h, v in board['records'] if h['type'] == typ}

Q = O / 'FPGA-Music-Control88-GND-R2/pcb/PCB1.epcb2'
RHO = 0.01724          # Ohm*mm^2/m @20C
T_OUTER = 0.035        # mm
T_INNER = 0.0152       # mm
R_VIA = 1.2e-3         # Ohm, 12mil 孔 / 24mil 盘 贯通孔估算
MIL = 0.0254           # mm per mil

# 源器件（供出电流的一端）
SOURCES = {
    '5V_IN': 'J13', '5V_FUSED': 'F1', '5V_PROTECTED': 'Q1',
    '5V_PERIPH': 'U17', '3V3_IO': 'J6', '3V3_PERIPH': 'U18',
    'DAC_3V3': 'U13', 'AUX_L': 'R41', 'AUX_R': 'R42',
}
NOMINAL = {'5V_IN': 5.0, '5V_FUSED': 5.0, '5V_PROTECTED': 5.0,
           '5V_PERIPH': 5.0, '3V3_IO': 3.3, '3V3_PERIPH': 3.3, 'DAC_3V3': 3.3}
# 声明式负载估计（用于判定，不代表实测）
EST_LOAD = {'5V_IN': 0.50, '5V_FUSED': 0.50, '5V_PROTECTED': 0.50,
            '5V_PERIPH': 0.35, '3V3_IO': 0.20, '3V3_PERIPH': 0.05, 'DAC_3V3': 0.03}
BUDGET = 0.03          # 3% 压降预算


def seg_R(width_mil, length_mil, layer):
    t = T_OUTER if layer in (1, 2) else T_INNER
    L_mm = length_mil * MIL
    A_mm2 = (width_mil * MIL) * t
    return RHO * (L_mm / 1000.0) / A_mm2


def build_graph(lines, vias, net, pads=(), split=True):
    """返回 (节点集, 邻接表)。节点 = (layer, x, y)。"""
    segs = [(v['layerId'], float(v['startX']), float(v['startY']),
             float(v['endX']), float(v['endY']), float(v['width']))
            for v in lines.values() if v['netName'] == net]

    def rnd(a):
        return round(a, 2)

    if split:
        # 把落在其它线段内部的端点拆成 T 型接点
        extra = collections.defaultdict(list)
        for layer, x1, y1, x2, y2, w in segs:
            for layer2, a1, b1, a2, b2, _ in segs:
                if layer != layer2:
                    continue
                dx, dy = a2 - a1, b2 - b1
                L2 = dx * dx + dy * dy
                if L2 == 0:
                    continue
                for (px, py) in ((x1, y1), (x2, y2)):
                    t = ((px - a1) * dx + (py - b1) * dy) / L2
                    if 0.0 < t < 1.0:
                        cx, cy = a1 + t * dx, b1 + t * dy
                        if math.hypot(px - cx, py - cy) < 0.05:
                            extra[(layer, a1, b1, a2, b2, w)].append((cx, cy))
        new = []
        for k, pts in extra.items():
            layer, a1, b1, a2, b2, w = k
            dx, dy = a2 - a1, b2 - b1
            L2 = dx * dx + dy * dy
            pts.sort(key=lambda p: ((p[0] - a1) * dx + (p[1] - b1) * dy) / L2)
            chain = [(a1, b1)] + pts + [(a2, b2)]
            for i in range(len(chain) - 1):
                new.append((layer, chain[i][0], chain[i][1], chain[i + 1][0], chain[i + 1][1], w))
        segs.extend(new)

    adj = collections.defaultdict(list)
    for layer, x1, y1, x2, y2, w in segs:
        n1, n2 = (layer, rnd(x1), rnd(y1)), (layer, rnd(x2), rnd(y2))
        if n1 == n2:
            continue
        r = seg_R(w, math.hypot(x2 - x1, y2 - y1), layer)
        adj[n1].append((n2, r)); adj[n2].append((n1, r))

    layers = (1, 15, 16, 2)
    for v in vias.values():
        if v['netName'] != net:
            continue
        x, y = rnd(float(v['centerX'])), rnd(float(v['centerY']))
        for i in range(len(layers) - 1):
            n1, n2 = (layers[i], x, y), (layers[i + 1], x, y)
            adj[n1].append((n2, R_VIA)); adj[n2].append((n1, R_VIA))

    # 焊盘铜箔连通：同一焊盘内端点视为同电位；通孔焊盘跨层连通
    from shapely.geometry import Point
    for _pid, shapes in pads:
        members = []
        for layer, g in shapes:
            members += [n for n in adj if n[0] == layer and g.distance(Point(n[1], n[2])) < 0.6]
        for i in range(1, len(members)):
            adj[members[0]].append((members[i], 1e-7))
            adj[members[i]].append((members[0], 1e-7))
    return adj


def dijkstra(adj, src):
    dist = {src: 0.0}
    pq = [(0.0, src)]
    prev = {}
    while pq:
        d, u = heapq.heappop(pq)
        if d > dist.get(u, 1e18):
            continue
        for v, w in adj.get(u, ()):
            nd = d + w
            if nd < dist.get(v, 1e18):
                dist[v] = nd; prev[v] = u; heapq.heappush(pq, (nd, v))
    return dist, prev


def components(adj):
    seen, comp = set(), 0
    for s in adj:
        if s in seen:
            continue
        comp += 1; stack = [s]; seen.add(s)
        while stack:
            u = stack.pop()
            for v, _ in adj.get(u, ()):
                if v not in seen:
                    seen.add(v); stack.append(v)
    return comp


def main():
    import hashlib
    ds, b = load(Q)
    sha = hashlib.sha256(Q.read_bytes()).hexdigest()
    lines = records(b, 'LINE'); vias = records(b, 'VIA')
    obs = objects(b)

    pad_pts = collections.defaultdict(list)
    pad_geo = collections.defaultdict(lambda: collections.defaultdict(list))
    for o in obs:
        if o['kind'] == 'PAD' and o['net']:
            c = o['g'].centroid
            pad_pts[o['net']].append((o['ref'], c.x, c.y))
            pad_geo[o['net']][o['id']].append((o['layer'], o['g']))

    report = {'pcb_path': str(Q), 'pcb_sha256': sha,
              'lines': len(lines), 'vias': len(vias),
              'trace_check': audit(b), 'power': {}}

    for net, ref in SOURCES.items():
        adj = build_graph(lines, vias, net, list(pad_geo.get(net, {}).items()))
        if not adj:
            report['power'][net] = {'status': 'NO_COPPER'}
            continue
        cands = [(n, x, y) for n, x, y in pad_pts.get(net, []) if n.split('.')[0] == ref]
        if not cands:
            report['power'][net] = {'status': 'SOURCE_PAD_NOT_FOUND', 'src_ref': ref}
            continue
        _, sx, sy = cands[0]
        src = min(adj, key=lambda n: math.hypot(n[1] - sx, n[2] - sy))
        dist, prev = dijkstra(adj, src)
        far = max(dist, key=lambda k: dist[k])
        rmax = dist[far]
        # 回溯最坏路径
        path, cur = [], far
        while cur in prev:
            path.append(cur); cur = prev[cur]
        path.append(cur); path.reverse()
        via_n = sum(1 for a, c in zip(path, path[1:]) if a[0] != c[0])
        length = 0.0
        for a, c in zip(path, path[1:]):
            if a[0] == c[0]:
                length += math.hypot(a[1] - c[1], a[2] - c[2]) * MIL
        vnom = NOMINAL.get(net)
        est = EST_LOAD.get(net)
        entry = {
            'src_ref': ref, 'src_node': list(src), 'worst_sink_node': list(far),
            'worst_path_resistance_ohm': round(rmax, 5),
            'worst_path_length_mm': round(length, 2),
            'vias_on_worst_path': via_n,
            'graph_components': components(adj),
            'reachable_nodes': len(dist),
            'total_nodes': len(adj),
        }
        if vnom:
            entry['nominal_v'] = vnom
            entry['drop_mV_at'] = {f'{int(i*1000)}mA': round(rmax * i * 1000, 1)
                                   for i in (0.1, 0.2, 0.3, 0.5)}
            entry['drop_pct_at_est_load'] = round(rmax * est / vnom * 100, 2)
            entry['est_load_A'] = est
            entry['max_load_A_for_3pct'] = round(vnom * BUDGET / rmax, 3)
            entry['verdict'] = 'PASS' if rmax * est / vnom <= BUDGET else 'FAIL'
        report['power'][net] = entry

    out = O / 'r2-power-verification.json'
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('sha256', sha)
    print('lines', len(lines), 'vias', len(vias))
    tc = report['trace_check']
    print('clearance_errors', len(tc['clearance_errors']), 'unconnected', tc['unconnected_nets'],
          'nets', tc['net_count'])
    for n, e in report['power'].items():
        if 'verdict' in e:
            print(f"{n:14s} R={e['worst_path_resistance_ohm']:.4f}ohm "
                  f"L={e['worst_path_length_mm']:.1f}mm via={e['vias_on_worst_path']} "
                  f"comp={e['graph_components']} "
                  f"drop@{e['est_load_A']*1000:.0f}mA={e['drop_pct_at_est_load']:.2f}% "
                  f"Imax3%={e['max_load_A_for_3pct']:.3f}A {e['verdict']}")
        else:
            print(f"{n:14s} R={e['worst_path_resistance_ohm']:.4f}ohm "
                  f"L={e['worst_path_length_mm']:.1f}mm via={e['vias_on_worst_path']} "
                  f"comp={e['graph_components']} (非电源轨，仅报电阻)")


if __name__ == '__main__':
    main()
