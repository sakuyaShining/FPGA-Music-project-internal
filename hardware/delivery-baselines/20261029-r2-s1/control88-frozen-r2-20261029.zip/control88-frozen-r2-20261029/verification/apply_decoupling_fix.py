from cad_audit import *
import shutil,uuid
base=O/'FPGA-Music-Control88-MANUFACTURING-REVIEW';rev=O/'FPGA-Music-Control88-GND-R2'
assert not rev.exists();src=base/'pcb/PCB1.epcb2'
assert hashlib.sha256(src.read_bytes()).hexdigest()=='9df45cdcfe1ebe9ddf2f7aba495cc9e64a734b2ffb44d998ae58f01faa2fabca'
shutil.copytree(base,rev,ignore=shutil.ignore_patterns('*backup*','*.bak'))
prof=next(rev.glob('*.eprj3'));data=json.loads(prof.read_text(encoding='utf-8-sig'));data['name']=rev.name
(rev/(rev.name+'.eprj3')).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
# Preserve copied profile as provenance; open only the new named profile.
ds,b=load(src);vt=next(v for h,v in b['records'] if h['type']=='VIA');lt=next(v for h,v in b['records'] if h['type']=='LINE')
b['records']=[(h,v) for h,v in b['records'] if h['type']!='POURED'];ticket=max(h.get('ticket',0) for d in ds for h,v in d['records']);changes=[]
for row in json.loads((O/'decoupling-fix-search-20261029.json').read_text()):
 assert row['net']=='GND';c=row['candidates'][0];assert c and c['diameter_mil']==24
 x,y=round(c['x'],3),round(c['y'],3);px,py=row['pad_center_mil'];ticket+=1;vid=uuid.uuid4().hex[:16]
 b['records'].append(({'type':'VIA','id':vid,'ticket':ticket},{**vt,'netName':'GND','centerX':x,'centerY':y,'viaDiameter':24,'holeDiameter':12}))
 ticket+=1;b['records'].append(({'type':'LINE','id':uuid.uuid4().hex[:16],'ticket':ticket},{**lt,'netName':'GND','layerId':1,'startX':px,'startY':py,'endX':x,'endY':y,'width':10}))
 changes.append({'ref':row['ref'],'via_id':vid,'via_center_mil':[x,y],'pad_to_via_mm':math.hypot(x-px,y-py)*.0254})
r=audit(b);assert not r['clearance_errors'] and not r['unconnected_nets'],r
out=rev/'pcb/PCB1.epcb2';out.write_text('\n'.join(json.dumps(h,ensure_ascii=False,separators=(',',':'))+'||'+json.dumps(v,ensure_ascii=False,separators=(',',':'))+'|' for d in ds for h,v in d['records'])+'\n',encoding='utf-8')
report={'base_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'revision_pcb':str(out),'revision_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'changes':changes,'independent_audit':r,'native_pour_rebuild_and_DRC_pending':True}
(O/'decoupling-fix-r2.json').write_text(json.dumps(report,indent=2),encoding='utf-8');print(json.dumps(report,indent=2))
