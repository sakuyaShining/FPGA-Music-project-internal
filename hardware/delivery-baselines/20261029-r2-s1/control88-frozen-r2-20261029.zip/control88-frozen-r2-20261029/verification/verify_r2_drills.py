from cad_audit import *
ds,b=load(O/'FPGA-Music-Control88-GND-R2/pcb/PCB1.epcb2');libs={d['head']['uuid']:d for d in ds};at=collections.defaultdict(dict)
for h,v in b['records']:
 if h['type']=='ATTR':at[v['parentId']][v['key']]=v['value']
expected=[];slots=[]
for h,c in b['records']:
 if h['type']=='VIA':expected.append((c['centerX']*.0254,c['centerY']*.0254,c['holeDiameter']*.0254));continue
 if h['type']!='COMPONENT':continue
 theta=math.radians(c['angle']);co,si=math.cos(theta),math.sin(theta)
 for hh,p in libs[at[h['id']]['Footprint']]['records']:
  hole=p.get('hole') if hh['type']=='PAD' else None
  if not hole or hole['width']<=0:continue
  pa=math.radians(p['padAngle']);ox=p.get('padOffsetX',0) or 0;oy=p.get('padOffsetY',0) or 0
  x=p['centerX']+ox*math.cos(pa)-oy*math.sin(pa);y=p['centerY']+ox*math.sin(pa)+oy*math.cos(pa)
  gx=(c['x']+x*co-y*si)*.0254;gy=(c['y']+x*si+y*co)*.0254
  if hole['holeType']=='ROUND':expected.append((gx,gy,hole['width']*.0254))
  else:slots.append({'ref':at[h['id']]['Designator']+'.'+p['num'],'center_mm':[gx,gy],'size_mm':[hole['width']*.0254,hole['height']*.0254],'angle':c['angle']+p['padAngle']})
txt=(O/'gerber-r2-inspection/Drill_PTH_Through.DRL').read_text();toolsizes={int(n):float(d) for n,d in re.findall(r'^T(\d+)C([\d.]+)$',txt,re.M)};tool=None;actual=[];actual_slots=[]
for l in txt.splitlines():
 t=re.fullmatch(r'T(\d+)',l)
 if t:tool=int(t[1]);continue
 m=re.fullmatch(r'X(-?[\d.]+)Y(-?[\d.]+)',l)
 if m:actual.append((float(m[1]),float(m[2]),toolsizes[tool]));continue
 if 'G85' in l:actual_slots.append({'command':l,'tool_diameter_mm':toolsizes[tool]})
assert len(expected)==len(actual),(len(expected),len(actual));remain=actual.copy();maxerr=0
for a in expected:
 q=min(remain,key=lambda x:math.dist(a,x));err=math.dist(a,q);assert err<.00003,(a,q,err);maxerr=max(maxerr,err);remain.remove(q)
assert len(slots)==len(actual_slots)==2
for native,actual_slot in zip(slots,actual_slots):
 a,bx,c,d=map(float,re.fullmatch(r'X(-?[\d.]+)Y(-?[\d.]+)G85X(-?[\d.]+)Y(-?[\d.]+)',actual_slot['command']).groups())
 diameter=actual_slot['tool_diameter_mm'];cx,cy=native['center_mm'];length,width=native['size_mm']
 assert math.dist([(a+c)/2,(bx+d)/2],[cx,cy])<.00003
 assert abs(diameter-width)<.00003 and abs(math.hypot(c-a,d-bx)+diameter-length)<.00003
 assert abs(a-c)<.00003 and native['angle']==90
r={'pcb_sha256':hashlib.sha256((O/'FPGA-Music-Control88-GND-R2/pcb/PCB1.epcb2').read_bytes()).hexdigest(),'round_drills_including_vias':len(expected),'round_drill_coordinates_and_diameters_match':True,'maximum_3D_xyzdiameter_match_error_mm':maxerr,'native_slots':slots,'gerber_slots':actual_slots,'note':'Main PTH drill includes all 120 vias. The separate Via.DRL is a native subset, not an additional 120 holes.'};(O/'r2-drill-verification.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r,indent=2))
