# build.tcl -- headless build for the Control88 board top
# Usage: gw_sh.exe build.tcl   (cwd = q4-firmware/)
#
# NOTE (2026-10-29): pins 51/54/55/56 are the dedicated SSPI group on GW2AR-18.
# Without -use_sspi_as_gpio the placer refuses them with
#   "cannot be placed according to constraint, for the location is a dedicated pin (SSPI)"
# and this happens even for the project's own tdm_ship + tdm_top.cst
# (verified by the control build control_tdm_ship.gprj). So the option is
# mandatory for any board that uses the I2S pins.

set proj "control88.gprj"

open_project $proj
puts "== project opened: $proj =="

set_option -use_sspi_as_gpio 1

run syn
puts "== synthesis done =="

run pnr
puts "== pnr done =="

run close
puts "== build finished =="
