//=============================================================================
// c88_spi.v —— Control88 共享三线总线位引擎
//
// 【为什么是"共享"】
//   Control88 上 FPGA 只有三根线（BUS_SCK=27 / BUS_MOSI=15 / BUS_RETURN=28）
//   同时服务两类完全不同的器件：
//     · 74HC595 (U8)  —— 写：ADDR0-3 / MUX_DISABLE / RC_DRIVE / LCD_RESET_N / TP_RESET_N
//     · 74HC165 (U9+UX1) —— 读：按键、拨轮、编码器、编辑键
//     · 屏 (J10) —— 经 U15 电平转换，SCK/MOSI 直通，MISO 与 165 输出在 U11 二选一
//   依据：control88-netlist.json（BUS_SCK/BUS_MOSI/BUS_RETURN 的成员表）
//
// 【时序】SCK 空闲低；595 与 165 都在上升沿采样，故 MOSI 在 SCK 低电平期间建立。
//         返回线默认在**上升沿之前**采样（SAMPLE_PHASE=0）：74HC165 装载后 Q7 立即
//         等于 D7，每个上升沿把输出往前推一位，所以"沿前取"才取得到当前位；
//         若在沿后取，整串数据会整体错一位（tb_sr165 抓到过，已修正）。
//=============================================================================
`timescale 1ns/1ps

module c88_spi #(
    parameter integer DIV = 8,           // 半周期拍数：27MHz / (2*8) ≈ 1.69 MHz
    // 采样相位。0 = 在 SCK 上升沿**之前**取（74HC165 的语义：装载后 Q7 立刻等于 D7，
    // 每个上升沿把输出往前推一位，所以在沿前取到的才是当前位）。
    // 1 = 在上升沿之后取（标准 SPI mode0 从机，留给将来的屏驱动）。
    parameter integer SAMPLE_PHASE = 0
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        start,
    input  wire [15:0] mo,               // 待发位（高位先出）
    input  wire [4:0]  nbits,            // 8 或 16
    input  wire        sample,            // 1 = 采样返回线

    output reg         busy,
    output reg         done,
    output reg         sck,
    output reg         mosi,
    input  wire        miso,
    output reg  [15:0] mi
);

    localparam S_IDLE = 2'd0, S_SETUP = 2'd1, S_HIGH = 2'd2, S_LOW = 2'd3;

    reg [1:0]  st;
    reg [4:0]  idx;                      // 当前位下标（从 nbits-1 递减）
    reg [15:0] sh;                       // 发送移位寄存器
    reg [15:0] rx;
    reg [7:0]  div;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; busy <= 1'b0; done <= 1'b0;
            sck <= 1'b0; mosi <= 1'b0; mi <= 16'd0;
            idx <= 5'd0; sh <= 16'd0; rx <= 16'd0; div <= 8'd0;
        end else begin
            done <= 1'b0;
            case (st)
                S_IDLE: begin
                    sck <= 1'b0;
                    if (start && nbits != 5'd0) begin
                        sh  <= mo;
                        idx <= nbits - 5'd1;
                        busy <= 1'b1;
                        rx <= 16'd0;
                        st <= S_SETUP;
                    end
                end
                // MOSI 在 SCK 低电平期间建立
                S_SETUP: begin
                    mosi <= sh[idx];
                    div  <= 8'd0;
                    // [BEFORE-FIX] 不在沿前采样
                    st   <= S_HIGH;
                end
                S_HIGH: begin
                    sck <= 1'b1;
                    if (div == DIV[7:0] - 8'd1) begin
                        div <= 8'd0;
                        // [BEFORE-FIX] 在 SCK 高电平末端采样
                        if (sample) rx[idx] <= miso;
                        st <= S_LOW;
                    end else begin
                        div <= div + 8'd1;
                    end
                end
                S_LOW: begin
                    sck <= 1'b0;
                    if (div == DIV[7:0] - 8'd1) begin
                        div <= 8'd0;
                        if (idx == 5'd0) begin
                            busy <= 1'b0; done <= 1'b1; mi <= rx;
                            st <= S_IDLE;
                        end else begin
                            idx <= idx - 5'd1;
                            st  <= S_SETUP;
                        end
                    end else begin
                        div <= div + 8'd1;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end

endmodule
