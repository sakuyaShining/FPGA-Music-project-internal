//=============================================================================
// tb_sr165.v —— 165 级联链读回位序定向测试
//
// 判据：
//   T1 读回的 keys[15:0] 必须等于 {U9.D[7:0], UX1.D[7:0]}
//      （U9 先出，D7 最先）
//   T2 链完整性哨位：UX1.D4..D0 在本板接 3V3_IO 恒为 1，
//      若这几位不是全 1，说明链序/位数错了
//   T3 SH/LD 必须在 16 拍之前拉低完成装载，且装载期间 SCK 保持低
//
// 用法: iverilog -o tb_sr165.vvp tb_sr165.v tb_models.v ../rtl/c88_sr165.v ../rtl/c88_spi.v
//=============================================================================
`timescale 1ns/1ps

module tb_sr165;
    localparam integer DIV    = 4;
    localparam integer LOAD_W = 4;

    reg clk = 1'b0, rst_n = 1'b0;
    always #18.5 clk = ~clk;

    reg         start = 1'b0;
    wire        busy, done, sck, mosi, load_n;
    wire [15:0] keys;

    reg  [7:0] u9_d  = 8'h5A;
    reg  [7:0] ux1_d = 8'hA3;
    wire       q7;

    model_hc165_chain u_chain (
        .cp(sck), .shld_n(load_n), .u9_d(u9_d), .ux1_d(ux1_d), .q7(q7)
    );

    c88_sr165 #(.DIV(DIV), .LOAD_W(LOAD_W)) dut (
        .clk(clk), .rst_n(rst_n), .start(start), .busy(busy), .done(done),
        .keys(keys), .sck(sck), .mosi(mosi), .load_n(load_n), .miso(q7)
    );

    // 装载期间 SCK 必须为低
    integer sck_during_load = 0;
    always @(posedge clk) if (!load_n && sck) sck_during_load <= sck_during_load + 1;

    integer   nclk = 0;
    always @(posedge sck) nclk <= nclk + 1;

    integer errors = 0;

    task run_read(input [7:0] a, input [7:0] b);
        reg [15:0] exp_val;
        begin
            u9_d = a; ux1_d = b;
            exp_val = {a, b};
            nclk = 0; sck_during_load = 0;
            @(posedge clk); start <= 1'b1;
            @(posedge clk); start <= 1'b0;
            wait (done === 1'b1);
            #100;

            $display("  U9.D=%b UX1.D=%b -> keys=%b (期望 %b) clk=%0d",
                     a, b, keys, exp_val, nclk);

            if (keys !== exp_val) begin
                $display("  [FAIL T1] 读回 %h != 期望 %h", keys, exp_val);
                errors = errors + 1;
            end else
                $display("  [ ok  T1] 16 位对齐");

            if (keys[4:0] !== 5'b11111) begin
                $display("  [FAIL T2] 链哨位 keys[4:0]=%b 非全 1（链序错或位数错）", keys[4:0]);
                errors = errors + 1;
            end else
                $display("  [ ok  T2] 链哨位全 1");

            if (sck_during_load != 0) begin
                $display("  [FAIL T3] SH/LD 低电平期间 SCK 有 %0d 拍高电平", sck_during_load);
                errors = errors + 1;
            end else
                $display("  [ ok  T3] 装载期间 SCK 保持低");

            if (nclk != 16) begin
                $display("  [FAIL T3] 时钟数 %0d != 16", nclk);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $dumpfile("tb_sr165.vcd");
        $dumpvars(0, tb_sr165);
        repeat (4) @(posedge clk);
        rst_n <= 1'b1;
        repeat (2) @(posedge clk);

        $display("=== 165 级联链位序测试 ===");
        run_read(8'h5A, 8'hBF);   // UX1 低 5 位必须为 1（哨位）
        run_read(8'hFF, 8'hFF);   // 全部未按
        run_read(8'h7F, 8'hFF);   // 只按 EDIT（U9.D7=0）
        run_read(8'hFE, 8'hFF);   // 只按 U9.D0（ENC_A）

        if (errors == 0) $display("RESULT: PASS (tb_sr165)");
        else             $display("RESULT: FAIL (tb_sr165) errors=%0d", errors);
        $finish;
    end

    initial begin
        #500000;
        $display("RESULT: FAIL (tb_sr165) timeout");
        $finish;
    end
endmodule
