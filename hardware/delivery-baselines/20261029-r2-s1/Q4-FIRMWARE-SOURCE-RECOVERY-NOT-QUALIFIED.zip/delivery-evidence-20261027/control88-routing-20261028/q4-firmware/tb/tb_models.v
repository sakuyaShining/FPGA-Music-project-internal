//=============================================================================
// tb_models.v —— 74HC595 / 74HC165 行为模型（供 testbench 用，非综合）
//
// 【建模依据】只依据器件手册的移位语义，不依据本项目 RTL 的注释：
//   74HC595：8 级移位寄存器，SER 进第一级(QA)，QH 为最后一级。
//            ⇒ 第 1 个移入的位最后停在 QH，最后移入的位停在 QA。
//            ⇒ RCLK 上升沿把移位寄存器并行拷到输出锁存。
//   74HC165：8 级并行装载移位寄存器，D7 装到输出级(Q7)。
//            ⇒ 装载后 Q7 立即等于 D7（**在第一个时钟沿之前**就有效）。
//            ⇒ 每个 CP 上升沿 Q7 变成 D6、D5……即输出在时钟沿后"前进一位"。
//            ⇒ 级联时 U9.DS <- UX1.Q7，等效 16 位移位链 {U9[7:0], UX1[7:0]}。
//   这条"沿后前进一位"的语义是本 testbench 的核心：它决定了主机必须在
//   第一个时钟沿**之前**取到 D7，否则整串数据会整体错一位。
//=============================================================================
`timescale 1ns/1ps

//------------------------------------------------------------------ 74HC595
module model_hc595 (
    input  wire       srclk,     // pin11 上升沿移位
    input  wire       rclk,      // pin12 上升沿锁存
    input  wire       ser,       // pin14
    input  wire       srclr_n,   // pin10，低清移位寄存器
    output reg  [7:0] q          // q[0]=QA ... q[7]=QH
);
    always @(posedge srclk or negedge srclr_n) begin
        if (!srclr_n) q <= 8'h00;
        else          q <= {q[6:0], ser};   // QA<=SER, QB<=QA, ... QH<=QG
    end

    reg [7:0] latched;
    always @(posedge rclk) latched <= q;
    initial latched = 8'h00;

    // 对外可见的输出（锁存后）
    wire [7:0] dout = latched;
endmodule

//------------------------------------------------------------------ 74HC165 x2
module model_hc165_chain (
    input  wire        cp,        // pin2 时钟，上升沿移位
    input  wire        shld_n,    // pin1 装载，低有效（电平装载）
    input  wire  [7:0] u9_d,      // U9 的 D7..D0
    input  wire  [7:0] ux1_d,     // UX1 的 D7..D0
    output wire        q7        // U9.Q7 -> BUS_RETURN
);
    // chain[15] = U9.D7（先出），chain[0] = UX1.D0（最后出）
    reg [15:0] chain;

    always @(posedge cp) chain <= {chain[14:0], 1'b0};
    always @(shld_n)     if (!shld_n) chain <= {u9_d, ux1_d};

    initial chain = 16'h0000;

    // 器件特性：Q7 就是输出级的当前值，装载后立刻等于 D7
    assign q7 = chain[15];
endmodule
