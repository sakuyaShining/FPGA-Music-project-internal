//=============================================================================
// c88_sr595.v —— 74HC595 (U8) 输出帧 + SCAN_LATCH 锁存
//
// 【位序怎么来的】U8 逐脚网络（control88-netlist.json）与 74HC595 标准脚位对照：
//     pin11 SRCLK <- BUS_SCK          pin12 RCLK <- SCAN_LATCH
//     pin14 SER   <- BUS_MOSI         pin15 QA   -> ADDR0
//     pin1  QB -> ADDR1               pin2  QC   -> ADDR2
//     pin3  QD -> ADDR3               pin4  QE   -> MUX_DISABLE
//     pin5  QF -> RC_DRIVE            pin6  QG   -> LCD_RESET_N
//     pin7  QH -> TP_RESET_N          pin10 SRCLR -> 3V3_IO（常清允许）
//     pin13 OE -> GND（常使能）        pin9  QH' -> 未接
//   ⇒ 595 的 QA 是**最后**移入的位，QH 是**最先**移入的位。
//     所以要写 ctl[0]=ADDR0 到 QA，必须把 ctl 按 bit7..bit0 顺序移出。
//
// ctl 位定义：ctl[3:0]=ADDR0..ADDR3, [4]=MUX_DISABLE, [5]=RC_DRIVE,
//             [6]=LCD_RESET_N, [7]=TP_RESET_N
//=============================================================================
`timescale 1ns/1ps

module c88_sr595 #(
    parameter integer DIV      = 8,
    parameter integer LATCH_W  = 4          // RCLK 脉冲宽度（拍）
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        load,                // 一拍请求：把 ctl 推出去并锁存
    input  wire [7:0]  ctl,

    output reg         busy,
    output wire        sck,
    output wire        mosi,
    output wire        latch_n              // RCLK，低有效锁存
);

    localparam S_IDLE = 2'd0, S_SHIFT = 2'd1, S_LATCH = 2'd2;

    reg [1:0]  st;
    reg [7:0]  div;
    reg        spi_start;
    reg [15:0] spi_mo;
    reg [4:0]  spi_n;
    wire       spi_busy, spi_done;

    c88_spi #(.DIV(DIV)) u_spi (
        .clk(clk), .rst_n(rst_n),
        .start(spi_start), .mo(spi_mo), .nbits(spi_n), .sample(1'b0),
        .busy(spi_busy), .done(spi_done),
        .sck(sck), .mosi(mosi), .miso(1'b0), .mi()
    );

    assign latch_n = (st == S_LATCH) ? 1'b0 : 1'b1;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; busy <= 1'b0; div <= 8'd0;
            spi_start <= 1'b0; spi_mo <= 16'd0; spi_n <= 5'd0;
        end else begin
            spi_start <= 1'b0;
            case (st)
                S_IDLE: begin
                    busy <= 1'b0;
                    if (load) begin
                        // [BEFORE-FIX] 高 8 位放 ctl，低 8 位补 0；nbits=8 只用高 8 位
                        spi_mo <= {ctl, 8'h00};
                        spi_n  <= 5'd8;
                        spi_start <= 1'b1;
                        busy <= 1'b1;
                        st <= S_SHIFT;
                    end
                end
                S_SHIFT: begin
                    if (spi_done) begin
                        div <= 8'd0;
                        st  <= S_LATCH;
                    end
                end
                S_LATCH: begin
                    if (div == LATCH_W[7:0] - 8'd1) begin
                        div <= 8'd0; busy <= 1'b0; st <= S_IDLE;
                    end else begin
                        div <= div + 8'd1;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end

endmodule
