//=============================================================================
// tb_sr595.v —— 595 帧位序定向测试
//
// 判据（三层，任一层失败即 FAIL）：
//   T1 移入 8 位后，595 模型锁存输出的 8 个 Q 必须等于 ctl
//      （QA=ADDR0 ... QH=TP_RESET_N）
//   T2 RCLK 只在 8 位发完之后出现，且脉宽 >= LATCH_W 拍
//   T3 busy 在帧结束后必须释放（否则扫描会永久卡死）
//
// 用法: iverilog -o tb_sr595.vvp tb_sr595.v tb_models.v ../rtl/c88_sr595.v ../rtl/c88_spi.v
//=============================================================================
`timescale 1ns/1ps

module tb_sr595;
    localparam integer DIV     = 4;
    localparam integer LATCH_W = 4;

    reg clk = 1'b0, rst_n = 1'b0;
    always #18.5 clk = ~clk;              // 27 MHz

    reg        load = 1'b0;
    reg  [7:0] ctl  = 8'h00;
    wire       busy, sck, mosi, latch_n;

    c88_sr595 #(.DIV(DIV), .LATCH_W(LATCH_W)) dut (
        .clk(clk), .rst_n(rst_n), .load(load), .ctl(ctl),
        .busy(busy), .sck(sck), .mosi(mosi), .latch_n(latch_n)
    );

    // 595 模型
    wire [7:0] q595;
    model_hc595 u_595 (.srclk(sck), .rclk(~latch_n), .ser(mosi),
                       .srclr_n(1'b1), .q(q595));

    // 诊断：抓原始位流
    integer   nbits = 0;
    reg [7:0] cap = 8'h00;
    always @(posedge sck) begin
        cap   <= {cap[6:0], mosi};
        nbits <= nbits + 1;
    end

    // RCLK 脉宽测量
    integer latch_cycles = 0;
    always @(posedge clk) if (!latch_n) latch_cycles <= latch_cycles + 1;

    integer errors = 0;
    reg [7:0] expect_ctl;

    task run_frame(input [7:0] v);
        begin
            expect_ctl = v;
            ctl  = v;
            nbits = 0; cap = 8'h00; latch_cycles = 0;
            @(posedge clk); load <= 1'b1;
            @(posedge clk); load <= 1'b0;
            // 等 busy 释放
            wait (busy === 1'b1);
            wait (busy === 1'b0);
            #100;

            $display("  ctl=%b  shifted=%b  nbits=%0d  q595=%b  latch_w=%0d",
                     v, cap, nbits, q595, latch_cycles);

            // T1
            if (q595 !== expect_ctl) begin
                $display("  [FAIL T1] 595 锁存输出 %b != ctl %b  (595 收到的位流=%b)",
                         q595, expect_ctl, cap);
                errors = errors + 1;
            end else
                $display("  [ ok  T1] 595 输出与 ctl 一致");

            // T2
            if (nbits != 8) begin
                $display("  [FAIL T2] 时钟数 %0d != 8", nbits);
                errors = errors + 1;
            end else if (latch_cycles < LATCH_W) begin
                $display("  [FAIL T2] RCLK 脉宽 %0d 拍 < LATCH_W=%0d", latch_cycles, LATCH_W);
                errors = errors + 1;
            end else
                $display("  [ ok  T2] 8 拍 + RCLK 脉宽 %0d 拍", latch_cycles);

            // T3
            if (busy !== 1'b0) begin
                $display("  [FAIL T3] busy 未释放");
                errors = errors + 1;
            end else
                $display("  [ ok  T3] busy 已释放");
        end
    endtask

    initial begin
        $dumpfile("tb_sr595.vcd");
        $dumpvars(0, tb_sr595);
        repeat (4) @(posedge clk);
        rst_n <= 1'b1;
        repeat (2) @(posedge clk);

        $display("=== 595 帧位序测试 ===");
        run_frame(8'b1011_0101);   // TP_RST=1 LCD_RST=0 RC=1 MUX_DIS=1 ADDR=5
        run_frame(8'b0000_1010);   // 只有 ADDR=10，其余 0
        run_frame(8'hFF);
        run_frame(8'h00);

        if (errors == 0) $display("RESULT: PASS (tb_sr595)");
        else             $display("RESULT: FAIL (tb_sr595) errors=%0d", errors);
        $finish;
    end

    initial begin
        #500000;
        $display("RESULT: FAIL (tb_sr595) timeout");
        $finish;
    end
endmodule
