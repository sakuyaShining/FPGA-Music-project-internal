//=============================================================================
// tb_arb.v —— 板级联调：总线仲裁 + 595/165 同时挂在三线上的行为
//
// 这个 testbench 把 c88_top 与"真实板子上的器件"接起来：
//   bus_sck / bus_mosi 同时进 595 模型和 165 模型（现实就是这样，两根线共用）
//   165 模型的 Q7 驱动 bus_return
//   input_load_n 进 165 的 SH/LD
//
// 判据：
//   A1 harm_cs_n 恒为 1（屏不选中，返回线固定接 165）
//   A2 595 帧与 165 读帧不重叠：owner=1 时 595 必须不 busy
//   A3 SH/LD 低电平期间 scan_latch 不得出现（装载不能被 595 的 RCLK 打断）
//   A4 按键链持续被读取（至少 3 次），不得在读了几次后永久停摆
//   A5 读回的按键能正确反映到 preset / edit_btn（正逻辑）
//
// 用法: iverilog -o tb_arb.vvp tb_arb.v tb_models.v ../rtl/c88_top.v ../rtl/c88_scan.v
//        ../rtl/c88_sr595.v ../rtl/c88_sr165.v ../rtl/c88_spi.v ../rtl/c88_evq.v
//=============================================================================
`timescale 1ns/1ps

module tb_arb;
    localparam integer NCH = 6, NV = 84, DIV = 2, KEYS_DIV = 2;

    reg clk = 1'b0, rst_n = 1'b0;
    always #18.5 clk = ~clk;

    wire        bus_sck, bus_mosi, bus_return, scan_latch, input_load_n, harm_cs_n;
    wire [NV-1:0] touch;
    wire        ev_valid, ev_on;
    wire [6:0]  ev_note;
    wire [3:0]  ev_vel;
    wire [3:0]  preset;
    wire        edit_btn, edit_apply, edit_save, edit_cancel, enc_push, enc_up, enc_dn;
    wire [7:0]  dbg_frame;
    reg  [NCH-1:0] sense = 6'b000000;

    // 按键链输入：EDIT(U9.D7)=0 表示按下，其余全 1
    reg [7:0] u9_d  = 8'b0111_1111;
    reg [7:0] ux1_d = 8'b1111_1111;

    model_hc165_chain u_chain (
        .cp(bus_sck), .shld_n(input_load_n),
        .u9_d(u9_d), .ux1_d(ux1_d), .q7(bus_return)
    );

    c88_top #(.NCH(NCH), .NV(NV), .BASE_N(36), .DIV(DIV), .KEYS_DIV(KEYS_DIV)) dut (
        .clk(clk), .rst_n(rst_n),
        .bus_sck(bus_sck), .bus_mosi(bus_mosi), .bus_return(bus_return),
        .scan_latch(scan_latch), .input_load_n(input_load_n), .harm_cs_n(harm_cs_n),
        .sense(sense),
        .touch(touch), .ev_valid(ev_valid), .ev_on(ev_on), .ev_note(ev_note), .ev_vel(ev_vel),
        .preset(preset), .edit_btn(edit_btn),
        .edit_apply(edit_apply), .edit_save(edit_save), .edit_cancel(edit_cancel),
        .enc_push(enc_push), .enc_up(enc_up), .enc_dn(enc_dn),
        .dbg_frame(dbg_frame)
    );

    // 595 模型挂在同一条总线上（现实如此）
    wire [7:0] q595;
    model_hc595 u_595 (.srclk(bus_sck), .rclk(~scan_latch), .ser(bus_mosi),
                       .srclr_n(1'b1), .q(q595));

    integer errors = 0;
    integer keys_reads = 0;
    integer overlap = 0;
    integer latch_in_load = 0;
    integer cs_bad = 0;
    reg     load_n_q = 1'b1;

    always @(posedge clk) begin
        if (harm_cs_n !== 1'b1) cs_bad <= cs_bad + 1;
        // A2：165 拥有总线时 595 不得 busy
        if (dut.owner === 1'b1 && dut.sr595_busy === 1'b1) overlap <= overlap + 1;
        // A3：装载期间不得有 RCLK 脉冲
        if (load_n_q === 1'b0 && scan_latch === 1'b0) latch_in_load <= latch_in_load + 1;
        load_n_q <= input_load_n;
        // A4：统计读次数
        if (dut.keys_done === 1'b1) keys_reads <= keys_reads + 1;
    end

    initial begin
        $dumpfile("tb_arb.vcd");
        $dumpvars(0, tb_arb);
        repeat (4) @(posedge clk);
        rst_n <= 1'b1;

        // 跑足够长时间，确保至少 4 次按键链读取
        wait (keys_reads >= 4);
        repeat (200) @(posedge clk);

        $display("=== 总线仲裁 / 板级联调 ===");
        $display("  按键链读取次数 = %0d", keys_reads);
        $display("  dbg_frame      = %0d", dbg_frame);
        $display("  595 最后输出    = %b (ADDR=%0d MUX_DIS=%b RC=%b LCD_RST=%b TP_RST=%b)",
                 q595, q595[3:0], q595[4], q595[5], q595[6], q595[7]);
        $display("  preset=%b edit_btn=%b enc_push=%b", preset, edit_btn, enc_push);

        if (cs_bad != 0)      begin $display("  [FAIL A1] harm_cs_n 有 %0d 拍不为 1", cs_bad); errors = errors + 1; end
        else                       $display("  [ ok  A1] harm_cs_n 恒 1");

        if (overlap != 0)     begin $display("  [FAIL A2] owner=1 且 595 busy 同时出现 %0d 拍", overlap); errors = errors + 1; end
        else                       $display("  [ ok  A2] 595/165 未同时占用总线");

        if (latch_in_load != 0) begin $display("  [FAIL A3] 装载期间出现 RCLK %0d 拍", latch_in_load); errors = errors + 1; end
        else                        $display("  [ ok  A3] 装载期间无 RCLK");

        if (keys_reads < 4)   begin $display("  [FAIL A4] 只读了 %0d 次，仲裁停摆", keys_reads); errors = errors + 1; end
        else                       $display("  [ ok  A4] 按键链持续被读取");

        if (edit_btn !== 1'b1) begin
            $display("  [FAIL A5] EDIT 按下但 edit_btn=%b（应为 1）", edit_btn);
            errors = errors + 1;
        end else if (preset !== 4'b0000) begin
            $display("  [FAIL A5] 未按 preset 却为 %b", preset);
            errors = errors + 1;
        end else
            $display("  [ ok  A5] 按键正逻辑正确");

        if (errors == 0) $display("RESULT: PASS (tb_arb)");
        else             $display("RESULT: FAIL (tb_arb) errors=%0d", errors);
        $finish;
    end

    initial begin
        #50000000;
        $display("RESULT: FAIL (tb_arb) timeout (keys_reads=%0d)", keys_reads);
        $display("  诊断: dbg_frame=%0d arb=%0d scan_idle=%b sr595_busy=%b scan_pause=%b frame_div=%0d owner=%b st=%0d ctl_load=%b",
                 dbg_frame, dut.arb, dut.scan_idle, dut.sr595_busy, dut.scan_pause,
                 dut.frame_div, dut.owner, dut.u_scan.st, dut.u_scan.ctl_load);
        $finish;
    end
endmodule
