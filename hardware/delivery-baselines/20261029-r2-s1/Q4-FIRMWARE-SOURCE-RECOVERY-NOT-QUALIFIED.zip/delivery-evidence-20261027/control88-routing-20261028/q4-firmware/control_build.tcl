open_project control_tdm_ship.gprj
set_option -use_sspi_as_gpio 1
run syn
run pnr
run close
