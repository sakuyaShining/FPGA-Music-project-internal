//=============================================================================
// c88_scan.v —— 84 节点电容扫描（6 通道 × 16 地址，经 4067 阵列）
//
// 【拓扑（来自 control88-netlist.json，不是猜的）】
//   ADDR0-3 / MUX_DISABLE / RC_DRIVE 全部由 U8(74HC595) 输出，六个 4067 板
//   （JB0..JB5）共用同一组地址线 ⇒ 一个地址同时选中六块板上的同一个通道。
//   六块板的输出分别回到 SENSE_0..5 ⇒ 一次地址扫描同时得到 6 个节点的读数。
//   16 地址 × 6 通道 = 96 槽，其中 84 槽接琴键（其余为空槽）。
//
// 【测量原理（推断，待 JB 板原理图确认）】
//   RC_DRIVE 是 595 的推挽输出，不能三态 ⇒ 它不可能直接给电极做"释放到高阻"。
//   因此判断 RC_DRIVE 驱动的是 4067 板上的**放电管栅极**：
//     RC_DRIVE=1 → 放电管导通 → 节点清零
//     RC_DRIVE=0 → 放电管关断 → 节点经上拉电阻充电，SENSE 比较器翻转
//   计时"释放后到 SENSE 翻转"的拍数：手指靠近 ⇒ C 变大 ⇒ 时间变长。
//   ⇒ 本模块按 SENSE_POL=1（释放后等 SENSE 变高）实现，并把该假设写进证据。
//   **该假设未经验证**：JB0-JB5 是外接小板，不在本 PCB 内，其原理图不在冻结源中。
//
// 【与 pad_scan.v 的关系】阈值/基线/去抖沿用 pad_scan 已验证的算法（1.156/1.078
//   移位近似 + 连续 3 轮去抖），只把"16 路并行直连"换成"16 地址 × 6 通道扫查"。
//=============================================================================
`timescale 1ns/1ps

module c88_scan #(
    parameter integer NCH      = 6,        // 感应通道数（SENSE_0..5）
    parameter integer NADDR    = 16,       // 4067 地址数
    parameter integer NVLD     = 84,       // 有效节点数（其余为空槽）
    parameter integer CW       = 10,       // 计数位宽
    parameter integer CHARGE   = 64,       // 放电拍数
    parameter integer CAL_RND  = 32,       // 基线标定轮数
    parameter integer DEB      = 3,        // 去抖轮数
    parameter integer SENSE_POL= 1,        // 1 = 释放后等 SENSE 变高
    parameter integer DIV      = 8         // 595 帧的 SCK 半周期
)(
    input  wire              clk,
    input  wire              rst_n,

    // ---- 595 控制（ADDR0-3 / MUX_DISABLE / RC_DRIVE / 两级复位）----
    output reg  [7:0]        ctl,
    output reg               ctl_load,
    input  wire              ctl_busy,

    // ---- 六路感应输入 ----
    input  wire [NCH-1:0]    sense,

    // ---- 总线让出（165 读回要用同一组 SCK/MOSI）----
    input  wire              pause,        // 1 = 停在帧边界，不再发起新地址
    output wire              idle_now,     // 1 = 处于 S_IDLE 且无未完成的 595 帧

    // ---- 结果 ----
    output reg  [NVLD-1:0]   touch,        // 去抖后的触摸位图
    output wire [CW-1:0]     dbg_raw,      // 调试：当前节点裸计数
    output wire [CW-1:0]     dbg_base,     // 调试：当前节点基线
    output reg  [7:0]        frame_cnt     // 完整帧计数（刷新率观测）
);

    localparam S_IDLE  = 3'd0;
    localparam S_CTL1  = 3'd1;   // 写地址 + RC_DRIVE=1（放电）
    localparam S_CHG   = 3'd2;   // 保持放电
    localparam S_CTL2  = 3'd3;   // 写 RC_DRIVE=0（释放）
    localparam S_MEAS  = 3'd4;   // 计时
    localparam S_LATCH = 3'd5;   // 锁存 + 基线/阈值/去抖
    localparam S_NEXT  = 3'd6;   // 下一地址

    reg [2:0]  st;
    reg [7:0]  addr;
    reg [7:0]  chg;
    reg [CW-1:0] cnt  [0:NCH-1];
    reg [CW-1:0] raw  [0:NCH-1];
    reg [CW-1:0] base [0:NCH-1];
    reg [1:0]  deb_up [0:NCH-1];
    reg [1:0]  deb_dn [0:NCH-1];
    reg [5:0]  cal_rnd;
    reg [5:0]  trk_cnt;
    reg [NCH-1:0] done_ch;                 // 本地址已停止计时的通道

    integer i;

    // 位图下标：node = addr*NCH + ch（与 4067 的物理顺序一致）
    function integer node_idx(input integer a, input integer c);
        node_idx = a * NCH + c;
    endfunction

    assign dbg_raw  = raw[0];
    assign dbg_base = base[0];
    assign idle_now = (st == S_IDLE) && !ctl_load && !ctl_busy;

    wire [CW-1:0] cap = {CW{1'b1}};

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; addr <= 8'd0; chg <= 8'd0; ctl <= 8'b0100_0000;
            ctl_load <= 1'b0; cal_rnd <= 6'd0; trk_cnt <= 6'd0;
            frame_cnt <= 8'd0; done_ch <= {NCH{1'b0}};
            for (i = 0; i < NCH; i = i + 1) begin
                cnt[i] <= {CW{1'b0}}; raw[i] <= {CW{1'b0}};
                base[i] <= {CW{1'b0}}; deb_up[i] <= 2'd0; deb_dn[i] <= 2'd0;
            end
        end else begin
            ctl_load <= 1'b0;
            case (st)
                //-------------------------------------------------------------
                S_IDLE: begin
                    addr <= 8'd0;
                    if (pause) begin
                        // 让出总线。595 在上一地址的 S_CTL2 已写成 RC_DRIVE=0（释放态），
                        // 这里不再发起任何帧，idle_now 才能为 1。
                        st <= S_IDLE;
                    end else begin
                        frame_cnt <= frame_cnt + 8'd1;
                        // ctl[3:0]=ADDR, [5]=RC_DRIVE=1, [6]=LCD_RST_N=1, [7]=TP_RST_N=1
                        ctl <= {2'b11, 1'b1, 1'b0, addr[3:0]};
                        ctl_load <= 1'b1;
                        st <= S_CTL1;
                    end
                end
                S_CTL1: begin
                    if (!ctl_busy) begin
                        chg <= 8'd0;
                        for (i = 0; i < NCH; i = i + 1) cnt[i] <= {CW{1'b0}};
                        done_ch <= {NCH{1'b0}};
                        st <= S_CHG;
                    end
                end
                S_CHG: begin
                    if (chg == CHARGE[7:0] - 8'd1) begin
                        // 释放：RC_DRIVE=0，地址不变
                        ctl <= {2'b11, 1'b0, 1'b0, addr[3:0]};
                        ctl_load <= 1'b1;
                        st <= S_CTL2;
                    end else begin
                        chg <= chg + 8'd1;
                    end
                end
                S_CTL2: begin
                    if (!ctl_busy) st <= S_MEAS;
                end
                //-------------------------------------------------------------
                // 计时：每通道独立计数，翻转到目标电平或封顶即停
                S_MEAS: begin
                    for (i = 0; i < NCH; i = i + 1) begin
                        if (!done_ch[i]) begin
                            if (sense[i] == SENSE_POL[0] || cnt[i] == cap) begin
                                done_ch[i] <= 1'b1;
                            end else begin
                                cnt[i] <= cnt[i] + {{(CW-1){1'b0}}, 1'b1};
                            end
                        end
                    end
                    if (&done_ch) st <= S_LATCH;
                end
                //-------------------------------------------------------------
                S_LATCH: begin
                    for (i = 0; i < NCH; i = i + 1) begin
                        raw[i] <= cnt[i];
                        if (cal_rnd != CAL_RND[5:0]) begin
                            // 标定窗：取最小值 = 未触摸电平
                            if (cnt[i] < base[i] || cal_rnd == 6'd0) base[i] <= cnt[i];
                        end else if (trk_cnt == 6'd0 && cnt[i] < base[i]) begin
                            // 缓慢跟踪（每 64 轮最多下调 1）
                            base[i] <= base[i] - {{(CW-1){1'b0}}, 1'b1};
                        end
                        // 阈值：hi = base*1.156，lo = base*1.078（移位加，零乘法器）
                        // 去抖：连续 DEB 轮同向才翻转
                        if (cnt[i] > base[i] + (base[i] >> 3) + (base[i] >> 5)) begin
                            if (deb_up[i] == DEB[1:0] - 2'd1) begin
                                touch[node_idx(addr[3:0], i)] <= 1'b1;
                                deb_up[i] <= 2'd0;
                            end else deb_up[i] <= deb_up[i] + 2'd1;
                            deb_dn[i] <= 2'd0;
                        end else if (cnt[i] < base[i] + (base[i] >> 4) + (base[i] >> 6)) begin
                            if (deb_dn[i] == DEB[1:0] - 2'd1) begin
                                touch[node_idx(addr[3:0], i)] <= 1'b0;
                                deb_dn[i] <= 2'd0;
                            end else deb_dn[i] <= deb_dn[i] + 2'd1;
                            deb_up[i] <= 2'd0;
                        end else begin
                            deb_up[i] <= 2'd0; deb_dn[i] <= 2'd0;
                        end
                    end
                    st <= S_NEXT;
                end
                S_NEXT: begin
                    if (addr == NADDR[7:0] - 8'd1) begin
                        if (cal_rnd != CAL_RND[5:0]) cal_rnd <= cal_rnd + 6'd1;
                        trk_cnt <= trk_cnt + 6'd1;
                        st <= S_IDLE;
                    end else begin
                        addr <= addr + 8'd1;
                        // 新地址 + RC_DRIVE=1：ADDR=addr+1, MUX_DISABLE=0, 复位保持高
                        ctl <= {2'b11, 1'b1, 1'b0, addr[3:0] + 4'd1};
                        ctl_load <= 1'b1;
                        st <= S_CTL1;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end

endmodule
