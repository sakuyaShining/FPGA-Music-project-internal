//=============================================================================
// c88_evq.v —— 84 键位图 -> tdm_top 事件流（ev_valid/ev_on/ev_note/ev_vel）
//
// 【为什么需要它】tdm_top 的 ev_* 是单拍接口，内部只有 EVQ_DEPTH=4 的队列；
//   同时按下多个键会产生多个事件，若同一拍压进去必然丢音。
//   本模块把"位图变化"串行化成一条事件流，事件之间留 GAP 拍冷却。
//
// 【音高映射】84 节点 = 7 个八度 × 12 半音，node n -> note 36+n（C2..B8）。
//   这是控制板"逐音键"的直映射，不经过五声音阶表（那是 16 电极旧方案的约束）。
//
// 【实现取舍（2026-10-29 第一版资源超标的修正）】
//   第一版用 `pend <= pend & ~(1 << idx)` 清除已发位 ⇒ 综合出 84 位桶形移位器，
//   单这一处就吃掉约 7k LUT（整设计 Logic 从 27% 涨到 82%）。
//   本版改为**线性扫描**：把 diff 打进移位寄存器，每拍看 bit0、右移一位、下标 +1。
//   全程无变长移位、无变址写；一轮扫描 84 拍（27 MHz 下 3.1 µs）。
//   prev 在扫描结束时整体装载，避免变址写。
//   代价：按下并松开若发生在同一轮扫描内（<3 µs）会漏，对人手不可能。
//=============================================================================
`timescale 1ns/1ps

module c88_evq #(
    parameter integer NV   = 84,           // 键数
    parameter integer BASE = 36,           // 最低音（C2）
    parameter integer GAP  = 200,          // 事件间隔（拍）
    parameter integer VB   = 4              // 力度位宽（与 tdm_top 一致）
)(
    input  wire            clk,
    input  wire            rst_n,

    input  wire [NV-1:0]   touch,          // 当前键位图
    input  wire [VB-1:0]   vel,            // 固定力度（无压力传感）

    output reg             ev_valid,
    output reg             ev_on,
    output reg  [6:0]      ev_note,
    output reg  [VB-1:0]   ev_vel,
    output reg  [7:0]      ev_cnt          // 累计事件数（观测丢音用）
);

    reg [NV-1:0] prev;
    reg [NV-1:0] sr;                       // diff 的移位副本
    reg [NV-1:0] tsr;                      // touch 的移位副本（避免变址读）
    reg [7:0]    si;                       // 扫描下标
    reg [7:0]    gap;
    reg          sweeping;

    wire [NV-1:0] diff = touch ^ prev;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            prev <= {NV{1'b0}}; sr <= {NV{1'b0}}; tsr <= {NV{1'b0}};
            si <= 8'd0; gap <= 8'd0;
            sweeping <= 1'b0;
            ev_valid <= 1'b0; ev_on <= 1'b0; ev_note <= 7'd0;
            ev_vel <= {VB{1'b0}}; ev_cnt <= 8'd0;
        end else begin
            ev_valid <= 1'b0;

            if (!sweeping) begin
                if (diff != {NV{1'b0}}) begin
                    sr       <= diff;
                    tsr      <= touch;
                    si       <= 8'd0;
                    gap      <= 8'd0;
                    sweeping <= 1'b1;
                end
            end else if (gap != 8'd0) begin
                gap <= gap - 8'd1;
            end else begin
                if (sr[0]) begin
                    ev_valid <= 1'b1;
                    ev_on    <= tsr[0];          // 目标状态：按下=1，松开=0
                    ev_note  <= BASE[6:0] + si[6:0];
                    ev_vel   <= vel;
                    ev_cnt   <= ev_cnt + 8'd1;
                    gap      <= GAP[7:0];
                end
                sr  <= {1'b0, sr[NV-1:1]};
                tsr <= {1'b0, tsr[NV-1:1]};
                si  <= si + 8'd1;
                if (si == NV[7:0] - 8'd1) begin
                    sweeping <= 1'b0;
                    prev     <= touch;            // 整轮结束才对基线
                end
            end
        end
    end

endmodule
