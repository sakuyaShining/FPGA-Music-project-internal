//=============================================================================
// c88_sr165.v —— 74HC165 链 (U9 -> UX1) 读回
//
// 【链序】UX1.Q7 (pin9) -> U9.DS (pin10)。装载后先出 U9 的 D7。
//   两个 165 都按 Nexperia 脚位与网络逐脚对上：
//     U9 : 1 SH/LD<-INPUT_LOAD_N  2 CP<-BUS_SCK  9 Q7->KEY_QH  10 DS<-UX1.Q7
//          11 D0<-ENC_A  12 D1<-ENC_B  13 D2<-ENC_PUSH  14 D3<-PRESET0
//          3 D4<-PRESET1  4 D5<-PRESET2  5 D6<-PRESET3  6 D7<-EDIT
//          15 CE->GND（常使能）  7 Q7S 未接  16 VCC  8 GND
//     UX1: 同脚位；D5/D6/D7 <- EDIT_CANCEL_N/EDIT_SAVE_N/EDIT_APPLY_N
//          D0..D4 <- 3V3_IO（恒读 1，作为链完整性判据）
//
// 【极性】PRESET0-3 / EDIT / ENC_* / EDIT_* 都是"开关到 GND + 上拉电阻"
//   （R50-R57、RX1-RX3 另一端接 3V3_IO）⇒ 按下读 0。本模块输出**已反相**的
//   正逻辑 pressed 位，调用方不需要再取反。
//
// 输出 keys[15:0] 原始位（未反相），pressed[10:0] 正逻辑（按下=1）
//=============================================================================
`timescale 1ns/1ps

module c88_sr165 #(
    parameter integer DIV     = 8,
    parameter integer LOAD_W  = 4
)(
    input  wire        clk,
    input  wire        rst_n,

    input  wire        start,               // 一拍请求：装载 + 读 16 位
    output reg         busy,
    output reg         done,
    output reg  [15:0] keys,                // 原始位（MSB 先出的顺序）

    output wire        sck,
    output wire        mosi,                // 165 链不需要 MOSI，接 0
    output reg         load_n,              // SH/LD，低有效
    input  wire        miso                 // BUS_RETURN
);

    localparam S_IDLE = 2'd0, S_LOAD = 2'd1, S_SHIFT = 2'd2;

    reg [1:0]  st;
    reg [7:0]  div;
    reg        spi_start;
    wire       spi_busy, spi_done;
    wire [15:0] spi_mi;

    c88_spi #(.DIV(DIV)) u_spi (
        .clk(clk), .rst_n(rst_n),
        .start(spi_start), .mo(16'h0000), .nbits(5'd16), .sample(1'b1),
        .busy(spi_busy), .done(spi_done),
        .sck(sck), .mosi(mosi), .miso(miso), .mi(spi_mi)
    );

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st <= S_IDLE; busy <= 1'b0; done <= 1'b0; div <= 8'd0;
            spi_start <= 1'b0; load_n <= 1'b1; keys <= 16'hFFFF;
        end else begin
            spi_start <= 1'b0;
            done <= 1'b0;
            case (st)
                S_IDLE: begin
                    busy <= 1'b0; load_n <= 1'b1;
                    if (start) begin
                        busy <= 1'b1; div <= 8'd0; load_n <= 1'b0;
                        st <= S_LOAD;
                    end
                end
                // SH/LD 拉低 LOAD_W 拍完成并行装载（165 是电平装载）
                S_LOAD: begin
                    if (div == LOAD_W[7:0] - 8'd1) begin
                        div <= 8'd0; load_n <= 1'b1;
                        spi_start <= 1'b1;
                        st <= S_SHIFT;
                    end else begin
                        div <= div + 8'd1;
                    end
                end
                S_SHIFT: begin
                    if (spi_done) begin
                        keys <= spi_mi;
                        busy <= 1'b0; done <= 1'b1;
                        st <= S_IDLE;
                    end
                end
                default: st <= S_IDLE;
            endcase
        end
    end

    // 正逻辑（按下 = 1）。位下标见文件头。
    // keys[15]=EDIT [14]=PRESET3 [13]=PRESET2 [12]=PRESET1 [11]=PRESET0
    // keys[10]=ENC_PUSH [9]=ENC_B [8]=ENC_A
    // keys[7]=EDIT_APPLY_N [6]=EDIT_SAVE_N [5]=EDIT_CANCEL_N [4:0]=1

endmodule
