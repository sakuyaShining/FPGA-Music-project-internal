//=============================================================================
// c88_top.v —— Control88 板级粘合层（总线仲裁 + 扫描 + 按键链）
//
// 【总线上只有一个主】BUS_SCK / BUS_MOSI 同时挂在 U8(595)、U9/UX1(165) 和屏上。
//   595 写帧与 165 读帧不能交错，否则两者都会收到对方的时钟。
//   本模块的仲裁规则：
//     常态：扫描引擎拥有总线（每个地址发 2 个 595 帧：放电 / 释放）
//     每 KEYS_DIV 个扫描帧：扫描停在帧边界 → 交出总线 → 165 读 16 位 → 还回
//
// 【返回线】BUS_RETURN 经 U11 在 KEY_QH 与 RA_MISO 之间二选一，选择位是 HARM_CS_N。
//   本模块**不使用屏**（屏控制器型号未确认，见契约文档 §6 红项），
//   因此 HARM_CS_N 恒为 1（屏不选中）⇒ 返回线恒定接到 165 链输出。
//   若将来接屏，必须在 165 读窗口之外才允许 HARM_CS_N=0。
//=============================================================================
`timescale 1ns/1ps

module c88_top #(
    parameter integer NCH     = 6,
    parameter integer NV      = 84,
    parameter integer BASE_N  = 36,
    parameter integer DIV     = 8,
    parameter integer KEYS_DIV= 8          // 每 8 个扫描帧读一次按键链
)(
    input  wire        clk,
    input  wire        rst_n,

    // ---- 共享三线总线 ----
    output wire        bus_sck,
    output wire        bus_mosi,
    input  wire        bus_return,
    output wire        scan_latch,         // 595 RCLK
    output wire        input_load_n,       // 165 SH/LD
    output wire        harm_cs_n,          // 屏片选 / 返回通道选择

    // ---- 六路感应 ----
    input  wire [NCH-1:0] sense,

    // ---- 人机 ----
    output wire [NV-1:0]  touch,           // 84 键位图（给遥测/调试）
    output wire           ev_valid,
    output wire           ev_on,
    output wire [6:0]     ev_note,
    output wire [3:0]     ev_vel,

    output reg  [3:0]     preset,          // PRESET0-3（正逻辑，按下=1）
    output reg            edit_btn,
    output reg            edit_apply,
    output reg            edit_save,
    output reg            edit_cancel,
    output reg            enc_push,
    output reg            enc_up,          // 编码器正转脉冲
    output reg            enc_dn,          // 编码器反转脉冲

    output wire [7:0]     dbg_frame        // 扫描帧计数（刷新率观测）
);

    //-------------------------------------------------------------------------
    // 595 / 165 / 扫描
    //-------------------------------------------------------------------------
    wire        ctl_load;
    wire [7:0]  ctl;
    reg         scan_pause;                // 在仲裁状态机里赋值，必须是 reg
    wire        scan_idle;
    wire        sr595_busy;                // 595 帧忙（= 扫描侧的 ctl_busy）

    c88_scan #(.NCH(NCH), .NVLD(NV), .DIV(DIV)) u_scan (
        .clk(clk), .rst_n(rst_n),
        .ctl(ctl), .ctl_load(ctl_load), .ctl_busy(sr595_busy),
        .sense(sense),
        .pause(scan_pause), .idle_now(scan_idle),
        .touch(touch), .dbg_raw(), .dbg_base(), .frame_cnt(dbg_frame)
    );

    wire        sr595_sck, sr595_mosi, sr595_latch_n;
    c88_sr595 #(.DIV(DIV)) u_sr595 (
        .clk(clk), .rst_n(rst_n),
        .load(ctl_load), .ctl(ctl),
        .busy(sr595_busy), .sck(sr595_sck), .mosi(sr595_mosi), .latch_n(sr595_latch_n)
    );

    wire        keys_start, keys_busy, keys_done;
    wire [15:0] keys_raw;
    wire        sr165_sck, sr165_mosi, sr165_load_n;
    c88_sr165 #(.DIV(DIV)) u_sr165 (
        .clk(clk), .rst_n(rst_n),
        .start(keys_start), .busy(keys_busy), .done(keys_done), .keys(keys_raw),
        .sck(sr165_sck), .mosi(sr165_mosi), .load_n(sr165_load_n), .miso(bus_return)
    );

    //-------------------------------------------------------------------------
    // 总线仲裁
    //-------------------------------------------------------------------------
    localparam S_RUN  = 2'd0, S_WAIT = 2'd1, S_KEYS = 2'd2;

    reg [1:0]  arb;
    reg        owner;                      // 1 = 165 拥有总线
    reg [3:0]  frame_div;
    reg        keys_start_q;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            arb <= S_RUN; owner <= 1'b0; scan_pause <= 1'b0;
            frame_div <= 4'd0; keys_start_q <= 1'b0;
        end else begin
            keys_start_q <= 1'b0;
            case (arb)
                S_RUN: begin
                    owner <= 1'b0; scan_pause <= 1'b0;
                    if (dbg_frame != 8'd0 && dbg_frame[2:0] == 3'd0 &&
                        frame_div != KEYS_DIV[3:0]) begin
                        frame_div <= frame_div + 4'd1;
                        scan_pause <= 1'b1;
                        arb <= S_WAIT;
                    end
                end
                S_WAIT: begin
                    // 等扫描停在帧边界（595 也没有未完成的帧）
                    if (scan_idle && !sr595_busy) begin
                        owner <= 1'b1;
                        keys_start_q <= 1'b1;
                        arb <= S_KEYS;
                    end
                end
                S_KEYS: begin
                    if (keys_done) begin
                        owner <= 1'b0; scan_pause <= 1'b0;
                        frame_div <= 4'd0;
                        arb <= S_RUN;
                    end
                end
                default: arb <= S_RUN;
            endcase
        end
    end

    assign bus_sck      = owner ? sr165_sck  : sr595_sck;
    assign bus_mosi     = owner ? sr165_mosi : sr595_mosi;
    assign scan_latch   = sr595_latch_n;
    assign input_load_n = owner ? sr165_load_n : 1'b1;
    assign harm_cs_n    = 1'b1;            // 屏不选中 ⇒ 返回线接 165

    assign keys_start = keys_start_q;

    //-------------------------------------------------------------------------
    // 165 位解码（位序见 c88_sr165.v 文件头）
    //   keys[15]=EDIT [14]=PRESET3 [13]=PRESET2 [12]=PRESET1 [11]=PRESET0
    //   keys[10]=ENC_PUSH [9]=ENC_B [8]=ENC_A
    //   keys[7]=EDIT_APPLY_N [6]=EDIT_SAVE_N [5]=EDIT_CANCEL_N [4:0]=1
    //   全部为低有效（开关到 GND + 上拉），这里统一反相成正逻辑。
    //-------------------------------------------------------------------------
    reg [15:0] keys_s1, keys_s2;           // 两级同步（总线跨域余量）

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            keys_s1 <= 16'hFFFF; keys_s2 <= 16'hFFFF;
            preset <= 4'd0; edit_btn <= 1'b0; enc_push <= 1'b0;
            edit_apply <= 1'b0; edit_save <= 1'b0; edit_cancel <= 1'b0;
        end else if (keys_done) begin
            keys_s1 <= keys_raw; keys_s2 <= keys_s1;
            preset      <= {~keys_s2[14], ~keys_s2[13], ~keys_s2[12], ~keys_s2[11]};
            edit_btn    <= ~keys_s2[15];
            enc_push    <= ~keys_s2[10];
            edit_apply  <= ~keys_s2[7];
            edit_save   <= ~keys_s2[6];
            edit_cancel <= ~keys_s2[5];
        end
    end

    //-------------------------------------------------------------------------
    // 编码器（SW1：A/B 正交，C=GND，D=按下）
    //   四状态译码，只在合法跳变时产生单拍 up/dn 脉冲。
    //-------------------------------------------------------------------------
    reg [1:0] enc_prev;
    reg [1:0] enc_ab;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            enc_prev <= 2'b00; enc_ab <= 2'b00;
            enc_up <= 1'b0; enc_dn <= 1'b0;
        end else begin
            enc_up <= 1'b0; enc_dn <= 1'b0;
            enc_ab <= {keys_s2[9], keys_s2[8]};   // {B, A}
            if (enc_ab != enc_prev) begin
                case ({enc_prev, enc_ab})
                    4'b00_01, 4'b01_11, 4'b11_10, 4'b10_00: enc_dn <= 1'b1;
                    4'b00_10, 4'b10_11, 4'b11_01, 4'b01_00: enc_up <= 1'b1;
                    default: begin end
                endcase
                enc_prev <= enc_ab;
            end
        end
    end

    //-------------------------------------------------------------------------
    // 位图 -> 事件流
    //-------------------------------------------------------------------------
    c88_evq #(.NV(NV), .BASE(BASE_N)) u_evq (
        .clk(clk), .rst_n(rst_n),
        .touch(touch), .vel(4'd12),
        .ev_valid(ev_valid), .ev_on(ev_on), .ev_note(ev_note), .ev_vel(ev_vel),
        .ev_cnt()
    );

endmodule
