module note_router_timing_probe(
    input wire clk,load,shift,capture,
    input wire [3:0] data_in,
    output wire [3:0] data_out);
    reg [3:0] held=0,observed=0;
    assign data_out=observed;
    always @(posedge clk)begin
        if(load)held<=data_in;
        else if(shift)held<={held[2:0],held[3]};
        if(capture)observed<=held;
    end
endmodule
