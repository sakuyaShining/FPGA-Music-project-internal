open_project "D:/FPGA-Project/review/router-crash-alternate-full-20261024-01/router.gprj"
set_option -top_module note_router_timing_probe
set_option -use_sspi_as_gpio 1
set_option -correct_hold_violation 1
set_option -place_option 1
set_option -route_option 1
run all
exit
