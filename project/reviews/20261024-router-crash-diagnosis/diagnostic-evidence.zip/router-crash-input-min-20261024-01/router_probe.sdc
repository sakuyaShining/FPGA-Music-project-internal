create_clock -name sys_clk -period 37.037 -waveform {0 18.5185} [get_ports {clk}]
set_input_delay -clock sys_clk -min 1.0 [get_ports {load shift capture data_in[*]}]
