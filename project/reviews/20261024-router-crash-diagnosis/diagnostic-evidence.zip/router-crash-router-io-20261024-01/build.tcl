open_project "D:/FPGA-Project/review/router-crash-router-io-20261024-01/router.gprj"
set_option -top_module note_router_timing_probe
set_option -use_sspi_as_gpio 1
run all
exit
