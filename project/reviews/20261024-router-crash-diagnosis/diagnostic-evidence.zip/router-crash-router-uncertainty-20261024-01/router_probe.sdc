create_clock -name sys_clk -period 37.037 -waveform {0 18.5185} [get_ports {clk}]
set_clock_uncertainty -setup 0.5 -from [get_clocks {sys_clk}]
set_clock_uncertainty -hold 0.2 -from [get_clocks {sys_clk}]
