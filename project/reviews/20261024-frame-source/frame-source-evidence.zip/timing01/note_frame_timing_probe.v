module note_frame_timing_probe(
input wire clk,load,shift,capture,
input wire [3:0] data_in,
output wire [3:0] data_out);
wire rst_n;
wire frame_valid;
wire [25:0] contact;
wire [25:0] invalid;
wire [233:0] position;
wire [181:0] note_map;
wire [31:0] frame_sequence;
wire frame_calibration;
wire [7:0] velocity;
wire [17:0] glide;
wire [3:0] layer_selection;
wire retire_valid;
wire [31:0] retire_token;
wire finish_valid;
wire [31:0] finish_token;
wire [31:0] finish_groups;
wire event_ready;
wire response_valid;
wire [31:0] response_token;
wire [2:0] response_code;
wire [31:0] response_groups;
wire [3:0] response_layers;
wire [19:0] response_map;
wire reply_ready;
wire frame_ready;
wire frame_error;
wire link_error;
wire sensor_error;
wire watchdog_error;
wire admission_error;
wire [25:0] seen_contacts;
wire [25:0] blocked_contacts;
wire anchor_valid;
wire [4:0] anchor_contact;
wire [11:0] anchor_position;
wire event_valid;
wire event_on;
wire [30:0] event_serial;
wire [31:0] event_token;
wire [6:0] event_note;
wire [7:0] event_velocity;
wire [17:0] event_glide;
wire [3:0] event_layers;
wire cancel_valid;
wire [31:0] cancel_token;
wire response_ready;
wire reply_valid;
wire reply_on;
wire [31:0] reply_token;
wire [31:0] reply_groups;
wire [2:0] reply_code;
wire [3:0] reply_layers;
wire [19:0] reply_map;
wire [4:0] reply_contact;
wire [7:0] reply_generation;
wire expression_valid;
wire [31:0] expression_token;
wire [31:0] expression_groups;
wire [3:0] expression_layers;
wire [11:0] expression_position;
wire epoch_exhausted;
wire protocol_error;
reg [725-1:0] staging=0,controls=0;
reg [401-1:0] observation=0;
assign {rst_n,frame_valid,contact,invalid,position,note_map,frame_sequence,frame_calibration,velocity,glide,layer_selection,retire_valid,retire_token,finish_valid,finish_token,finish_groups,event_ready,response_valid,response_token,response_code,response_groups,response_layers,response_map,reply_ready}=controls;
assign data_out=observation[3:0];
always @(posedge clk)begin
    if(shift)staging<=(staging<<4)|data_in;
    if(load)controls<=staging;
    if(capture)observation<={frame_ready,frame_error,link_error,sensor_error,watchdog_error,admission_error,seen_contacts,blocked_contacts,anchor_valid,anchor_contact,anchor_position,event_valid,event_on,event_serial,event_token,event_note,event_velocity,event_glide,event_layers,cancel_valid,cancel_token,response_ready,reply_valid,reply_on,reply_token,reply_groups,reply_code,reply_layers,reply_map,reply_contact,reply_generation,expression_valid,expression_token,expression_groups,expression_layers,expression_position,epoch_exhausted,protocol_error};
    else if(shift)observation<=observation>>4;
end
note_frame_transport dut(.clk(clk),.rst_n(rst_n),
.frame_valid(frame_valid),
.contact(contact),
.invalid(invalid),
.position(position),
.note_map(note_map),
.frame_sequence(frame_sequence),
.frame_calibration(frame_calibration),
.velocity(velocity),
.glide(glide),
.layer_selection(layer_selection),
.retire_valid(retire_valid),
.retire_token(retire_token),
.finish_valid(finish_valid),
.finish_token(finish_token),
.finish_groups(finish_groups),
.event_ready(event_ready),
.response_valid(response_valid),
.response_token(response_token),
.response_code(response_code),
.response_groups(response_groups),
.response_layers(response_layers),
.response_map(response_map),
.reply_ready(reply_ready),
.frame_ready(frame_ready),
.frame_error(frame_error),
.link_error(link_error),
.sensor_error(sensor_error),
.watchdog_error(watchdog_error),
.admission_error(admission_error),
.seen_contacts(seen_contacts),
.blocked_contacts(blocked_contacts),
.anchor_valid(anchor_valid),
.anchor_contact(anchor_contact),
.anchor_position(anchor_position),
.event_valid(event_valid),
.event_on(event_on),
.event_serial(event_serial),
.event_token(event_token),
.event_note(event_note),
.event_velocity(event_velocity),
.event_glide(event_glide),
.event_layers(event_layers),
.cancel_valid(cancel_valid),
.cancel_token(cancel_token),
.response_ready(response_ready),
.reply_valid(reply_valid),
.reply_on(reply_on),
.reply_token(reply_token),
.reply_groups(reply_groups),
.reply_code(reply_code),
.reply_layers(reply_layers),
.reply_map(reply_map),
.reply_contact(reply_contact),
.reply_generation(reply_generation),
.expression_valid(expression_valid),
.expression_token(expression_token),
.expression_groups(expression_groups),
.expression_layers(expression_layers),
.expression_position(expression_position),
.epoch_exhausted(epoch_exhausted),
.protocol_error(protocol_error));
endmodule
