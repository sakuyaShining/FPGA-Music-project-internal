open_project "D:/FPGA-Project/review/frame-source-timing-20261024-02/contact.gprj"
set_option -top_module note_frame_timing_probe
set_option -use_sspi_as_gpio 1
run all
exit
