module tb_frames;
reg clk=0;always #5 clk=~clk;
reg rst_n=0;
reg frame_valid=0;
reg [3:0] contact=0;
reg [3:0] invalid=0;
reg [35:0] position=0;
reg [27:0] note_map=0;
reg [31:0] frame_sequence=0;
reg frame_calibration=0;
reg [7:0] velocity=0;
reg [17:0] glide=0;
reg [3:0] layer_selection=0;
reg retire_valid=0;
reg [31:0] retire_token=0;
reg finish_valid=0;
reg [31:0] finish_token=0;
reg [31:0] finish_groups=0;
reg event_ready=0;
reg response_valid=0;
reg [31:0] response_token=0;
reg [2:0] response_code=0;
reg [31:0] response_groups=0;
reg [3:0] response_layers=0;
reg [19:0] response_map=0;
reg reply_ready=0;
wire frame_ready;
wire frame_error;
wire link_error;
wire sensor_error;
wire watchdog_error;
wire admission_error;
wire [3:0] seen_contacts;
wire [3:0] blocked_contacts;
wire anchor_valid;
wire [4:0] anchor_contact;
wire [11:0] anchor_position;
wire event_valid;
wire event_on;
wire [30:0] event_serial;
wire [31:0] event_token;
wire [6:0] event_note;
wire [7:0] event_velocity;
wire [17:0] event_glide;
wire [3:0] event_layers;
wire cancel_valid;
wire [31:0] cancel_token;
wire response_ready;
wire reply_valid;
wire reply_on;
wire [31:0] reply_token;
wire [31:0] reply_groups;
wire [2:0] reply_code;
wire [3:0] reply_layers;
wire [19:0] reply_map;
wire [4:0] reply_contact;
wire [7:0] reply_generation;
wire expression_valid;
wire [31:0] expression_token;
wire [31:0] expression_groups;
wire [3:0] expression_layers;
wire [11:0] expression_position;
wire epoch_exhausted;
wire protocol_error;
note_frame_transport #(.NF(4),.BAD_FRAMES(3),.FRAME_TIMEOUT(2000),.LINK_TIMEOUT(300)) dut(.clk(clk),.rst_n(rst_n),.frame_valid(frame_valid),.contact(contact),.invalid(invalid),.position(position),.note_map(note_map),.frame_sequence(frame_sequence),.frame_calibration(frame_calibration),.velocity(velocity),.glide(glide),.layer_selection(layer_selection),.retire_valid(retire_valid),.retire_token(retire_token),.finish_valid(finish_valid),.finish_token(finish_token),.finish_groups(finish_groups),.event_ready(event_ready),.response_valid(response_valid),.response_token(response_token),.response_code(response_code),.response_groups(response_groups),.response_layers(response_layers),.response_map(response_map),.reply_ready(reply_ready),.frame_ready(frame_ready),.frame_error(frame_error),.link_error(link_error),.sensor_error(sensor_error),.watchdog_error(watchdog_error),.admission_error(admission_error),.seen_contacts(seen_contacts),.blocked_contacts(blocked_contacts),.anchor_valid(anchor_valid),.anchor_contact(anchor_contact),.anchor_position(anchor_position),.event_valid(event_valid),.event_on(event_on),.event_serial(event_serial),.event_token(event_token),.event_note(event_note),.event_velocity(event_velocity),.event_glide(event_glide),.event_layers(event_layers),.cancel_valid(cancel_valid),.cancel_token(cancel_token),.response_ready(response_ready),.reply_valid(reply_valid),.reply_on(reply_on),.reply_token(reply_token),.reply_groups(reply_groups),.reply_code(reply_code),.reply_layers(reply_layers),.reply_map(reply_map),.reply_contact(reply_contact),.reply_generation(reply_generation),.expression_valid(expression_valid),.expression_token(expression_token),.expression_groups(expression_groups),.expression_layers(expression_layers),.expression_position(expression_position),.epoch_exhausted(epoch_exhausted),.protocol_error(protocol_error));
integer trace,script,status,kind,seq,mask,bad,cal,vel,delta,selected,timeout,countdown=0,delay_mode=3;
reg [4*9-1:0] positions;
reg pending=0,latched_on,cancel_seen=0;
reg [31:0] latched_token;
reg [6:0] latched_note;
reg [3:0] latched_layers;
integer layer,base,index;
integer stall_cycle=0;
always @(negedge clk)if(rst_n&&0)begin
    stall_cycle=stall_cycle+1;event_ready=stall_cycle%5!=0;reply_ready=stall_cycle%11>=4;
end
always @(posedge clk)if(rst_n)begin
    if(dut.on_valid&&dut.query_held)$fatal(1,"HELD_RETRIGGER");
    if(anchor_valid)begin
        $fdisplay(trace,"ON %0d %0d %0d %0d %0d %0d %0d",anchor_contact,dut.on_generation,dut.on_note,dut.on_velocity,dut.on_glide,dut.on_layers,anchor_position);
    end
    if(dut.release_valid&&dut.release_ready)$fdisplay(trace,"OFF %0d",dut.release_token);
    if(expression_valid)$fdisplay(trace,"MOVE %0d %0d %0d %0d",expression_token,expression_groups,expression_layers,expression_position);
    if(event_valid&&event_ready)begin
        $fdisplay(trace,"EVENT %0d %0d %0d %0d %0d %0d",event_on,event_token,event_note,event_velocity,event_glide,event_layers);
        pending<=1;countdown<=delay_mode;latched_on<=event_on;latched_token<=event_token;latched_note<=event_note;latched_layers<=event_layers;
        cancel_seen<=cancel_valid&&cancel_token==event_token;
    end
    if(pending&&cancel_valid&&cancel_token==latched_token)begin
        if(!cancel_seen)$fdisplay(trace,"CANCEL %0d",cancel_token);
        cancel_seen<=1;
        if(response_valid&&response_code==0)begin response_code<=6;response_groups<=0;response_layers<=0;response_map<=0;end
    end
    if(pending&&countdown>0)countdown<=countdown-1;
    if(response_valid&&response_ready)begin response_valid<=0;pending<=0;end
    if(pending&&countdown==1)begin
        response_valid<=1;response_token<=latched_token;
        response_code<=latched_on?((cancel_seen||(cancel_valid&&cancel_token==latched_token))?6:0):1;
        response_groups<=0;response_map<=0;response_layers<=latched_on&&!cancel_seen&&!(cancel_valid&&cancel_token==latched_token)?latched_layers:0;
        base=latched_layers==1?latched_note-60:(latched_note-60)*4;
        if(latched_on&&!cancel_seen&&!(cancel_valid&&cancel_token==latched_token))for(layer=0;layer<4;layer=layer+1)if(latched_layers[layer])begin
            response_groups[(base+layer)%32]<=1;response_map[layer*5+:5]<=(base+layer)%32;
        end
    end
end
task wait_ready;
begin
    timeout=0;
    while(!frame_ready)begin @(negedge clk);timeout=timeout+1;if(timeout>20000)$fatal(1,"FRAME_TIMEOUT");end
end
endtask
initial begin
    trace=$fopen("trace.txt","w");script=$fopen("commands.txt","r");
    repeat(3)@(negedge clk);rst_n=1;event_ready=1;reply_ready=1;
    while(!$feof(script))begin
        status=$fscanf(script,"%d %d %d %d %d %h %d %d %d\n",kind,seq,mask,bad,cal,positions,vel,delta,selected);
        if(status!=9)$fatal(1,"BAD_SCRIPT");
        if(kind==0)begin
            wait_ready();frame_valid=1;contact=mask;invalid=bad;position=positions;
            frame_sequence=seq;frame_calibration=cal;velocity=vel;glide=delta;layer_selection=selected;
            for(index=0;index<4;index=index+1)note_map[index*7+:7]=60+index;
            @(negedge clk);frame_valid=0;contact=0;position=0;note_map=0;velocity=0;glide=0;layer_selection=0;frame_calibration=0;invalid=0;
            wait_ready();repeat(40)@(negedge clk);
            $fdisplay(trace,"BOUNDARY %0d %0d %0d",frame_sequence,seen_contacts,blocked_contacts);
        end else if(kind==1)begin
            retire_valid=1;retire_token=seq;@(negedge clk);retire_valid=0;
        end else if(kind==2)begin
            repeat(2050)@(negedge clk);wait_ready();repeat(40)@(negedge clk);
            $fdisplay(trace,"BOUNDARY %0d %0d %0d",frame_sequence,seen_contacts,blocked_contacts);
        end else if(kind==3)delay_mode=500;
        else if(kind==4)begin repeat(600)@(negedge clk);delay_mode=3;end
    end
    $fdisplay(trace,"FLAGS %0d",{admission_error,watchdog_error,sensor_error,link_error,frame_error});
    if(protocol_error)$fatal(1,"ENDPOINT_PROTOCOL_ERROR");
    $fclose(script);$fclose(trace);$display("PASS frames NF=%0d",4);$finish;
end
endmodule
