open_project "D:/FPGA-Project/review/contact-rtl-timing-20261024-01/contact.gprj"
set_option -top_module note_contact_timing_probe
set_option -use_sspi_as_gpio 1
run all
exit
