module tb_contact;
reg clk=0;
always #5 clk=~clk;
wire rst_n;
wire on_valid;
wire [4:0] on_contact;
wire [7:0] on_generation;
wire [6:0] on_note;
wire [7:0] on_velocity;
wire [17:0] on_glide;
wire [3:0] on_layers;
wire release_valid;
wire [31:0] release_token;
wire move_valid;
wire [31:0] move_token;
wire [11:0] move_position;
wire retire_valid;
wire [31:0] retire_token;
wire finish_valid;
wire [31:0] finish_token;
wire [31:0] finish_groups;
wire event_ready;
wire response_valid;
wire [31:0] response_token;
wire [2:0] response_code;
wire [31:0] response_groups;
wire [3:0] response_layers;
wire [19:0] response_map;
wire reply_ready;
wire [4:0] query_contact;
wire on_ready;
wire release_ready;
wire event_valid;
wire event_on;
wire [30:0] event_serial;
wire [31:0] event_token;
wire [6:0] event_note;
wire [7:0] event_velocity;
wire [17:0] event_glide;
wire [3:0] event_layers;
wire cancel_valid;
wire [31:0] cancel_token;
wire response_ready;
wire reply_valid;
wire reply_on;
wire [31:0] reply_token;
wire [31:0] reply_groups;
wire [2:0] reply_code;
wire [3:0] reply_layers;
wire [19:0] reply_map;
wire [4:0] reply_contact;
wire [7:0] reply_generation;
wire expression_valid;
wire [31:0] expression_token;
wire [31:0] expression_groups;
wire [3:0] expression_layers;
wire [11:0] expression_position;
wire query_held;
wire [31:0] query_token;
wire [31:0] query_groups;
wire [3:0] query_layers;
wire [19:0] query_map;
wire epoch_exhausted;
wire protocol_error;
reg [327-1:0] stimulus[0:3626-1];
reg [327-1:0] controls=0;
assign {rst_n,on_valid,on_contact,on_generation,on_note,on_velocity,on_glide,on_layers,release_valid,release_token,move_valid,move_token,move_position,retire_valid,retire_token,finish_valid,finish_token,finish_groups,event_ready,response_valid,response_token,response_code,response_groups,response_layers,response_map,reply_ready,query_contact}=controls;
wire [416-1:0] observation={on_ready,release_ready,event_valid,event_on,event_serial,event_token,event_note,event_velocity,event_glide,event_layers,cancel_valid,cancel_token,response_ready,reply_valid,reply_on,reply_token,reply_groups,reply_code,reply_layers,reply_map,reply_contact,reply_generation,expression_valid,expression_token,expression_groups,expression_layers,expression_position,query_held,query_token,query_groups,query_layers,query_map,epoch_exhausted,protocol_error};
note_contact_adapter #(.SOURCE(1),.SERIAL_W(31),.INITIAL_SERIAL(2147483645)) dut(
.clk(clk),.rst_n(rst_n),
.on_valid(on_valid),
.on_contact(on_contact),
.on_generation(on_generation),
.on_note(on_note),
.on_velocity(on_velocity),
.on_glide(on_glide),
.on_layers(on_layers),
.release_valid(release_valid),
.release_token(release_token),
.move_valid(move_valid),
.move_token(move_token),
.move_position(move_position),
.retire_valid(retire_valid),
.retire_token(retire_token),
.finish_valid(finish_valid),
.finish_token(finish_token),
.finish_groups(finish_groups),
.event_ready(event_ready),
.response_valid(response_valid),
.response_token(response_token),
.response_code(response_code),
.response_groups(response_groups),
.response_layers(response_layers),
.response_map(response_map),
.reply_ready(reply_ready),
.query_contact(query_contact),
.on_ready(on_ready),
.release_ready(release_ready),
.event_valid(event_valid),
.event_on(event_on),
.event_serial(event_serial),
.event_token(event_token),
.event_note(event_note),
.event_velocity(event_velocity),
.event_glide(event_glide),
.event_layers(event_layers),
.cancel_valid(cancel_valid),
.cancel_token(cancel_token),
.response_ready(response_ready),
.reply_valid(reply_valid),
.reply_on(reply_on),
.reply_token(reply_token),
.reply_groups(reply_groups),
.reply_code(reply_code),
.reply_layers(reply_layers),
.reply_map(reply_map),
.reply_contact(reply_contact),
.reply_generation(reply_generation),
.expression_valid(expression_valid),
.expression_token(expression_token),
.expression_groups(expression_groups),
.expression_layers(expression_layers),
.expression_position(expression_position),
.query_held(query_held),
.query_token(query_token),
.query_groups(query_groups),
.query_layers(query_layers),
.query_map(query_map),
.epoch_exhausted(epoch_exhausted),
.protocol_error(protocol_error));
integer cycle,trace;
initial begin
    $readmemh("inputs.hex",stimulus);
    trace=$fopen("trace.hex","w");
    for(cycle=0;cycle<3626;cycle=cycle+1)begin
        @(negedge clk);controls=stimulus[cycle];
        #1;$fdisplay(trace,"%h",observation);
        @(posedge clk);#1;
    end
    $fclose(trace);$display("PASS contact cycles=%0d",3626);$finish;
end
endmodule
