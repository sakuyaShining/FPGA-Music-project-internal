# U9/C9 区域施工唯一入口

更新 2026-10-23T12:22:39.013317+08:00。原37项/6网验证基线aaa62f2与恢复包不变；本施工副本未晋升、不可投板。

当前原生工程：C:\Users\Sakuya\Documents\LCEDA-Pro\projects\FPGA-Music-U9ControlWork-20261023
PCB SHA256：b766e49ce032af4987c2afa3ed0c8ec4aeadfcd14dcc0f5b7ac7c2d1abd8f942
会话：286f24f0-495e-4b49-b7a5-392f3a38d1da；项目身份：6b570f10a9004c2a7374c39b14185fbbe64449a767876fe377667e630fc1e3c7。以文件实际哈希、session list及真实进程为准。

当前四层重铺、保存关闭重开严格DRC：0间距/0物理/0网表、58未连通/15网，227件597孔。426项参考比较无新增退化；899节点及外部焊盘保持。control-branches-native-review.json绑定当前哈希。原生67项为上一adb施工阶段，不能继续当最新状态。

U9=91/19mm180°，C9=99.25/16mm0°，R30=68.4/65.6mm90°。其他非铜原生属性严格一致。C9旧97.75位置已被真实器件包络检查否决，禁止恢复；旧CPL相应行失效。

供电/实际地、PRESET3、HARM_CS_N和触控复位保持闭合。新增35条远端控制线、11信号孔和8配套地孔恢复了原远端支路，但10个U9主连接未恢复：BUS_SCK、INPUT_LOAD_N、KEY_QH、ENC_A/B/PUSH、PRESET0/1/2、EDIT。PRESET0/1远端还有分岛。INPUT_LOAD_N用实际Top直连R32替代旧三孔绕行；全宽Ground15参考无缺口。

参考检查边界：已恢复信号孔按实际参与层选择参考层；INPUT_LOAD_N的Top/Inner16回流孔所需Ground15/2接触均0.204164mm²，Ground16实际0.140175mm²不被称为通过。继承ADDR3/M02/M03/旧复位参考缺口仍开放；低活动复位Ground2约6.110mm缺口例外不扩大到数据/时钟。RC_DRIVE孔Ground16接触0.1474mm²低于0.15偏好仍如实记录。

本轮固定单焊盘PRESET2两层、三层方法均终态无路径、未导入；不能据此认定整网无解。已改变目标表示为同一实际连通铜岛的全部焊盘/铜端点/过孔，物理/参考/回流门限不变。检查control-next-plan.json及真实进程；即使route_complete也须完整几何预检后才能原生应用，之后必须四层重铺、严格DRC、保存重开、实铜/899节点/参考复核。绝不能重复旧apply。

Use actual construction-state hash/session and live process. Current b766 native has58 unconnected/15nets/597vias; remote branches restored, ten U9 main links remain. PRESET2 fixed-pad two/three-layer trials are terminal failures and not imported. Current offline trial uses whole connected target-copper-island goals rather than a single fixed pad, with unchanged physical/reference/return limits. Inspect control-next-plan.json and actual process before resuming; do not duplicate or apply incomplete/unreviewed plans. Restore ten controls before promotion over aaa37; then BUS_MOSI/ADDR0/1/2/MUX_DISABLE. PRESET3/PDN/HARM/touchreset remain closed. Keep R30/U9/C9 exact poses; preserve RC_DRIVE and shared rails. No fab release.

恢复包construction-native-NOT-FOR-FAB.zip包含当前19原生文件及本README；control-source-native.zip保留adb/67阶段，pdn-source-native.zip保留稳定PDN阶段，bck-loss-native.zip为旧音频参考退化失败证据。原37项恢复包../native-touch-reset-WORK-IN-PROGRESS.zip保持f28dab61不变。

最终屏SKU/CTP/接口/线束/机械及采购整价交期仍未锁定；没有同版投板制造包。实物全部UNMEASURED，不下单付款外发，不改产品RTL。PCB完整定稿与最终硬件选型均落定后才删除pcb自动唤醒。
