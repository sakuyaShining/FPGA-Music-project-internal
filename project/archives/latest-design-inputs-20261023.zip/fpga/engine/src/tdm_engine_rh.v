//=============================================================================
// tdm_engine.v —— 时分复用（TDM）合成引擎
//
// ============================ 为什么要有它 ============================
// 全并行版本每加一个声部就要【复制一整套运算硬件】：
//     4 声部实测 BSRAM 32/46（70%）、DSP 24/24（100%）
//     → 天花板约 5 声部 = 40 个振荡器
// 但 27 MHz ÷ 46875 Hz = 每样本 576 个时钟，而每个振荡器每样本只用 1 拍：
//     全并行：8 套硬件 × 每样本用 1 拍 / 576 拍   → 利用率 0.17%
//     TDM：1 套硬件 × 把 576 拍用满           → 可服务数百个振荡器
//
// 更关键的是【状态存储方式变了】：
//     全并行：正弦表按读端口复制 —— 8 泛音 = 8 块 BSRAM，32 泛音 = 32 块
//     TDM：所有振荡器轮流用【同一个读端口】→ 正弦表只要 1 块
// 所以 TDM 下 BSRAM 不再随时隙数增长，瓶颈从存储搬到了"每拍能不能算完一个振荡器"。
//
// ==================== 逐位一致：本模块的硬性验收标准 ====================
// TDM 是【同一套数学、不同的调度】。所以它有一个天然的黄金参考：
// 现有的全并行引擎。本模块的设计目标是：
//     相同参数下，TDM 输出序列 ≡ 全并行引擎输出序列（允许一个固定延迟）
// 这条一致性一旦成立，就同时证明了：时隙调度、BSRAM 状态读写、
// 流水线对齐、地址回绕 —— 全部正确。比"频谱看着对"强一个数量级。
//
// 为此必须精确复刻并行设计里两个【容易被忽略】的细节：
//
// 细节 1：查表用的是【推进前】的相位
//     osc_core.v: addr_r <= phase_in[...]（相位寄存器本身，不是 phase+inc）
//
// 细节 2：相位与包络之间有【一拍错位】，这是流水线造成的，不是 bug
//     并行设计的逐拍推导（P(n)=第 n 拍后的相位，E(n)=第 n 拍后的包络电平）：
//         prod(n) 用的表项 = sine_tab[P(n-3)]      ← 相位来自 3 拍前
//         prod(n) 用的幅度 = f(amp, E(n-2))        ← 包络来自 2 拍前
//     也就是【包络比相位新一拍】。
//     本模块如果"想当然地对齐"，输出就会与并行版差一个样本的包络位移，
//     逐位比对必然失败。
//     复刻办法：amp_eff 用【包络推进后】的值 env_next，而不是当前值。
//     这样"相位取当期、包络取下一期"，相对错位与并行版完全一致。
//
// ============================== 流水线 ==============================
// 令 sc 为时钟计数（0..NSLOT-1，由 sample_en 复位，NSLOT 是 2 的幂所以自然回绕）。
// 为了让"第 sc 拍的累加 = 第 sc 号时隙"，地址阶段要【提前 LAT 拍】：
//
//     地址 = (sc + LAT) mod NSLOT      LAT = 4
//
//   sc+0 : 发出 BSRAM 地址（相位/包络/增量/幅度/门）
//   sc+1 : 数据回来 → 算 env_next、amp_eff、表地址、phase_next；发出写回
//   sc+2 : 正弦表数据回来（同步读）→ 连同 amp_eff 一起打拍
//   sc+3 : prod = (sine × amp_eff) >>> 16
//   sc+4 : acc += prod        ← 此刻 sc 对应的正是"第 sc 号时隙"
//
//   于是第 sc 拍的累加恰好属于时隙 sc 周期边界干净，不需要额外的排空周期。
//
//   sc=0 拍清累加器，sc=NSLOT-1 拍锁存输出。
//
// ============================ 资源账（预期） ============================
//   NSLOT=256 时：相位 24 位 + 增量 24 位 + 包络 16 + 状态 3 + 门 2 + 幅度 8
//                 = 77 位 × 256 = 19712 位 ≈ 1.1 块 18Kb BSRAM
//   正弦表 1 块。合计约 4~5 块 —— 而全并行做 32 个振荡器就要 32 块。
//=============================================================================

`timescale 1ns/1ps

module tdm_engine_rh #(
    parameter NSLOT   = 32,      // 时隙数 = 同时活跃振荡器数（必须是 2 的幂）
    parameter PHASE_W = 24,
    parameter TAB_AW  = 8,
    parameter AMP_W   = 8,
    parameter ENV_W   = 16,
    parameter STG_W   = 3,
    parameter OUT_W   = 24,
    parameter GAIN_UP = 0,       // 电平增益（左移）
    parameter SHIFT   = 0,       // 留量（右移）
    // ---- 表情调制（滑音/颤音）：见 pitch_mod.v 与文件内"表情调制"一段 ----
    //   开关与深度不在这里（编译期参数做不成"演奏时可调"），
    //     改由 pmod_cfg 端口在运行时给。
    parameter PART      = 8,     // 每组泛音数（组号 = slot / PART）。NSLOT=PART×组数
    parameter FINGER_EXPR = 0,   // Opt-in; omitted ports preserve legacy bit accuracy.
    parameter EXPLICIT_START = 0, // Legacy direct clients may omit load_start.
    parameter INSTRUMENT_ENV=0,
    parameter RIGHT_TIMBRE = 0 // Opt-in, disabled path is structurally unchanged.
)(
    input  wire clk,
    input  wire rst_n,
    input  wire sample_en,       // 周期起始（每 NSLOT 拍一次）
    input  wire clr,             // 保留：正常流程不用（见下方"上电初值"说明）
    input  wire pclr,            // 保留：正常流程不用
    input  wire gate_in,         // 演奏门：门沿检测在【周期级】做，见下
    // 2026-10-01 已删除 `boost_en` 端口。
    //   它是第 28~31 轮"补偿相位 4 周期滞后"实验的遗留，实测有害且从未启用。
    //   该"滞后"的真身已在 10-01 查清 = 【累加窗口横跨两代状态】，
    //   现已修复（见文件末尾"级 5：累加"的窗口旋转注释）。
    //   补偿一个不存在的症状的通路已无存在理由。

    // ---- 时隙参数装载 ----
    input  wire                        load_en,
    input  wire [$clog2(NSLOT)-1:0]    load_slot,
    input  wire [PHASE_W-1:0]          load_inc,
    input  wire [AMP_W-1:0]            load_amp,
    input  wire                        load_gate,
    input  wire [7:0]                  load_start_tag,
    // 每时隙的包络参数 = {s_lvl[15:0], d_m[1:0], d_k[4:0]}  （23 位）
    //   这是"构造泛音结构"的核心：让每个泛音有自己的【衰减速率】与【衰减终点】，
    //   频谱才能随时间演化（钟/马林巴/钢琴的音色本质）。
    input  wire [22:0]                 load_epar,
    input wire [39:0] load_env, // custom flag / attack / phase dividers / release
    // ---- 包络参数（全时隙共用；与并行版一致，为编译期常量时最省）----
    input  wire        env_en,
    input  wire [ENV_W-1:0] a_inc,
    input  wire [ENV_W-1:0] d_inc,
    input  wire [1:0]  d_m,
    input  wire [4:0]  d_k,
    input  wire [ENV_W-1:0] s_lvl,
    input  wire [ENV_W-1:0] r_inc,
    input  wire [1:0]  r_m,
    input  wire [4:0]  r_k,
    input  wire [ENV_W-1:0] env_cutoff,
    input  wire        exp_mode,

    // ---- 表情调制：滑音初值随装载进入待生效区；颤音参数见 pitch_mod ----
    input  wire signed [17:0]          load_gq,

    //-------------------------------------------------------------------------
    // 运行时调制参数（2026-10-02：由编译期参数改成一根端口总线）
    //   { lfo_inc[23:0], vib_depth[15:0], glide_step[15:0],
    //     vib_en, glide_en }                                    = 58 位
    //   为什么打包成一根：pitch_mod 的参数要变成"演奏时可写"，
    //   而 tdm_engine 在 8 个测试台里被实例化 —— 打成一包以后，
    //   每个测试台只需要多接一行 `.pmod_cfg(58'd0)`。
    //   `58'd0` = 两个开关全关 = poff ≡ 0 = 与加调制之前【逐位相同】。
    //-------------------------------------------------------------------------
    input  wire [57:0]                 pmod_cfg,
    input  wire [NSLOT/PART-1:0]       finger_active,
    input  wire [(NSLOT/PART)*18-1:0]  finger_offsets,

    // Independent performance modifiers. Q8 unity=256; bounded boost only.
    input wire [PART*10-1:0] timbre_gain_q8,
    input wire [NSLOT/PART-1:0] timbre_voice_mask,

    // ---- 输出 ----
    output reg  signed [OUT_W-1:0] sample_out,
    output wire [31:0]             sum_raw,      // 未饱和的原始和（调试/比对用）
    output wire [$clog2(NSLOT)-1:0] slot_dbg
);

    localparam integer LAT  = 4;
    localparam integer EPW=31+(INSTRUMENT_ENV?40:0);
    localparam integer CORE_AMP_W = AMP_W + 8;      // 16：与并行版一致
    localparam integer ENV_FRAC   = 7;              // 与并行版一致
    localparam integer SW = $clog2(NSLOT);

    //-------------------------------------------------------------------------
    // 状态存储（每时隙一份）
    //   相位、增量、包络电平、包络段、门（当前/上一次）、幅度
    //   全部做成同步读 → 能映射到 BSRAM
    //-------------------------------------------------------------------------
    reg [PHASE_W-1:0] phase_mem [0:NSLOT-1];
    reg [PHASE_W-1:0] inc_mem   [0:NSLOT-1];
    reg [ENV_W-1:0]   env_mem   [0:NSLOT-1];
    reg [STG_W-1:0]   stg_mem   [0:NSLOT-1];
    reg               gcur_mem  [0:NSLOT-1];   // 当前门（已生效）
    reg               gq_mem    [0:NSLOT-1];   // 上一次的门（触发沿检测）
    reg [AMP_W-1:0]   amp_mem   [0:NSLOT-1];

    //-------------------------------------------------------------------------
    // 待生效装载区（2026-10-01）：装载的【样本边界对齐】机制
    //
    //   【为什么需要它 —— 起音段错位的真正根因】
    //     旧版 load_en 直接写 inc_mem/amp_mem/gcur_mem：
    //       · 装载落在样本周期中间，各时隙在自己的访问时刻"各看各的"——
    //         同一个音符的各时隙，访问时刻在装载之前的当周期就看到新
    //         inc/门，在之后的下个周期才看到 → 各时隙的相位起点/起音点
    //         相差最多 1 个样本周期；
    //       · 而并行引擎的参数在 sample_en 拍同时生效。
    //       → 包络时间轴与正弦时间轴互相错开，且逐时隙不同——
    //         这就是"包络关闭逐位一致、打开后起音段数百样本不符、
    //         稳态又一致"的完整解释（改包络步进/加 boost 均无效的原因：
    //         它们没碰时间轴错位）。
    //
    //   【机制】装载写入"待生效"区并打上【装载时刻的周期奇偶】标签；
    //     各时隙在自己的访问时刻检查：标签 ≠ 当前周期奇偶 ⇒ 装载发生在
    //     之前的周期 ⇒ 本拍统一消费（inc/amp/门同时换成新值并写回状态区）。
    //     于是无论装载落在周期内哪一拍、无论各时隙访问时刻先后，
    //     全部时隙都在【装载后的第一个完整样本周期】统一生效——
    //     与并行引擎"sample_en 拍生效"的语义严格对齐。
    //
    //   【为什么 1 位奇偶就够】装载在周期 p 打标，消费必发生在 p+1
    //     （每时隙每周期恰好访问一次），不存在隔多拍才消费的路径，
    //     所以只需区分"装载当周期"与"之后"，1 位足矣。
    //
    //   【epar 也走此通路 —— 2026-10-01 修订】
    //     原设计刻意让 epar 即时生效，理由是"包络参数是音色【调制】量
    //     （谱心/谱宽轴），逐拍即时生效正是需要的语义"。
    //     这个理由对【连续调制】成立，但 epar 同时承担【音色预设切换】——
    //     那是离散的音符事件，应当与 inc/amp/gate 一起原子更新，
    //     否则同一次预设切换里 epar 会比其余三个最多早一个样本周期生效，
    //     重新引入本条通路专门要消除的那类亚周期偏斜。
    //     两者的实际差别只有 ≤1 个样本周期（21.3 µs）：
    //       · 对连续调制：无感 （远小于任何可感知的调制速率）
    //       · 对预设切换：消除偏斜
    //     所以改成与其余三个参数完全对称，语义更干净：
    //     **一次音符/预设事件 = 一次原子参数更新**。
    //-------------------------------------------------------------------------
    reg               pv_mem [0:NSLOT-1];        // 待生效有效
    reg               pp_mem [0:NSLOT-1];        // 装载时刻的周期奇偶标签
    reg               pg_mem [0:NSLOT-1];        // 待生效门
    reg [PHASE_W-1:0] pi_mem [0:NSLOT-1];        // 待生效 inc
    reg [AMP_W-1:0]   pa_mem [0:NSLOT-1];        // 待生效 amp
    reg [EPW-1:0]        pe_mem [0:NSLOT-1];        // pending start + epar

    //-------------------------------------------------------------------------
    // 每时隙包络参数（构造泛音结构）
    //   {s_lvl[15:0], d_m[1:0], d_k[4:0]}
    //
    //   为什么"每泛音独立包络"是关键：
    //     8 泛音 + 运行时幅度 = 拉杆风琴（Hammond 1935）—— 频谱【静态】，
    //     只是把固定的谐波配方调出来。
    //     而真实的钟/钢琴/马林巴，高次泛音衰减得比基频快得多 ——
    //     频【谱】随时间演化，这才是音色的物理本质（模态合成）。
    //     要做到这一点，必须让每个泛音有自己的 d_m/d_k（衰减速率）
    //     与 s_lvl（衰减终点）。
    //
    //   为什么在 TDM 里几乎免费、在全并行里做不到：
    //     全并行：包络参数变寄存器后，32 套 osc_env 各要一套变量移位器
    //             → 逻辑 8047 涨到 26226，超 20736 上限，综合失败。
    //     TDM：包络只例化【一套】（时分复用），参数只是多几个存储字段
    //             → 512 × 23 位 ≈ 11.8 Kbit ≈ 0.7 个 BSRAM 块。
    //
    //   上电默认值刻意取成与模块输入端口相同的默认
    //   (d_m=3, d_k=12, s_lvl=22938) —— 这样【不装载】时行为与原来完全一致，
    //   现有的"与全并行逐位一致"回归测试必须仍然全绿。
    //-------------------------------------------------------------------------
    localparam [22:0] EPAR_DEF = {16'd22938, 2'd3, 5'd12};

    reg [EPW-1:0] epar_mem [0:NSLOT-1];

    // 待生效的【滑音初值】（每时隙一份，与 inc/amp/gate/epar 同一个消费拍生效）
    //   为什么不能从 note_map 直写 gq：见 pitch_mod.v 顶部注释 ——
    //   直写会出现"旧 inc × 新 gq"的那一个样本（同一样本混两代状态）。
    reg signed [17:0] pgq_mem [0:NSLOT-1];

    reg signed [15:0] sine_tab  [0:(1<<TAB_AW)-1];

    //-------------------------------------------------------------------------
    // 上电初值：相位/包络/门状态全部为 0
    //
    //   第四轮的关键认识：**根本不需要"清零"这个动作。**
    //   BSRAM 上电本来就是 0（Gowin 支持存储器初值），仿真的 X 只是没有初值而已。
    //   前四轮我一直在跟"清零窗口的瞬态"搏斗 —— 清零停止那一刻的第一笔写回
    //   总会让某个时隙少一次推进，释放点挪到哪，受害的就换成哪一批时隙。
    //   把"清零"整个去掉，这一整类问题就不存在了：
    //       上电（全 0）→ 装载 inc/amp/gate → 直接开跑
    //   每个时隙每周期恰好被回写一次，从同一个 0 起跑，天然均匀。
    //
    //   `clr` / `pclr` 端口保留（便于将来需要时重新初始化），但正常流程不用。
    //-------------------------------------------------------------------------
    integer ii;

    initial begin
        $readmemh("sine256.hex", sine_tab);
        for (ii = 0; ii < NSLOT; ii = ii + 1) begin
            phase_mem[ii] = {PHASE_W{1'b0}};
            env_mem  [ii] = {ENV_W{1'b0}};
            // 包络初值 = IDLE，门 = 0（2026-10-01 改，理由见下方 init 处）：
            //   上电寂静，起音只由显式音符事件（load_gate 0→1 沿）触发。
            //   旧的"门置起、上电即 ATK"是幽灵音符，已废除。
            //   （包络推进与查表的相对偏斜关系不变，见模块头"细节 2"。）
            stg_mem  [ii] = {STG_W{1'b0}};   // ST_IDLE
            // 2026-10-01：门初值改为 0（原为 1）。
            //   旧值是为了"上电即触发"对齐并行引擎的复位行为；但它是
            //   【幽灵音符】——装载真正的音符前包络就在爬升，是起音段
            //   无法对齐的帮凶之一。现在音符事件一律由 load_gate 的
            //   0→1 沿显式触发（样本边界对齐），上电必须寂静。
            gq_mem   [ii] = 1'b0;
            gcur_mem [ii] = 1'b0;
            inc_mem  [ii] = {PHASE_W{1'b0}};
            amp_mem  [ii] = {AMP_W{1'b0}};
            epar_mem [ii] = EPAR_DEF;        // 与端口默认一致 → 不装载＝原行为
            pv_mem   [ii] = 1'b0;            // 待生效区：上电无待办
            pp_mem   [ii] = 1'b0;
            pg_mem   [ii] = 1'b0;
            pi_mem   [ii] = {PHASE_W{1'b0}};
            pa_mem   [ii] = {AMP_W{1'b0}};
            pe_mem   [ii] = EPAR_DEF;        // 与 epar_mem 初值一致
            pgq_mem  [ii] = 18'sd0;          // 滑音初值：上电为 0（不滑）
        end
    end

    //-------------------------------------------------------------------------
    // 时隙计数：sample_en 复位，NSLOT 是 2 的幂所以自然回绕
    //-------------------------------------------------------------------------
    reg [SW-1:0] sc;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)          sc <= {SW{1'b0}};
        else if (sample_en)  sc <= {SW{1'b0}};
        else                 sc <= sc + 1'b1;
    end

    //-------------------------------------------------------------------------
    // 周期奇偶（装载标签用）
    //   翻转点必须在【周期最后一拍 sc=NSLOT-1】，不能在 sample_en：
    //     各时隙的读取散布在 sc 0..31 整个周期里，若奇偶在周期中间
    //     （sc=0 拍的边沿）翻转，则 sc=0 拍的读取拿到旧值、sc≥1 拿到
    //     新值 —— 恰好读在 sc=0 的那个时隙会晚一个周期消费（实测
    //     slot 0 / slot 4 各差一拍、其余准时，混合延迟比对失败）。
    //     在周期末尾翻转，奇偶在【整个周期内是常数】，所有时隙判定一致。
    //-------------------------------------------------------------------------
    reg ppar;
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)              ppar <= 1'b0;
        else if (sc == NSLOT-1)  ppar <= ~ppar;
    end

    // 地址阶段提前 LAT 拍
    wire [SW-1:0] slot_addr = sc + LAT[SW-1:0];

    assign slot_dbg = sc;

    //-------------------------------------------------------------------------
    // 级 1：同步读状态
    //-------------------------------------------------------------------------
    reg [PHASE_W-1:0] ph1,  inc1;
    reg [ENV_W-1:0]   env1;
    reg [STG_W-1:0]   stg1;
    reg               gc1, gq1;
    reg [AMP_W-1:0]   amp1;
    reg [SW-1:0]      sl1;
    reg [EPW-1:0]        epar1 = EPAR_DEF;   // 该时隙的包络参数（必须给初值，
                                          //   否则首拍为 X 会污染包络存储）
    // 待生效装载区读出（与状态同地址同拍）
    //   ppr1 = 【读取时刻】的周期奇偶。判定必须用它而不是当前 ppar：
    //     级1读取与级2使用隔着 LAT=4 拍，跨样本边界时 ppar 已翻转，
    //     用当前值会把"应消费"误判成"未消费"（或反之），逐时隙差一拍。
    reg               pv1, pp1, pg1;
    reg [PHASE_W-1:0] pi1;
    reg [AMP_W-1:0]   pa1;
    reg [EPW-1:0]        pe1;        // pending start + epar
    reg               ppr1;
    reg signed [17:0] pgq1;       // 待生效滑音初值（与状态同地址同拍读出）

    //-------------------------------------------------------------------------
    // 级 2 组合：包络推进 + 有效幅度 + 表地址 + 相位推进
    //-------------------------------------------------------------------------
    wire [ENV_W-1:0] env_n;
    wire [STG_W-1:0] stg_n;

    //-------------------------------------------------------------------------
    // 装载消费判定（样本边界对齐的核心）
    //   consume = 本时隙有待生效装载，且它标记于【上一个】周期
    //   满足时，本拍全部换成新值：门沿检测、相位推进、幅度乘法统一用新参数。
    //-------------------------------------------------------------------------
    wire consume = pv1 & (pp1 != ppr1);
    wire release_only = consume & gc1 & ~pg1;
    wire replace_params = consume & ~release_only;
    wire [PHASE_W-1:0] eff_inc  = replace_params ? pi1 : inc1;
    wire [AMP_W-1:0]   eff_amp  = replace_params ? pa1 : amp1;
    wire               eff_gate = consume ? pg1  : gc1;
    wire [22:0]        eff_epar = replace_params ? pe1[22:0] : epar1[22:0];

    //-------------------------------------------------------------------------
    // 门沿检测：按时隙各判各的，但门值已经过【样本边界对齐】
    //
    //   【2026-10-01 修复记录】旧版直接用 gcur_mem（装载即时写入），
    //     同一音符的各时隙在各自访问时刻看到门沿，起音点相差最多 1 个
    //     样本周期 → 包络时间轴与正弦时间轴逐时隙错位 → 起音段无法与
    //     并行引擎逐位对齐。现 eff_gate 来自待生效区（见"待生效装载区"
    //     注释块），所有时隙在同一周期边界统一切换，与并行引擎
    //     "sample_en 拍同时生效"的语义严格一致。
    //     曾经试过"把门沿提升到周期级统一判定"（发 1 拍宽脉冲）失败，
    //     原因：包络状态机按各时隙访问时刻推进，绝大多数时隙不在那一拍
    //     访问，脉冲无人消费——正确做法是让门值本身按周期边界切换，
    //     而不是发脉冲。
    //-------------------------------------------------------------------------
    wire trig_on  = (eff_gate & ~gq1) |
                   (EXPLICIT_START && consume && pg1 && pe1[30:23] != epar1[30:23]);
    wire trig_rel = ~eff_gate & gq1;

    // Extended metadata shares exactly the pending/active epar lifetime.
    // No extra lookup keyed by a mutable preset: released/old notes keep their copy.
    wire [EPW-1:0] next_epar,pending_epar;
    wire [ENV_W-1:0] env_calc,env_a_inc;
    wire [STG_W-1:0] stg_calc;
    wire [1:0] env_r_m;wire [4:0] env_r_k;
    generate if(INSTRUMENT_ENV)begin: per_instrument_env
        wire [39:0] eff_env=replace_params?pe1[70:31]:epar1[70:31];
        wire custom=eff_env[35];
        reg [14:0] phase_count=0,phase_read=0;
        always @(posedge clk or negedge rst_n)begin
            if(!rst_n)begin phase_count<=0;phase_read<=0;end
            else begin
                if(sc==NSLOT-1)phase_count<=phase_count+1'b1;
                phase_read<=phase_count;
            end
        end
        wire [3:0] shift=(stg1==1)?eff_env[34:31]:(stg1==2)?eff_env[14:11]:(stg1==4)?eff_env[10:7]:4'd0;
        wire [14:0] mask=~(15'h7fff << shift);
        wire tick=(phase_read & mask)==0;
        wire hold_level=custom&&!tick&&!trig_on&&!trig_rel;
        assign env_n=hold_level?env1:env_calc;
        assign stg_n=hold_level?stg1:stg_calc;
        assign env_a_inc=custom?eff_env[30:15]:a_inc;
        assign env_r_m=custom?eff_env[6:5]:r_m;
        assign env_r_k=custom?eff_env[4:0]:r_k;
        assign next_epar={eff_env,EXPLICIT_START&&replace_params?pe1[30:23]:epar1[30:23],eff_epar};
        assign pending_epar={load_env,EXPLICIT_START?load_start_tag:8'd0,load_epar};
    end else begin: legacy_env
        assign env_n=env_calc;assign stg_n=stg_calc;
        assign env_a_inc=a_inc;assign env_r_m=r_m;assign env_r_k=r_k;
        assign next_epar={EXPLICIT_START&&replace_params?pe1[30:23]:epar1[30:23],eff_epar};
        assign pending_epar={EXPLICIT_START?load_start_tag:8'd0,load_epar};
    end endgenerate

    osc_env #(.ENV_W(ENV_W), .STG_W(STG_W)) u_env (
        .lvl_i    (env1),
        .stg_i    (stg1),
        .trig_on  (trig_on),
        .trig_rel (trig_rel),
        .a_inc    (env_a_inc),
        .d_inc    (d_inc),
        .d_m      (eff_epar[6:5]),       // 每时隙 + 待生效（原来是全局 d_m）
        .d_k      (eff_epar[4:0]),       // 每时隙 + 待生效（原来是全局 d_k）
        .s_lvl    (eff_epar[22:7]),      // 每时隙 + 待生效（原来是全局 s_lvl）
        .r_inc    (r_inc),
        .r_m      (env_r_m),
        .r_k      (env_r_k),
        .cutoff   (env_cutoff),
        .exp_mode (exp_mode),
        .lvl_o    (env_calc),
        .stg_o    (stg_calc)
    );

    // 关于"幅度该用包络的哪一步"——本轮试过但【实测不支持】的一条路
    //
    //   理论推导：并行 prod(n) 用相位 P(n-3) 与包络 E(n-2)，偏斜 +1；
    //   TDM 访问 n 用相位 P(n) 与 env_n=E(n)，偏斜 0 —— 差一步。
    //   于是加了一级串联的 osc_env（env_nn = f(env_n)）让包络多走一步。
    //
    //   **实测：不符数 759 → 776，没有改善。**
    //   所以这条推导虽然自洽，但不是本问题的成因，故【回退】，
    //   不把说不清的东西留在设计里。
    //
    //   已确认的事实：
    //     · 包络存储轨迹两者完全一致（TDM 领先一格后 0/2499 不同）
    //     · 幅度对齐也是对的（按各自时隙的 amp 反算，包络同为 ≈1170）
    //     · 不符只出现在样本 1~780（起音+衰减段），延音段 0 处不符
    //   → 剩余差异在起音/衰减的动态过程中，尚未定位。见验收文档"遗留问题"。
    // 关于"幅度该用包络的哪一步"—— 已实测【不是成因】，故不引入第二级
    //
    //   推理链（第十二轮）：
    //     并行 prod(n) 用相位 P(n-3) 与包络 E(n-2)  → 包络比相位新一步
    //     TDM 访问 n  用相位 P(n)   与 env_n=E(n)   → 偏斜 0，低一步
    //   于是加了一级串联 osc_env 让幅度多用一步（env_nn = f(env_n)）。
    //
    //   **实测（决定性）**：
    //     · env_n 与 env_nn 确实相差 +117（起音段每周期都对）
    //     · 但输出比值 TDM/并行 几乎纹丝不动：0.9965 → 0.9962
    //   加入整整一个包络步进（理论上应带来 +0.4% 的变化），
    //   输出只动了 0.07% —— **说明包络电平不是这个 0.35% 缺口的成因**。
    //
    //   这一条排除了"包络电平 / 配对步数"这一整类假设，
    //   所以不把无用的第二级留在设计里。
    //   幅度用【读到的】包络 env1（而不是推进后的 env_n）—— 与并行引擎语义一致
    //
    //   对照 osc_additive.v：并行 amp_eff_q(n) = f(amp8, env_lvl_q(第 n-1 拍))
    //   用的是【存储值】；而 env_n = f(env1) 是【存储值 +1 步】。
    //   采用 env1 与并行语义一致。
    //
    //   但必须如实说明：**这一改动对输出没有任何影响**（实测不符数 777 → 777）。
    //     第十四轮还实测过 env_n（快一步）与串联第二级（快两步），
    //     三者对输出【完全等价】。也就是说"幅度用哪一步包络"这件事
    //     在本设计里根本不敏感 —— 说明起音段那 777 处不符的成因不在这里。
    //
    //   第十四轮确立的可靠事实（单时隙掩码 + 慢包络，无歧义）：
    //     **TDM 的 amp3 与并行的 amp_eff_q[0] 逐拍完全相等，零偏移。**
    //   即：包络轨迹、幅度轨迹都已证明正确。
    wire [31:0] amp_prod = {24'd0, eff_amp} * {16'd0, env1};
    wire [CORE_AMP_W-1:0] amp_env = amp_prod[AMP_W + ENV_W - 2 : ENV_FRAC];
    wire [CORE_AMP_W-1:0] amp_byp = eff_amp << (CORE_AMP_W - AMP_W);
    wire [CORE_AMP_W-1:0] amp_eff = env_en ? amp_env : amp_byp;


    // RIGHT_TIMBRE modifies only the read-side amplitude. Never writes base
    // amplitudes, phases, increments, gates, envelope state, tags or velocity.
    // Snapshot all coefficients/mask at logical slot0, before the entire rotated
    // accumulation traversal; do not snapshot at the unrelated sample_en edge.
    wire [CORE_AMP_W-1:0] rh_amp_eff;
    generate if (RIGHT_TIMBRE) begin: right_timbre
        reg [PART*10-1:0] gain_frame;
        reg [NSLOT/PART-1:0] mask_frame;
        wire first_slot = sl1 == 0;
        //   ★ 2026-10-22 (M1-面积)：原来先把整帧选一遍再取一片 ——
        //       gain_use = first_slot ? timbre_gain_q8    : gain_frame     (80 位 2:1)
        //       mask_use = first_slot ? timbre_voice_mask : mask_frame     (64 位 2:1)
        //       raw_gain = gain_use[(sl1 % PART)*10 +: 10]
        //       rh_amp_eff = mask_use[sl1/PART] ? boosted : amp_eff
        //   但 first_slot 就是 sl1==0，此刻 sl1%PART==0、sl1/PART==0，
        //   两个宽 mux 实际只用到第 0 片，另外 70 位 / 63 位是白送的组合逻辑。
        //   改成"先取片、再选"，逐位等价：
        //     first_slot 时两边都取第 0 片；!first_slot 时两边都取 frame 的对应片。
        //   这条同时落在 amp2 的 −5.176 ns 路径上（`mask_use[sl1/PART]` 是 64:1 mux）。
        wire [9:0] raw_gain = first_slot ? timbre_gain_q8[9:0]
                                         : gain_frame[(sl1 % PART)*10 +: 10];
        wire [9:0] gain = raw_gain < 10'd256 ? 10'd256 : raw_gain;
        wire [CORE_AMP_W+9:0] scaled = amp_eff * gain;
        wire [CORE_AMP_W-1:0] boosted = (|scaled[CORE_AMP_W+9:CORE_AMP_W+8]) ?
                   {CORE_AMP_W{1'b1}} : scaled[CORE_AMP_W+7:8];
        wire mask_bit = first_slot ? timbre_voice_mask[0] : mask_frame[sl1/PART];
        assign rh_amp_eff = mask_bit ? boosted : amp_eff;
        always @(posedge clk or negedge rst_n) begin
            if(!rst_n) begin
                gain_frame <= {PART{10'd256}};
                mask_frame <= 0;
            end else if(first_slot) begin
                gain_frame <= timbre_gain_q8;
                mask_frame <= timbre_voice_mask;
            end
        end
    end else begin: no_right_timbre
        assign rh_amp_eff = amp_eff;
    end endgenerate

    // 表地址用【推进前】的相位（细节 1）
    //   第二十二轮：试过在【读侧】修正 slot LAT-1 的一周期领先
    //     （`tab_phase = (sl1 == LAT-1) ? ph1 - inc1 : ph1`）。
    //   **实测：slot 3 的延迟仍是 1（与修正前完全相同），而多时隙组合
    //     的不符数从 345 变成 360（略差）。** 故【已回退】。
    //   机理虽已查明（见下方长注释），但"减一个 inc"并不能把它对齐 ——
    //   说明领先量并不等于一个 inc，或领先发生在写入之外的环节。
    //   在把这一点用实验钉死之前，不保留无依据的改动。
    //   第二十七轮：查表相位【减去 3×inc】
    //
    //   实测（本轮）：TDM 的【正弦序列】比并行恒定滞后 3 个周期
    //   （段跳变点：并行 n=8/13/19/24，TDM n=11/16/22，差恒为 3），
    //   而幅度 amp3 已证明逐拍完全相等 → 差的在【正弦侧】。
    //
    //   这解释了此前所有困惑：
    //     · 包络关闭时幅度是常数 → 3 周期偏移只是整体延迟，被延迟搜寻吸收
    //     · 包络打开时幅度在变 → 相对错位显现
    //     · 改"包络用哪一步"全部中性 → 差的是正弦侧，不是幅度
    //     · 第 21/22 轮补 1 个 inc 无效 → 偏移量是 3，不是 1
    //
    //   修法：只在【读侧】把查表相位减掉 3×inc（写入路径不动，
    //   所以不触及已验证的 BSRAM 通路）。
    //   3×inc 用移位加法实现，避免乘法器。
    //   第二十七轮：试过在读侧加减 3×inc 去追那 3 个周期的正弦滞后 ——
    //     **两个方向都得到 2464/2481（几乎全错）**，说明"减/加 3×inc"
    //     并不是正确的追法（3×inc 折算成查表步进是 1.62 步，不是整数步）。
    //     已回退。真正的修法需要让相位与幅度在【同一条时间轴】上，
    //     而不是在查表地址上做小数平移。
    //
    //   第二十八轮试过"启动时多推进 3 次"（boost）—— 第二十九轮实测
    //     **没有减少滞后**（回退前地址滞后 4 个周期，与不加 boost 时一致），
    //     已按纪律【回退】，不留无依据的代码。
    //     滞后量需在无 boost 的干净条件下重新测定。
    //   第二十九轮定稿：查表相位【加 4×inc】
    //   实测（本轮，无 boost 的干净条件）：
    //     TDM 跳变点 5,11,16,22,27…  并行 1,7,12,18,23…
    //     逐项差恒为 4；序列偏移 +4 时 **2496/2496 完全一致**
    //   ⇒ TDM 的查表地址序列【整体滞后 4 个周期】，而幅度完全对齐。
    //   修法：查表相位加 4×inc（只动读侧，写入路径不碰）。
    //   4×inc 用移位实现，避免乘法器。
    //   第二十九轮：试过在读侧加 4×inc 追那 4 个周期。
    //     **地址序列确实做到了 2500/2500 完全对齐**（实测），
    //     但输出仍有 725/2495 不符，而且【破坏了包络关闭的逐位一致基线】
    //     （8 种掩码全部 471/471）→ 已按纪律【回退】。
    //   保留的可靠事实：**查表地址序列整体滞后恰好 4 个周期**
    //     （跳变点逐项差恒为 4；序列偏移 +4 时 2500/2500 相同）。
    //     下一轮应从这个数字出发，但要在【不改变地址序列绝对值】的前提下修正，
    //     即让相位与幅度共用同一条时间轴，而不是给地址加常数偏移。
    //   第三十轮试过"相位额外推进"（boost_en 外部使能）
    //   做法：由测试台在装载完成后拉起 boost_en 持续 4 个周期，
    //         每个时隙因此恰好多得 4 次推进。
    //   结果：**查表地址序列确实做到了 2500/2500 完全对齐**（实测），
    //         但输出仍有 721/2495 不符，且**破坏了包络关闭的逐位一致基线**。
    //   → 已按纪律【回退】，boost_en 端口于 2026-10-01 删除。

    //   第三十三轮：试过"把幅度延后 4 个周期"（反向补偿）。
    //     **基线完好（8 掩码 0/500）**，但输出几乎没变（758 → 751，噪声范围）
    //     → 已回退。
    //   ⇒ 至此【两个方向都试过、都无效】：相位提前 / 幅度延后
    //
    //   ══════════════════════════════════════════════════════════════════════
    //   2026-10-01 结案：这个"4 周期偏移"的真身是【累加窗口跨两代】
    //
    //   第 27~33 轮一直在追"相位比并行滞后 4 个周期"这个现象，
    //   并把它当作**相位/时基**问题去补（读侧加常数、时基 boost、幅度延后）。
    //
    //   真正的根因完全不在相位上：
    //     旧的累加窗口 [sc0..sc31] 里，slot 0~3 的乘积来自【上一周期】的读取、
    //     slot 4~31 来自本周期 —— 一个"样本和"混了两代状态。
    //     这个组边界的宽度恰好就是 LAT=4，所以它在观测上【伪装成了 4 个周期的相位滞后】。
    //
    //   修法见文件末尾"级 5：累加"的窗口旋转（清零 sc=LAT、锁存 sc=LAT-1）。
    //   修后包络打开、含完整起音段，8/8 掩码 0/2495 逐位一致。
    //
    //   教训：**相位路径被逐位验证过（包络关闭时全通）就不该首先怀疑它**；
    //         而"样本和"的组边界从来没被单独验证过 —— 那才是应当先查的地方。
 // 完整的证据链见 与 TDM进展与未解问题.md。
    //   ══════════════════════════════════════════════════════════════════════
    wire [TAB_AW-1:0] tab_addr = ph1[PHASE_W-1 -: TAB_AW];

    //-------------------------------------------------------------------------
    // 表情调制层（滑音 + 颤音）—— 2026-10-01 新增
    //
    //   赛题拓展要求「搭建 ≥3 维演奏表情调控逻辑，支持力度动态、滑音、颤音」。
    //   力度已在 note_map 装载时生效（amp × vel）；滑音与颤音必须落在
    //   【相位推进】上，因为音高是每样本连续变化的量。
    //
    //   唯一的插入点就是下面这一行：
    //       ph_n = ph1 + eff_inc + ((eff_inc × poff) >> 16)
    //   poff 是每音符的有符号 Q2.16 音高比偏移（滑音衰减 + 全局颤音），
    //   由 pitch_mod.v 维护。因为 inc 里已含泛音比，所以【所有泛音同比移动】，
    //   滑音/颤音过程中谐波关系不变（判据 G2/V2）。
    //
    //   保护门：glide_en=0 且 vib_en=0 时 poff ≡ 0 → pmod ≡ 0 →
    //     ph_n 与原来的 ph1 + eff_inc 逐位相同。旧测试台接 `49'd0`
    //     即可保持逐位不变。
    //     因此 8 掩码 0/2495 的黄金参考回归必须原样通过 —— 做不到就是插错了。
    //
    //   不写回 inc_mem：调制只影响"这一拍的推进量"，inc_mem 里始终是
    //     基准音高。否则颤音会被逐样本累积（每次在上次的调制值上再乘），
    //     表现为指数跑飞 —— 这是本设计刻意避开的第一号陷阱。
    //-------------------------------------------------------------------------
    localparam integer PGRP = NSLOT / PART;   // 音符组数（= 最大复音数）
    localparam integer PBS  = $clog2(PART);   // 组内泛音索引位宽

    // pmod_cfg 切片（Verilog 不允许对切片再取切片，先落具名 wire）
    //   位宽必须写成"目标位宽"，不能写成源位段：
    //      曾经把 glide_m 写成 `wire [3:2] cfg_glide_m = pmod_cfg[3:2];`
    //      然后在例化时按 `cfg_glide_m[1:0]` 取位 —— 对 [3:2] 声明的向量
    //      取 [1:0] 是【越界取位】，Verilog 规定返回 x。
    //      后果极其隐蔽：只有【负数 gq】会显形（gq=0 的项被恒真条件掩盖），
    //      表现为"滑音一开始，那一组的相位就全变 x"。
    //      教训：切片声明一律用 [目标位宽-1:0]。
    wire [23:0] cfg_lfo_inc    = pmod_cfg[57:34];
    wire [15:0] cfg_vib_depth  = pmod_cfg[33:18];
    wire [15:0] cfg_glide_step = pmod_cfg[17:2];
    wire        cfg_vib_en     = pmod_cfg[1];
    wire        cfg_glide_en   = pmod_cfg[0];

    // 音高调制和（限幅【前】）。限幅改到下一拍做，见本文件"相位写回重定时"一段。
    localparam integer PMOD_QW = 18;
    // 限幅端点只在这里定义一次，并同时传给 pitch_mod —— 避免两处常量漂移。
    localparam signed [PMOD_QW-1:0] PMOD_CLAMP_LO = -18'sd114688;  // -1.75
    localparam signed [PMOD_QW-1:0] PMOD_CLAMP_HI =  18'sd131071;  // +1.9999
    wire signed [PMOD_QW:0] poff_pre;

    // 滑音初值的写入时机 = 【装载被消费的那一拍】
    //   这样 inc/amp/gate/epar/gq 五者同拍生效，不会出现
    //   "旧 inc × 新 gq"那种混代样本（见 pitch_mod.v 顶部注释）。
    wire               gw_en   = replace_params;
    // 组号位宽 = SW - PBS = $clog2(PGRP)（PBS 是"组内泛音索引"的位宽）
    wire [SW-PBS-1:0]  gw_note = sl1[SW-1:PBS];
    wire signed [17:0] gw_val  = pgq1;

    pitch_mod #(
        .NG        (PGRP),
        .QW        (PMOD_QW),
        .CLAMP_LO  (PMOD_CLAMP_LO),
        .CLAMP_HI  (PMOD_CLAMP_HI)
    ) u_pmod (
        .clk        (clk),
        .rst_n      (rst_n),
        .sample_en  (sample_en),
        .lfo_inc    (cfg_lfo_inc),
        .vib_depth  (cfg_vib_depth),
        .glide_step (cfg_glide_step),
        .vib_en     (cfg_vib_en),
        .glide_en   (cfg_glide_en),
        .gw_en      (gw_en),
        .gw_note    (gw_note),
        .gw_val     (gw_val),
        .rd_note    (sl1[SW-1:PBS]),
        // 限幅后的 poff 不再使用（下游改用 poff_pre 并自己限幅），故不连接。
        .poff_pre   (poff_pre)
    );

    // Freeze expression at the first partial of each group traversal. Updates
    // mid-group cannot split harmonics between two expression generations.
    //   ★ 2026-10-22 (M1-面积)：`finger_held` 不再复位。
    //   原来有一句 `for(fi=0;fi<PGRP;fi=fi+1) finger_held[fi]<=0;`。
    //   这一句让综合器无法把它推断成分布式 RAM：LUT RAM 没有复位端，
    //   于是 32×18 被铺成 576 个触发器 + 一个 32:1×18 的桶形选择器
    //   （实测约 162 LUT ≈ 81 CLS）。而本设计 CLS 已经 100% 占满，
    //   这是"再多 5 个 CLS 就布不通"的直接原因之一。
    //
    //   为什么去掉是安全的（与 pitch_mod 的 initialized[] 同一套纪律）：
    //   · `finger_held_active` 才是"该组是否已冻结过表情"的元数据，它照常复位；
    //   · 所有使用点都被 `finger_use` 门控 —— `eff_poff = fuse ? fing : poff`；
    //   · 写与读用同一个地址 `finger_group`，且写发生在该组第一个分音
    //     （`finger_first`），读发生在该组其余分音，中间隔 1..PBS-1 拍，
    //     所以"写后下一拍读到新值"的时序与原来逐位相同。
    //   ⇒ 未初始化的 RAM 内容永远走不到数据通路。
    reg signed [17:0] finger_held [0:PGRP-1];
    reg [PGRP-1:0] finger_held_active;
    wire [SW-PBS-1:0] finger_group = sl1[SW-1:PBS];
    wire finger_first = sl1[PBS-1:0] == 0;
    wire signed [17:0] finger_current = finger_offsets[finger_group*18 +: 18];
    wire finger_use = FINGER_EXPR && (finger_first ? finger_active[finger_group] :
                                                    finger_held_active[finger_group]);
    wire signed [17:0] finger_q = finger_first ? finger_current : finger_held[finger_group];
    always @(posedge clk or negedge rst_n) begin
        if(!rst_n) begin
            finger_held_active<=0;
            //   M1-面积：不再复位 finger_held 本体（见声明处注释）。
            //   复位循环会让它退化成 576 个触发器 + 32:1×18 桶形选择器。
        end else if(FINGER_EXPR && finger_first) begin
            finger_held[finger_group]<=finger_current;
            finger_held_active[finger_group]<=finger_active[finger_group];
        end
    end
    //-------------------------------------------------------------------------
    // 相位写回重定时（M1，2026-10-22）
    //
    // 【为什么可以加拍而不改变行为】
    //   时隙 s 的状态在 sc = s - LAT 被读一次，写回一次，然后要等【整整一个
    //   周期】—— 511 拍之后 —— 才会被再次读到。原设计把写回塞在"读后第 1 拍"，
    //   把整条 pmod 组合链（异步 RAM 读 → 组选择 → advance → 加法 → 限幅 →
    //   接触表情选择 → 乘法 → 增量加法 → 相位加法）压在一个 37.037 ns 周期里，
    //   实测 42.9 ns ⇒ setup −6.397 ns，而且 u_tdm 的 25 条最差路径【全部】从
    //   同一个 sl1[5] 出发。写回本来有 511 拍余量，却只用了 1 拍。
    //   ⇒ 把这条链摊成 3 拍，写回落在"读后第 3 拍"，仍是 508 拍余量。
    //
    // 【哪些东西必须留在原来那一拍（不能跟着延迟）】
    //   · tab_addr / tad2（正弦查表地址）—— 读侧，与写回无关，保持原样；
    //   · env/stg/inc/amp/epar/gq/gcur 的写回 —— 都是一两级的短链，保持原样；
    //   · 装载待生效区的消费（pv_mem 清零、load_* 写入）—— 保持原样。
    //   只有 phase_mem 的写回走新流水线。
    //
    // 【increment_invalid 的去处】
    //   它原来把 amp2 清零。amp2 → amp3 → prod4 还要 2 拍才进累加器，
    //   所以改成在【累加入口】把乘积清零：prod4 恒等于 sin3×amp3，
    //   amp 被清零时乘积本来就是 0，两者逐位等价。这样它就不必挤在
    //   amp2 那一拍上（原来正是这条 41 ns 的 n3872 链在拖 amp2）。
    //
    // 【时钟/复位】
    //   pclr 期间与主流水线一样冻结（产品与全部 TB 都把 pclr 接 1'b0）。
    //-------------------------------------------------------------------------
    //   ★ 2026-10-22：不再新建 `p_sl`。写地址直接用已有的 `sl2`（`sl2 <= sl1`
    //   就在主 always 块里，且 `sl2(t) == sl1(t-1)`），与它逐位相同。
    //   这么做的原因是实测出来的：用另建的 `p_sl` 时 u_tdm 的 BSRAM 从 10 变 11
    //   （SDPB 19→20，phase_mem 被拆成了两块），而写地址回到主块里的寄存器后
    //   形态与基线一致。同时省掉 9 个寄存器。
    reg [PHASE_W-1:0]   p_ph;      // P1：推进前的相位
    reg [PHASE_W-1:0]   p_inc;     // P1：有效增量
    reg signed [PMOD_QW:0] p_sum;  // P1：限幅前的音高和
    reg signed [PMOD_QW-1:0] p_fing;// P1：接触表情偏移（与 sl1 同源，独立于 pmod）
    reg                 p_fuse;    // P1：接触表情是否接管本组
    reg                 p_invalid; // P2：增量越界标志
    reg                 p_invalid_d; // P3：与 prod4 对齐的越界标志

    // P2 组合：限幅 → 接触表情选择 → 调制乘法 → 增量加法 → 相位加法
    wire signed [PMOD_QW-1:0] poff_d =
        (p_sum > PMOD_CLAMP_HI) ? PMOD_CLAMP_HI :
        (p_sum < PMOD_CLAMP_LO) ? PMOD_CLAMP_LO : p_sum[PMOD_QW-1:0];
    wire signed [PMOD_QW-1:0] eff_poff_d = p_fuse ? p_fing : poff_d;
    wire signed [42:0] pmod_mul_d = $signed({1'b0, p_inc}) * eff_poff_d;
    wire signed [26:0] pmod_d     = pmod_mul_d >>> 16;
    // 最终有符号增量：越界（≤0 或 ≥2^23）就判定为无效增量。
    wire signed [27:0] final_inc_d = $signed({4'b0000, p_inc}) +
                                     $signed({pmod_d[26], pmod_d});
    wire invalid_d = final_inc_d <= 0 || final_inc_d >= (1 << (PHASE_W-1));
    wire [PHASE_W-1:0] ph_n_d = p_ph + final_inc_d[PHASE_W-1:0];

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            p_ph <= {PHASE_W{1'b0}}; p_inc <= {PHASE_W{1'b0}};
            p_sum <= {(PMOD_QW+1){1'b0}}; p_fing <= {PMOD_QW{1'b0}}; p_fuse <= 1'b0;
            p_invalid <= 1'b0; p_invalid_d <= 1'b0;
        end
        else if (pclr) begin
            // 与主流水线一致：冻结（不推进、不写回）
        end
        else begin
            // P1：采样级 1 数据与音高链的组合结果
            p_ph   <= ph1;
            p_inc  <= eff_inc;
            p_sum  <= poff_pre;
            p_fing <= finger_q;
            p_fuse <= finger_use;

            p_invalid   <= invalid_d;
            // P3：再延一拍，与 prod4 同拍，供累加入口清零乘积
            p_invalid_d <= p_invalid;
        end
    end


    //-------------------------------------------------------------------------
    // 级 2 寄存器 + 写回
    //-------------------------------------------------------------------------
    reg [CORE_AMP_W-1:0] amp2;
    reg [TAB_AW-1:0]     tad2;
    reg [SW-1:0]         sl2;

    //-------------------------------------------------------------------------
    // pclr 必须【多保持 LAT 拍】—— 这是实测抓出来的
    //
    //   症状极具迷惑性：各时隙相位推进次数不一致，例如
    //       phase_mem[0] = (n+1) × inc0      ← 多走了一拍
    //       phase_mem[4] =  n    × inc4      ← 正确
    //   于是输出变成"后半组在第 n 拍 + 前半组在第 n-1 拍"的混合。
    //   更阴险的是：只开 0~3 号时隙时，那一组整体偏移一致，
    //   看起来只是"延迟 1 拍"，测试照样通过 —— 问题被完全掩盖。
    //
    //   根因：pclr 的【释放时刻没有对齐周期边界】。
    //   各时隙的回写发生在不同的 sc（slot s 在 sc = s-3 被写）：
    //       slot 4 → sc=1     slot 0 → sc=29
    //   若清零在 sc=10 释放，则第一个周期里 slot 4 的写被抑制、slot 0 的写生效，
    //   于是 slot 0 从此永远领先 slot 4 一整拍（实测 pm0/inc0 - pm4/inc4 恒为 1）。
    //
    //   修法：pclr 一旦置起就【内部保持到下一个 sample_en（周期边界）】，
    //   再额外保持 LAT 拍冲干净流水线。这样所有时隙从同一个周期边界开始计数。
    //   恢复点必须是【周期边界 sc=0】，不能是"边界 + LAT"。
    //     曾经写成 pclr | pclr_hold | (|pclr_ext)，把恢复点推到了 sc=LAT=4，
    //     于是第一个周期里"写回时刻早于 sc=4"的时隙与晚于它的时隙
    //     相差一次推进 —— 实测表现为：
    //         时隙 0~7  匹配延迟 2
    //         时隙 8~15 匹配延迟 1     ← 两组差整整一个周期
    //     单独测任一组都"通过"（组内偏移一致，被延迟搜索吸收掉了），
    //     只有把两组混在一起才会暴露。
    //
    //   最终方案：清零【走正常回写通路】，而不是"遍历 sc 去写"
    //
    //   遍历 sc 清零的问题：sc 的自由相位与"时隙的回写时刻"（slot s 在 sc=s-3 被写）
    //   互相错开，清零窗口的首尾必然切在某个时隙中间，导致各时隙拿到的推进次数不等。
    //   实测表现（一步步查出来的）：
    //       时隙 0~7  匹配延迟 2      时隙 8~15 匹配延迟 1   ← 两组差整整一个周期
    //     单独测任一组都"通过"（组内偏移一致，被延迟搜索吸收），
    //     只有混在一起才暴露 —— 这是最阴险的一类 bug。
    //
    //   正确做法：让 pclr 期间【回写 0】而不是回写 ph_n。
    //   每个时隙本来每周期就恰好被回写一次 → 清零天然均匀
    //   再把 pclr 内部保持到周期边界，就彻底没有"谁多走一拍"的问题。
    //-------------------------------------------------------------------------
    //   最终方案（第三轮定稿）：让流水线【全程正常运行】，只把【写回数据】换成 0
    //
    //   前两版都错在同一个地方：用 pclr 分支去接管整个 always 块，
    //   顺带把流水线寄存器也强制清零。后果是清零【停止】那一刻的第一笔写回，
    //   写出去的是 0 而不是 ph_n —— 而那一刻恰好轮到哪个时隙，
    //   哪个时隙就少一次推进。释放点移到哪里，受害的就是哪一组：
    //       释放点 sc=LAT : 0~7 正常、8~15 差一拍
    //       释放点 sc=0   : 0~7 差一拍、8~15 正常
    //   两组各自测都"通过"（组内偏移一致会被延迟搜索吸收），
    //   混在一起才暴露 —— 这是最阴险的一类 bug。
    //
    //   关键认识：**清零本身不均匀是无害的**（清成 0 再清一次还是 0）。
    //   真正致命的只有"停止那一刻的第一笔写回"。
    //   所以：流水线照常跑（sl1/ph1/inc1 始终有效），
    //   只把回写值换成 0。释放时流水线数据是有效的，
    //   第一笔写回就是正常的 ph_n，不多不少。
    //-------------------------------------------------------------------------
    //   第四轮定稿：清零窗口 = 【整数个周期】，且在周期边界精确结束
    //
    //   前三轮都栽在同一个地方：想让流水线"干净"（强制清 0），
    //   结果释放后第一笔写回写出 0 而不是 ph_n ——
    //   那一刻轮到哪个时隙，哪个时隙就少一次推进。
    //   实测（逐时隙量 phase/inc）：
    //       写回时刻 sc < LAT 的时隙（s3、s4）整整晚一个周期
    //   而把释放点从 sc=LAT 挪到 sc=0，受害的只是换了一批时隙，问题没消失。
    //
    //   关键认识：**清零本身不均匀是无害的**（清成 0 再清一次还是 0）。
    //   真正致命的只有【停止那一刻的第一笔写回】。
    //
    //   所以：
    //     · 流水线【全程正常运行】—— 释放瞬间 ph1/inc1 都是有效值，
    //       第一笔写回正好是该时隙的正常推进（0 + inc），不多不少
    //     · 清零只改【回写数据】（写 0），走的是同一条通路 →
    //       每个时隙每周期恰好被写一次，天然均匀
    //     · 清零窗口由内部计数器保证覆盖【完整的 2 个周期】，
    //       且在 sample_en（周期边界）精确结束 —— 不依赖使用者掐时间
    //-------------------------------------------------------------------------
    //   第九轮定稿：不清零、不冲刷 —— 改成【冻结】
    //
    //   "清零"和"冲刷"都失败在同一件事上：任何窗口的首尾都必然切在
    //   某个时隙的访问中间，导致各时隙被推进的次数不等
    //   （实测分界正好落在 s = LAT = 4）。
    //
    //   冻结则没有这个问题：pclr 期间把【原值写回】——
    //   相位写 ph1、包络写 env1 —— 电平不推进。
    //   冻结是【幂等】的：做多少次都一样，不存在"谁多走一步"。
    //   状态机（含触发、gq 更新）照常走，所以装载期间触发会被正常消费；
    //   释放时所有时隙都停在 ATK、lvl=0 的同一起跑线。
    //   释放点由内部保证对齐到周期边界。
    //-------------------------------------------------------------------------
    //   窗口必须严格覆盖【整数个周期】，且起点也在周期边界
    //   只对齐终点不够：起点落在周期中间会让第一段不完整，
    //   各时隙被预置的次数不同（"幂等"要求先覆盖全部时隙才成立）。
    //   做法：pclr 置起后先等到第一个 sample_en 才真正开始预置，
    //   结束后再数满 2 个完整周期才释放 —— 起止都在边界上。
    //   第十九轮：起止点都改到 `sc = NSLOT-1`，避开 `sc = 0`
    //   第十八轮实测：预置效果很好（32 个时隙单独全部逐位一致），
    //   但组合时 slot 3 一加入就崩。而 slot 3 的相位写时刻正是 `sc = 0`
    //   —— 与原来的释放沿（sample_en）撞在同一拍。
    //   `sc = 0` 在本设计里还有别的含义（sample_en、累加器复位），
    //   所以先把释放沿挪到 `sc = NSLOT-1`，看碰撞是否随之转移。
    //   ——这是"便宜且能否证伪"的实验：若问题跟着走走，机制就是"碰撞"；
    //     若仍固定卡在 slot 3，则 `sc=0` 另有作用，需要另找原因。
    reg [1:0] pclr_periods;
    reg       pclr_act;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            pclr_periods <= 2'd0;
            pclr_act     <= 1'b0;
        end
        else if (pclr) begin
            // 等到 sc = NSLOT-1 才真正开始（起点对齐到周期末尾）
            if (sc == NSLOT - 1) begin
                pclr_act     <= 1'b1;
                pclr_periods <= 2'd0;
            end
        end
        // 第二十三轮：相位预置分支【已删除】
        //   它在第十七轮被引入用于修起音瞬态，但实测它【引入了新的错位】：
        //   启用后 slot 3 会破坏多时隙组合（0x7 通过、0xF 失败 345/499）。
        //   预置关闭时 8 种掩码全部 0/500 —— 也就是说预置是【回归】而非修复。
        //   第 17~22 轮据此提出的三条"机理"（slot3 相位领先一周期、
        //   领先量=一个 inc、读侧减 inc 可对齐）全部建立在这个自伤之上，
        //   一并不成立。详见验收文档"第二十三轮"。
        //   `pclr` 端口保留但不再驱动任何逻辑（预留）。
        //   真正的遗留问题只有一条：**包络打开时起音段（样本 2~780）不符**。
        else begin
            // 级 1：读状态（含待生效装载区）
            ph1  <= phase_mem[slot_addr];
            inc1 <= inc_mem  [slot_addr];
            env1 <= env_mem  [slot_addr];
            epar1 <= epar_mem[slot_addr];   // 包络参数随状态一起读出
            stg1 <= stg_mem  [slot_addr];
            gc1  <= gcur_mem [slot_addr];
            gq1  <= gq_mem   [slot_addr];
            amp1 <= amp_mem  [slot_addr];
            pv1  <= pv_mem   [slot_addr];
            pp1  <= pp_mem   [slot_addr];
            pg1  <= pg_mem   [slot_addr];
            pi1  <= pi_mem   [slot_addr];
            pa1  <= pa_mem   [slot_addr];
            pe1  <= pe_mem   [slot_addr];   // 待生效 epar
            pgq1 <= pgq_mem  [slot_addr];   // 待生效滑音初值
            ppr1 <= ppar;
            sl1  <= slot_addr;

            // 级 2：寄存给后续级用
            //   M1：increment_invalid 不再在这里清零 amp —— 它现在在【累加入口】
            //   清 prod4（见"相位写回重定时"一段）。两者逐位等价，但把
            //   "乘法结果 → 越界判定 → amp2" 这条 41 ns 的链从本拍移走了。
            amp2 <= rh_amp_eff;
            tad2 <= tab_addr;
            sl2  <= sl1;

            // ---- 写回（对 sl1 号时隙）----
            //   第十七轮：相位【预置】—— 直接下在"相位起始偏移"这个根因上
            //
            //   实测（第十六轮）：TDM 的相位比并行【滞后】，而幅度不滞后。
            //   包络关闭时滞后只是整体延迟、被延迟搜寻吸收（所以逐位一致）；
            //   包络打开时幅度与相位错位 → 起音段对不上。
            //
            //   成因：slot s 的相位回写在 `sc = s-3`。
            //     slot 0~2  → sc=29,30,31，落在【周期 0】
            //     slot 3~31 → sc=0..28，而 sc=0 那一拍已被复位释放沿占用，
            //                 实际落到【周期 1】
            //   → 两组时隙的"第一次推进"差一个周期；
            //     而并行的相位在 tick 0 就推进了。
            //
            //   修法：把每个时隙的相位【显式预置为 inc】。
            //   沿 sc 扫一遍即可覆盖所有时隙 —— 而且因为每次写的都是
            //   同一个值 `inc_mem[sc]`，**这个操作是幂等的**：
            //   窗口从哪里开始、到哪里结束都无所谓
            //   （这正是"清零 / 冲刷 / 冻结"反复失败、而"预置"可行的原因 ——
            //     前者的结果依赖窗口边界，后者不依赖。）
            //
            //   同时把包络电平冻结（写回 env1），但状态机照常走，
            //   让触发在预置期间被消费掉。于是释放时所有时隙
            //   都停在「相位 = inc、包络 = ATK / lvl 0」的统一起跑线。
            //
            //   对照并行：tick 0 相位推进（P(0)=inc），包络只跳到 ATK（0 步进）；
            //   下一个 tick 相位 2×inc、包络 a_inc —— 与本预置后的节奏一致。
            // ---- 写回（对 sl1 号时隙）----
            //   2026-10-01：inc/amp/gcur 改为每周期写回"有效值"——
            //     正常访问时是原值原样（幂等），消费拍写入新装载值。
            //     这让装载经过与相位/包络完全相同的回写通路，天然均匀。
            //   M1：相位写回的数据来自上面的重定时流水线（写地址 `sl2` + `ph_n_d`），
            //   落点仍是"读后第 2 拍"（该时隙下次被读在 511 拍后，余量 509 拍）。
            //   `sl2` 在原始源码里就是 `sl1` 延迟一拍（且原本是死信号，被综合扫掉）。
            //   写口形状（同块、同钟、无写使能）与改动前完全一致，
            //   以保证 phase_mem 继续被推断成 RAM，而不是 512×24 个寄存器。
            phase_mem[sl2] <= ph_n_d;
            env_mem  [sl1] <= env_n;
            stg_mem  [sl1] <= stg_n;
            gq_mem   [sl1] <= eff_gate;
            gcur_mem [sl1] <= eff_gate;
            inc_mem  [sl1] <= eff_inc;
            amp_mem  [sl1] <= eff_amp;
            epar_mem [sl1] <= next_epar;        // 与其他三个参数对称
            if (consume)
                pv_mem[sl1] <= 1'b0;           // 消费完清待生效标志

            // ---- 参数装载（写入待生效区，下个样本周期统一生效）----
            //   注意顺序：装载写在消费清零之后 —— 同拍同槽时装载优先
            //   （它属于下个周期，不能被本拍的清零吃掉）。
            if (load_en) begin
                pi_mem [load_slot] <= load_inc;
                pa_mem [load_slot] <= load_amp;
                pg_mem [load_slot] <= load_gate;
                // Tags survive coalesced ON/refresh/OFF writes without an async
                // read of every pending slot. At 512 slots and >=20 cycles/ON,
                // an 8-bit tag cannot wrap before that slot consumes the buffer.
                pe_mem [load_slot] <= pending_epar;
                pgq_mem[load_slot] <= load_gq;     // 滑音初值同走待生效
                pv_mem [load_slot] <= 1'b1;
                pp_mem [load_slot] <= ppar;    // 打上装载时刻的周期奇偶
            end
        end
    end

    //-------------------------------------------------------------------------
    // 级 3：正弦表同步读（表只有一份，所有时隙共用同一个读端口）
    //-------------------------------------------------------------------------
    reg signed [15:0] sin3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) sin3 <= 16'sd0;
        else        sin3 <= sine_tab[tad2];
    end

    //-------------------------------------------------------------------------
    // 级 4：乘有效幅度（与并行版 osc_core 级 3 相同的算式）
    //
    //   幅度必须比正弦表【晚一拍】用 —— 这是实测抓出来的 bug
    //
    //   推导各信号来自哪一级的哪一拍：
    //       sin3(post-t) ← tad2(post-t-1) ← 级1数据(t-2)
    //       amp2(post-t) ← amp_eff(pre-t)  ← 级1数据(t-1)
    //   直接相乘会把【上一个时隙的正弦】和【当前时隙的幅度】配到一起，
    //   表现为"相位推进好像快了十几倍"的假象（其实是相邻时隙串了）。
    //
    //   osc_core 里没有这个问题，因为它的幅度 a_val 是【组合直通】的端口，
    //   永远是最新值；而这里幅度经过了 amp2 寄存器，多了一拍。
    //   修法：再加一级 amp3，让幅度和正弦来自同一个时隙。
    //
    //   另外必须显式声明 32 位中间量 mul_tmp
    //   写成 `prod4 <= (sin3 * amp3) >>> 16` 时，乘法是在【左值位宽】的上下文里
    //   求值的：prod4 是 24 位，乘积会先被截成 24 位再右移。
    //-------------------------------------------------------------------------
    reg [CORE_AMP_W-1:0] amp3;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) amp3 <= {CORE_AMP_W{1'b0}};
        else        amp3 <= amp2;
    end

    wire signed [31:0] mul_tmp = $signed(sin3) * $signed({1'b0, amp3});

    reg signed [23:0] prod4;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) prod4 <= 24'sd0;
        else        prod4 <= mul_tmp >>> CORE_AMP_W;
    end

    //-------------------------------------------------------------------------
    // 级 5：累加（每个时钟累加一个时隙的贡献）
    //
    //   关键：第 sc 拍的 prod4 属于【第 sc 号时隙】。
    //
    //   累加窗口旋转 LAT 拍（2026-10-01）：清零在 sc=LAT、锁存在 sc=LAT-1
    //     旧窗口 [sc0..sc31] 的问题是【横跨两个周期的读取】：
    //       slot 0~3 的乘积（读在 sc28~31）累加在下一周期的 sc0~3，
    //       slot 4~31 的乘积（读在 sc0~27）累加在本周期 ——
    //     同一个"样本和"里，slot 0~3 用的是上一周期访问的状态、
    //     slot 4~31 用的是本周期的 → 混代数（旧版能对上解析真值纯属
    //     装载时机恰好与这个组边界重合的幸运）。
    //     窗口改为 [sc(LAT)..sc(LAT-1)next] 后：slot 4~31 在本周期
    //     sc4~31 累加、slot 0~3 在下一周期 sc0~3 累加 —— 而它们的
    //     读取全部发生在【同一个周期】（slot s 的读取在 sc=s-4），
    //     于是每个样本和 = 全部 32 个时隙【同一代】状态的乘积
    //-------------------------------------------------------------------------
    wire signed [31:0] prod_ext = {{8{prod4[23]}}, prod4};
    // M1：增量越界（final_inc ≤ 0 或 ≥ 2^23）在这里把乘积清零，而不是在 amp2 处
    //   清幅度 —— prod4 = sin3 × amp3，amp3 为 0 时乘积本来就是 0，两者逐位等价；
    //   但这样"乘法结果 → 越界判定"就不必挤进 amp2 那一拍（原 41 ns）。
    //   p_invalid_d 与 prod4 同拍（见"相位写回重定时"一段的流水线编号）。
    wire signed [31:0] prod_g = p_invalid_d ? 32'sd0 : prod_ext;

    reg signed [31:0] acc;

    wire signed [31:0] acc_next = (sc == LAT) ? prod_g : (acc + prod_g);

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) acc <= 32'sd0;
        else        acc <= acc_next;
    end

    //-------------------------------------------------------------------------
    // 输出锁存（与并行版的 mixer 同款：增益 → 饱和）
    //   在 sc=LAT-1 拍锁存 acc_next —— 此刻恰好含最后一个时隙的贡献。
    //   sum_raw / sample_out 都是寄存器输出，从 sc=LAT-1 起保持一整个周期，
    //   消费方（I2S 在 sample_en=sc0 采样）看到的是上一帧的完整和
    //   （多一拍固定延迟，由比对脚本的延迟搜索吸收，无失真）。
    //-------------------------------------------------------------------------
    reg signed [31:0] sum_latched;
    wire signed [31:0] scaled = (acc_next <<< GAIN_UP) >>> SHIFT;

    localparam signed [31:0] MAXV =  (1 <<< (OUT_W-1)) - 1;
    localparam signed [31:0] MINV = -(1 <<< (OUT_W-1));

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            sum_latched <= 32'sd0;
            sample_out  <= {OUT_W{1'b0}};
        end
        else if (sc == LAT - 1) begin
            sum_latched <= acc_next;
            if (scaled > MAXV)      sample_out <= MAXV[OUT_W-1:0];
            else if (scaled < MINV) sample_out <= MINV[OUT_W-1:0];
            else                    sample_out <= scaled[OUT_W-1:0];
        end
    end

    assign sum_raw = sum_latched;

endmodule
