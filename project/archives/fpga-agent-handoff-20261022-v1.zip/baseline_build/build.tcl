open_project "C:/Users/Sakuya/.codex/worktrees/4d37/FPGA-Music-project/experiments/nano20k_feasibility_20261021/build_nominal_v0/board.gprj"
set_option -top_module joint_timing_top
set_option -use_sspi_as_gpio 1
run all
exit
